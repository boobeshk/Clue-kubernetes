"""Document creation (CLAUDE.md section 4.8).

Takes chunks that have already passed the groundedness gate and formats them into
docx / pdf / xlsx / png. This module never calls the LLM to fill in missing data --
it only lays out what retrieval already grounded. The single LLM call available here
is an optional title, and even that is derived from the request text.
"""
from __future__ import annotations

import io
import re
from datetime import datetime, timezone

from docx import Document
from docx.shared import Pt
from openpyxl import Workbook
from PIL import Image, ImageDraw, ImageFont
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

from ingestion.hd_map import display_name
from retriever.retriever import Hit

FORMATS = ("docx", "pdf", "xlsx", "png")


# Word requests, in the shapes people actually type. The earlier pattern only
# recognised "docx", "word document" and "word doc", so eight ordinary phrasings --
# "give me a Word file", "export this to MS Word", "as a Microsoft Word file",
# "I want a Word version", "put it in Word", "word format please", "make a .doc
# file" -- silently produced a PDF instead. Nothing announced the substitution: the
# request succeeded and returned the wrong file type.
#
# A bare "word" is safe to treat as Word HERE specifically, because detect_format is
# only ever called once the planner has already put the request in the docgen lane
# (see main.py), so the message is known to be asking for a file.
#
# Bare "doc" is deliberately NOT matched. It abbreviates "document" at least as often
# as "Word", so "make it a doc" stays on the default rather than guessing Word.
_DOCX_RE = re.compile(
    r"\bdocx\b|\.docx?\b|\bms\s*word\b|\bmicrosoft\s*word\b|\bword\b", re.I)


def detect_format(query: str) -> str:
    q = query.lower()
    if re.search(r"\b(xlsx|excel|spreadsheet|workbook)\b", q):
        return "xlsx"
    if re.search(r"\b(png|image|picture|graphic|poster)\b", q):
        return "png"
    if _DOCX_RE.search(q):
        return "docx"
    return "pdf"


_DOCGEN_VERBS = (r"create|make|generate|build|produce|give me|draft|export|prepare|"
                 r"put together|write|compile|summari[sz]e|summary of|pull|"
                 r"want|need|send|share")
# Multi-word forms first: regex alternation is first-match, so "ms word" has to be
# offered before "word" or only the "word" half is removed and a bare "MS" is left
# stranded in the retrieval subject.
# "docx" must precede "docs?" so the longer form wins and does not leave a bare "x".
# Bare "doc" IS stripped here even though it deliberately does NOT trigger docx in
# detect_format: these two jobs are different. Removing a format noun from the
# retrieval subject is always safe, whereas guessing Word from an ambiguous "doc"
# would silently change the file type the user gets.
_FORMAT_WORDS = (r"microsoft\s+word|ms\s+word|pdf|docx|docs?|xlsx|png|excel|word|"
                 r"image|spreadsheet|workbook|document|file|report|deck")


def content_query(query: str) -> str:
    """Strip the 'make me a file' wrapper, leaving the subject to retrieve on.

    The reranker scores how well a passage answers a QUESTION. A docgen request is an
    instruction ("export the TAG KPIs as a spreadsheet"), and scoring passages against
    the instruction collapses every relevance score, so the groundedness gate rejects
    perfectly good chunks. Retrieval therefore runs on the subject alone.
    """
    q = query.strip()
    # "I want a Word version of X" / "we need a docx on Y": the request can open with
    # a pronoun subject before the verb, which the anchored pattern otherwise misses,
    # leaving "I want" in the text retrieval scores against.
    q = re.sub(rf"^\s*(please\s+)?((i|we)\s+)?({_DOCGEN_VERBS})\s+", " ", q, flags=re.I)
    q = re.sub(rf"\b(as|in|to|into)\s+(an?\s+)?({_FORMAT_WORDS})\b", " ", q, flags=re.I)
    q = re.sub(rf"^\s*(an?|the)\s+({_FORMAT_WORDS})\s+(of|for|on|about|summarising|"
               rf"summarizing|covering|with)\s+", " ", q, flags=re.I)
    q = re.sub(rf"\b({_FORMAT_WORDS})\b", " ", q, flags=re.I)
    # Removing the format word can strand its article: "a <spreadsheet> of X" -> "a of X".
    q = re.sub(r"\b(an?|the)\s+(of|on|for|about|covering|with)\b", r"\2", q, flags=re.I)
    # It can also strand an artifact noun: "a Word version of X" -> "a version of X",
    # and "version of" scored against the passages is pure noise. This is what made
    # "I want a Word version of the compensation and benefits services" retrieve
    # nothing and report the knowledge base empty for a department that has the answer.
    q = re.sub(r"\b(an?|the)?\s*(version|copy)\s+of\b", " ", q, flags=re.I)
    # A colon survives "export this to MS Word: <subject>" once the format is removed.
    q = re.sub(r"\s+", " ", q).strip(" .,-:")
    # Strip filler left at the front by the verb removal ("me", "together", "of", ...).
    # pronouns included: a resolved follow-up reads "make this a document about X",
    # and leaving "this" in produced filenames like "this-a-document-about-x.pdf"
    leading = {"me", "us", "together", "of", "on", "for", "about", "a", "an", "the",
               "and", "this", "that", "it", "these", "those"}
    words = q.split()
    while len(words) > 1 and words[0].lower().strip(".,") in leading:
        words.pop(0)
    q = " ".join(words).strip(" .,-:")
    # If stripping left nothing of substance ("make it a doc" -> "a"), the request
    # named no subject at all. Hand back the original text rather than retrieving on
    # an article: the planner's reference-resolution path is what actually handles
    # this shape, and a one-word remnant would only score noise if it got this far.
    if len(q) < 3 or q.lower() in leading:
        return query.strip()
    return q


def _title(query: str) -> str:
    """Document title, and via _stem the filename too.

    Derived from content_query rather than from a second copy of the same stripping
    rules. The duplicate list had already drifted once; it drifted again when Word
    detection widened, leaving titles like "I want a Word version of the compensation
    and benefits services" and "To MS Word: what services does IT Support provide".
    One implementation cannot disagree with itself.
    """
    t = re.sub(r"\s+", " ", content_query(query)).strip(" .,-:")
    t = re.sub(r"^\s*(this|that|it|these|those)\s+", "", t, flags=re.I)
    return (t[:1].upper() + t[1:]) if t else "Knowledge Base Extract"


def _sections(hits: list[Hit]) -> list[tuple[str, str, str]]:
    """(heading, body, citation) per grounded chunk, header lines stripped."""
    out = []
    for h in hits:
        lines = h.content.split("\n")
        head = [l for l in lines if l.startswith(("Head department:", "Sub-department:",
                                                  "Section:"))]
        body = "\n".join(lines[len(head):]).strip()
        section = next((l.split(":", 1)[1].strip() for l in head if l.startswith("Section:")),
                       "Extract")
        sub = next((l.split(":", 1)[1].strip() for l in head if l.startswith("Sub-department:")),
                   "")
        heading = f"{section}" + (f" - {sub}" if sub else "")
        out.append((heading, body, h.source_name))
    return out


def _footer(hits: list[Hit]) -> str:
    depts = sorted({display_name(h.head_dept) for h in hits})
    files = sorted({h.source_name for h in hits})
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    return (f"Generated by HUB AI on {stamp}. "
            f"Departments: {', '.join(depts)}. Sources: {', '.join(files)}.")


def build_docx(query: str, hits: list[Hit]) -> bytes:
    doc = Document()
    doc.add_heading(_title(query), level=0)
    for heading, body, cite in _sections(hits):
        doc.add_heading(heading, level=2)
        for para in [p for p in body.split("\n") if p.strip()]:
            doc.add_paragraph(para)
        p = doc.add_paragraph()
        run = p.add_run(f"Source: {cite}")
        run.italic = True
        run.font.size = Pt(8)
    note = doc.add_paragraph()
    r = note.add_run(_footer(hits))
    r.italic = True
    r.font.size = Pt(8)
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def build_pdf(query: str, hits: list[Hit]) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=18 * mm, bottomMargin=18 * mm,
                            leftMargin=18 * mm, rightMargin=18 * mm, title=_title(query))
    styles = getSampleStyleSheet()
    cite_style = ParagraphStyle("cite", parent=styles["Normal"], fontSize=7.5,
                                textColor="#666666", spaceAfter=10)
    flow = [Paragraph(_title(query), styles["Title"]), Spacer(1, 6)]
    for heading, body, cite in _sections(hits):
        flow.append(Paragraph(heading, styles["Heading2"]))
        for para in [p for p in body.split("\n") if p.strip()]:
            flow.append(Paragraph(para.replace("&", "&amp;").replace("<", "&lt;"),
                                  styles["BodyText"]))
        flow.append(Paragraph(f"Source: {cite}", cite_style))
    flow.append(Spacer(1, 10))
    flow.append(Paragraph(_footer(hits), cite_style))
    doc.build(flow)
    return buf.getvalue()


def build_xlsx(query: str, hits: list[Hit]) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Knowledge Base Extract"
    ws.append(["Head department", "Sub-department", "Section", "Content", "Source file"])
    for h in hits:
        lines = h.content.split("\n")
        def field(prefix: str) -> str:
            return next((l.split(":", 1)[1].strip() for l in lines if l.startswith(prefix)), "")
        head = [l for l in lines if l.startswith(("Head department:", "Sub-department:", "Section:"))]
        body = "\n".join(lines[len(head):]).strip()
        ws.append([display_name(h.head_dept), field("Sub-department:"), field("Section:"),
                   body, h.source_name])
    for col, width in zip("ABCDE", (28, 30, 24, 90, 34)):
        ws.column_dimensions[col].width = width
    ws.freeze_panes = "A2"
    meta = wb.create_sheet("Provenance")
    meta.append(["Request", query])
    meta.append(["Generated", datetime.now(timezone.utc).isoformat()])
    meta.append(["Note", _footer(hits)])
    meta.column_dimensions["B"].width = 110
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def build_png(query: str, hits: list[Hit], width: int = 1200) -> bytes:
    try:
        title_font = ImageFont.truetype("arialbd.ttf", 34)
        head_font = ImageFont.truetype("arialbd.ttf", 20)
        body_font = ImageFont.truetype("arial.ttf", 17)
    except OSError:
        title_font = head_font = body_font = ImageFont.load_default()

    margin, y = 48, 48
    lines: list[tuple[str, ImageFont.ImageFont, str]] = [(_title(query), title_font, "#111111")]
    for heading, body, cite in _sections(hits):
        lines.append(("", body_font, "#000000"))
        lines.append((heading, head_font, "#1a3a6b"))
        for para in [p for p in body.split("\n") if p.strip()][:12]:
            for wrapped in _wrap(para, 96):
                lines.append((wrapped, body_font, "#222222"))
        lines.append((f"Source: {cite}", body_font, "#777777"))
    lines.append(("", body_font, "#000000"))
    for wrapped in _wrap(_footer(hits), 110):
        lines.append((wrapped, body_font, "#777777"))

    height = margin * 2 + sum(30 if f is not body_font else 24 for _, f, _ in lines)
    img = Image.new("RGB", (width, max(height, 300)), "#FFFFFF")
    draw = ImageDraw.Draw(img)
    for text, font, colour in lines:
        draw.text((margin, y), text, font=font, fill=colour)
        y += 30 if font is not body_font else 24
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def _wrap(text: str, width: int) -> list[str]:
    words, out, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width:
            out.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        out.append(cur)
    return out or [""]


def build(fmt: str, query: str, hits: list[Hit]) -> tuple[bytes, str, str]:
    """Returns (bytes, filename, media type)."""
    stem = re.sub(r"[^a-zA-Z0-9]+", "-", _title(query)).strip("-").lower()[:60] or "hub-ai-extract"
    if fmt == "docx":
        return (build_docx(query, hits), f"{stem}.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    if fmt == "xlsx":
        return (build_xlsx(query, hits), f"{stem}.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    if fmt == "png":
        return build_png(query, hits), f"{stem}.png", "image/png"
    return build_pdf(query, hits), f"{stem}.pdf", "application/pdf"
