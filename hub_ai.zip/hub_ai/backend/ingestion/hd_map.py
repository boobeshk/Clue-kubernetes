"""Head-department display name <-> slug mapping (CLAUDE.md section 2).

Storage folders are named with the DISPLAY name, not the slug, and the casing does
not necessarily match (the real bucket has "Holding Co & family office management").
Everything is matched on a normalised form: lowercased, "&" folded to "and",
punctuation dropped, whitespace collapsed.
"""
from __future__ import annotations

import re

# (display name, slug) -- exactly the 18 rows of CLAUDE.md section 2.
HEAD_DEPARTMENTS: list[tuple[str, str]] = [
    ("Business Growth Management", "business_growth_management"),
    ("Business Growth Support", "business_growth_support"),
    ("CMO", "cmo"),
    ("Customer Success Management", "customer_success_management"),
    ("Delivery Management", "delivery_management"),
    ("FDE DCG", "fde_dcg"),
    ("FDE TCG", "fde_tcg"),
    ("Finance", "finance"),
    ("Holding Co & Family Office Management", "holding_co_family_office_management"),
    ("Internal Apps", "internal_apps"),
    ("Knowledge Mastery & Deployment", "knowledge_mastery_deployment"),
    ("Labs", "labs"),
    ("Office of CEO", "office_of_ceo"),
    ("P-Cube", "p_cube"),
    ("SME Advisory Group", "sme_advisory_group"),
    ("Support Services", "support_services"),
    ("TAG", "tag"),
    ("Organizational Culture & People Experience (OCPE)", "ocpe"),
]

SLUG_TO_DISPLAY: dict[str, str] = {slug: name for name, slug in HEAD_DEPARTMENTS}
ALL_SLUGS: list[str] = [slug for _, slug in HEAD_DEPARTMENTS]


def normalize(name: str) -> str:
    """Fold a folder name to a comparable key."""
    s = name.strip().lower().replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


_LOOKUP: dict[str, str] = {normalize(name): slug for name, slug in HEAD_DEPARTMENTS}

# Extra spellings we accept for folders that do not exist in the bucket yet, so they
# resolve on the first incremental run after upload instead of being skipped.
_ALIASES: dict[str, str] = {
    "ocpe": "ocpe",
    "organizational culture and people experience": "ocpe",
    "organisational culture and people experience": "ocpe",
    "organisational culture and people experience ocpe": "ocpe",
    "sme advisory": "sme_advisory_group",
    "holding co and family office": "holding_co_family_office_management",
    "holding co family office management": "holding_co_family_office_management",
    "pcube": "p_cube",
    "p cube": "p_cube",
    "office of the ceo": "office_of_ceo",
    "knowledge mastery and deployment": "knowledge_mastery_deployment",
}
_LOOKUP.update(_ALIASES)


def resolve_slug(folder_name: str) -> str | None:
    """Storage folder name -> canonical slug, or None if it matches no known HD."""
    return _LOOKUP.get(normalize(folder_name))


def display_name(slug: str) -> str:
    return SLUG_TO_DISPLAY.get(slug, slug)
