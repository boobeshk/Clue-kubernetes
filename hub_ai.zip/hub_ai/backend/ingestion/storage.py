"""Supabase Storage access for the knowledge base bucket (CLAUDE.md section 4.5).

The backend never reads the raw JSON from local disk -- everything comes from the
bucket, under SUPABASE_KB_ROOT_PREFIX.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from clients import supabase
from config import SUPABASE_KB_BUCKET, SUPABASE_KB_ROOT_PREFIX

_PAGE = 100


@dataclass
class StorageFile:
    name: str
    path: str
    updated_at: str | None


def _list(prefix: str) -> list[dict[str, Any]]:
    """List one level under prefix, paging until exhausted."""
    bucket = supabase().storage.from_(SUPABASE_KB_BUCKET)
    out: list[dict[str, Any]] = []
    offset = 0
    while True:
        page = bucket.list(prefix, {
            "limit": _PAGE,
            "offset": offset,
            "sortBy": {"column": "name", "order": "asc"},
        })
        if not page:
            break
        out.extend(page)
        if len(page) < _PAGE:
            break
        offset += _PAGE
    return out


def _updated_at(entry: dict[str, Any]) -> str | None:
    meta = entry.get("metadata") or {}
    return entry.get("updated_at") or meta.get("lastModified") or entry.get("created_at")


def list_hd_folders() -> list[str]:
    """Folder names (HD display names) directly under the root prefix."""
    return [e["name"] for e in _list(f"{SUPABASE_KB_ROOT_PREFIX}/") if e.get("id") is None]


def list_json_files(folder: str) -> list[StorageFile]:
    """JSON files inside one HD folder."""
    files = []
    for e in _list(f"{SUPABASE_KB_ROOT_PREFIX}/{folder}/"):
        if e.get("id") is None or not e["name"].lower().endswith(".json"):
            continue
        files.append(StorageFile(
            name=e["name"],
            path=f"{SUPABASE_KB_ROOT_PREFIX}/{folder}/{e['name']}",
            updated_at=_updated_at(e),
        ))
    return files


def download_json(path: str) -> dict[str, Any]:
    raw = supabase().storage.from_(SUPABASE_KB_BUCKET).download(path)
    return json.loads(raw.decode("utf-8-sig"))
