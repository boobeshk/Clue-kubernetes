"""OpenAI embeddings (CLAUDE.md sections 4.1, 4.5 step 6).

Model comes from OPENAI_EMBEDDING_MODEL -- never hardcoded.
"""
from __future__ import annotations

import time

from clients import openai_client
from config import EMBED_BATCH_SIZE, EMBEDDING_DIM, OPENAI_EMBEDDING_MODEL

# text-embedding-3-small caps at 8191 tokens per input. Chunks are logical units and
# run far below that, but a pathological profile_text should be truncated rather than
# fail the whole batch. ~4 chars/token is the usual rough ratio.
_MAX_CHARS = 8000 * 4


def embed_texts(texts: list[str], max_retries: int = 5) -> list[list[float]]:
    """Embed a list of texts, preserving order."""
    if not texts:
        return []
    client = openai_client()
    vectors: list[list[float]] = []

    for start in range(0, len(texts), EMBED_BATCH_SIZE):
        batch = [t[:_MAX_CHARS] for t in texts[start:start + EMBED_BATCH_SIZE]]
        delay = 2.0
        for attempt in range(max_retries):
            try:
                resp = client.embeddings.create(model=OPENAI_EMBEDDING_MODEL, input=batch)
                break
            except Exception:
                if attempt == max_retries - 1:
                    raise
                time.sleep(delay)
                delay *= 2
        ordered = sorted(resp.data, key=lambda d: d.index)
        for d in ordered:
            if len(d.embedding) != EMBEDDING_DIM:
                raise RuntimeError(
                    f"{OPENAI_EMBEDDING_MODEL} returned {len(d.embedding)} dims, "
                    f"but documents.embedding is vector({EMBEDDING_DIM})."
                )
            vectors.append(d.embedding)

    return vectors


def embed_query(text: str) -> list[float]:
    return embed_texts([text])[0]
