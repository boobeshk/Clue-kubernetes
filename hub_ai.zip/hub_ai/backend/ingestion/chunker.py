"""JSON profile -> chunks (CLAUDE.md section 4.5 step 5).

Chunking rules, as confirmed against the real bucket schema (31 uniform top-level
keys across all 29 files):

  one chunk per list item   functions, services_offered, kpis, faqs, glossary,
                            contact_directory, sops, business_processes,
                            cross_department_relationships, decision_matrix,
                            approval_matrix, data_ownership, systems, policies,
                            integrations
  one chunk per section     department_identity, organization_structure,
                            ai_specific_knowledge, communication_channels,
                            dependencies, escalation_matrix, stakeholders
  its own chunk             profile_text
  metadata only, not text   department_id, department_name, content_owner,
                            data_classification, last_updated, last_reviewed_date,
                            source_documents, needs_review

Nothing is split on a fixed character length -- every chunk is one logical unit.

Item shapes drift inside a few fields (systems items carry "name" or "system_name";
integrations has two different shapes; services_offered.owner appears in only 27 of
46 items), so the renderer walks whatever keys an item actually has rather than
assuming a fixed set.

do_not_disclose is deliberately stripped from the ai_specific_knowledge chunk text
and carried in file-level metadata instead: it names the very figures it protects,
so embedding it verbatim would make them retrievable. The generation layer applies
it as a constraint (see groundedness/gate.py).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

# section key -> (human label, preferred key to use as the item's label)
LIST_SECTIONS: dict[str, tuple[str, tuple[str, ...]]] = {
    "functions": ("Functions", ("function_name",)),
    "services_offered": ("Services offered", ("service_name",)),
    "kpis": ("KPIs", ("name", "kpi_name")),
    "faqs": ("FAQs", ("question",)),
    "glossary": ("Glossary", ("term",)),
    "contact_directory": ("Contact directory", ("name",)),
    "sops": ("SOPs", ("sop_name",)),
    "business_processes": ("Business processes", ("name", "process_name")),
    "cross_department_relationships": (
        "Cross-department relationships", ("related_department", "department")),
    "decision_matrix": ("Decision matrix", ("question",)),
    "approval_matrix": ("Approval matrix", ("approval_type",)),
    "data_ownership": ("Data ownership", ("data_entity",)),
    "systems": ("Systems", ("name", "system_name")),
    "policies": ("Policies", ("policy_name",)),
    "integrations": ("Integrations", ("integration_name", "source")),
}

DICT_SECTIONS: dict[str, str] = {
    "department_identity": "Department identity",
    "organization_structure": "Organization structure",
    "ai_specific_knowledge": "AI-specific knowledge",
    "communication_channels": "Communication channels",
    "dependencies": "Dependencies",
    "escalation_matrix": "Escalation matrix",
    "stakeholders": "Stakeholders",
}

# Carried in documents.metadata, never embedded as retrievable text.
FILE_META_KEYS = (
    "content_owner", "data_classification", "last_updated",
    "last_reviewed_date", "source_documents", "needs_review",
)

# Never rendered into chunk text.
SUPPRESSED_SUBKEYS = {"do_not_disclose"}


@dataclass
class Chunk:
    content: str
    section: str
    label: str
    item_index: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


def _is_empty(v: Any) -> bool:
    if v is None:
        return True
    if isinstance(v, str):
        return not v.strip()
    if isinstance(v, (list, dict, tuple, set)):
        return len(v) == 0
    return False


def _humanize(key: str) -> str:
    return key.replace("_", " ").strip().capitalize()


def _render(value: Any, depth: int = 0) -> str:
    """Render an arbitrary JSON value as readable indented text."""
    pad = "  " * depth
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float, bool)):
        return str(value)
    if isinstance(value, list):
        if all(isinstance(x, (str, int, float, bool)) for x in value):
            return "; ".join(str(x).strip() for x in value if not _is_empty(x))
        parts = []
        for item in value:
            if _is_empty(item):
                continue
            rendered = _render(item, depth + 1)
            if rendered:
                parts.append(f"{pad}- " + rendered.lstrip())
        return "\n".join(parts)
    if isinstance(value, dict):
        lines = []
        for k, v in value.items():
            if k in SUPPRESSED_SUBKEYS or _is_empty(v):
                continue
            rendered = _render(v, depth + 1)
            if not rendered:
                continue
            if "\n" in rendered:
                lines.append(f"{pad}{_humanize(k)}:\n{rendered}")
            else:
                lines.append(f"{pad}{_humanize(k)}: {rendered}")
        return "\n".join(lines)
    return ""


def _label_for(item: dict, preferred: tuple[str, ...], index: int) -> str:
    for key in preferred:
        v = item.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    for v in item.values():
        if isinstance(v, str) and v.strip():
            return v.strip()
    return f"Item {index + 1}"


def clean_sub_dept(filename: str) -> str:
    """'partnerships-profile (1).json' -> 'partnerships-profile'."""
    stem = re.sub(r"\.json$", "", filename, flags=re.IGNORECASE)
    while True:
        new = re.sub(r"\s*\(\d+\)\s*$", "", stem)
        if new == stem:
            return new.strip()
        stem = new


def _header(hd_display: str, dept_name: str, sub_dept: str, section_label: str) -> str:
    return (f"Head department: {hd_display}\n"
            f"Sub-department: {dept_name} ({sub_dept})\n"
            f"Section: {section_label}")


def chunk_profile(doc: dict, hd_display: str, sub_dept: str) -> tuple[list[Chunk], dict]:
    """Return (chunks, file_meta) for one department profile JSON."""
    dept_name = (doc.get("department_name") or sub_dept or "").strip()
    dept_id = (doc.get("department_id") or "").strip()

    file_meta: dict[str, Any] = {k: doc.get(k) for k in FILE_META_KEYS if not _is_empty(doc.get(k))}
    aik = doc.get("ai_specific_knowledge") or {}
    if isinstance(aik, dict) and not _is_empty(aik.get("do_not_disclose")):
        file_meta["do_not_disclose"] = aik["do_not_disclose"]

    base_meta = {"department_id": dept_id, "department_name": dept_name}
    if not _is_empty(doc.get("data_classification")):
        base_meta["data_classification"] = doc["data_classification"]
    if not _is_empty(doc.get("last_updated")):
        base_meta["last_updated"] = doc["last_updated"]

    chunks: list[Chunk] = []

    # profile_text -- its own chunk, and the carrier for file-level metadata.
    profile_text = doc.get("profile_text")
    if isinstance(profile_text, str) and profile_text.strip():
        chunks.append(Chunk(
            content=_header(hd_display, dept_name, sub_dept, "Department profile")
                    + "\n\n" + profile_text.strip(),
            section="profile_text",
            label="Department profile",
            metadata={**base_meta, "file_meta": file_meta},
        ))

    # Nested dict sections -- one chunk each.
    for key, label in DICT_SECTIONS.items():
        value = doc.get(key)
        if not isinstance(value, dict) or _is_empty(value):
            continue
        body = _render(value)
        if not body.strip():
            continue
        chunks.append(Chunk(
            content=_header(hd_display, dept_name, sub_dept, label) + "\n\n" + body,
            section=key,
            label=label,
            metadata=dict(base_meta),
        ))

    # List sections -- one chunk per item.
    for key, (label, preferred) in LIST_SECTIONS.items():
        value = doc.get(key)
        if not isinstance(value, list):
            continue
        for i, item in enumerate(value):
            if _is_empty(item):
                continue
            if isinstance(item, dict):
                item_label = _label_for(item, preferred, i)
                body = _render(item)
            else:
                item_label = str(item).strip()[:120]
                body = _render(item)
            if not body.strip():
                continue
            singular = label[:-1] if label.endswith("s") and not label.endswith("ss") else label
            chunks.append(Chunk(
                content=_header(hd_display, dept_name, sub_dept, label)
                        + f"\n{singular}: {item_label}\n\n" + body,
                section=key,
                label=item_label,
                item_index=i,
                metadata=dict(base_meta),
            ))

    return chunks, file_meta
