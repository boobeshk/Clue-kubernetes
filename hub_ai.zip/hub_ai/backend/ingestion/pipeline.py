"""Ingestion orchestration (CLAUDE.md section 4.5).

Two run modes:
  incremental  only files whose Storage updated_at is newer than ingestion_log's
               file_updated_at (plus files never seen). The everyday path.
  full         reprocess every file in scope regardless of ingestion_log; the
               scope's documents rows are deleted first and ingestion_log rows
               rewritten from scratch.

The orphan check runs in BOTH modes: anything recorded in ingestion_log whose
storage_path is no longer in the bucket has its chunks and log row removed. Neither
run mode handles deletions on its own -- this is what does.
"""
from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable

from clients import supabase
from config import INSERT_BATCH_SIZE
from ingestion import storage
from ingestion.chunker import chunk_profile, clean_sub_dept
from ingestion.embedder import embed_texts
from ingestion.hd_map import display_name, resolve_slug
from ingestion.summarizer import generate_summary


@dataclass
class Job:
    job_id: str
    mode: str
    scope: str | None
    status: str = "running"          # running | done | error
    processed: int = 0
    total: int = 0
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    chunks_inserted: int = 0
    files_skipped: int = 0
    orphans_removed: int = 0
    per_hd: dict[str, int] = field(default_factory=dict)
    started_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    finished_at: str | None = None

    def as_status(self) -> dict[str, Any]:
        """Shape required by GET /api/documents/ingest/status/{job_id} (section 4.10)."""
        return {
            "status": self.status,
            "processed": self.processed,
            "total": self.total,
            "errors": self.errors,
            # extras beyond the spec's contract; harmless to ignore
            "warnings": self.warnings,
            "chunks_inserted": self.chunks_inserted,
            "files_skipped": self.files_skipped,
            "orphans_removed": self.orphans_removed,
            "per_head_dept": self.per_hd,
            "mode": self.mode,
            "scope": self.scope,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
        }


JOBS: dict[str, Job] = {}
_LOCK = threading.Lock()


def new_job(mode: str, scope: str | None) -> Job:
    job = Job(job_id=str(uuid.uuid4()), mode=mode, scope=scope)
    with _LOCK:
        JOBS[job.job_id] = job
    return job


def get_job(job_id: str) -> Job | None:
    with _LOCK:
        return JOBS.get(job_id)


# --------------------------------------------------------------------------- utils

def _parse_ts(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def _log_rows(head_depts: list[str]) -> dict[str, dict]:
    """ingestion_log rows for the given scope, keyed by storage_path."""
    sb = supabase()
    q = sb.table("ingestion_log").select("*")
    if head_depts:
        q = q.in_("head_dept", head_depts)
    return {r["storage_path"]: r for r in (q.execute().data or [])}


# ----------------------------------------------------------------------- the run

def run_ingestion(head_dept: str | None = None, mode: str = "incremental",
                  job: Job | None = None,
                  progress: Callable[[Job], None] | None = None) -> Job:
    job = job or new_job(mode, head_dept)
    sb = supabase()

    try:
        # --- 1. resolve folders -> slugs -----------------------------------
        folders = storage.list_hd_folders()
        resolved: list[tuple[str, str]] = []   # (folder, slug)
        for folder in folders:
            slug = resolve_slug(folder)
            if slug is None:
                job.warnings.append(
                    f"Folder {folder!r} matches no head department in CLAUDE.md section 2 "
                    f"-- skipped. Add it to section 2 first if it is a real department."
                )
                continue
            if head_dept and slug != head_dept:
                continue
            resolved.append((folder, slug))

        if head_dept and not resolved:
            job.warnings.append(
                f"No bucket folder resolves to head_dept {head_dept!r}. "
                f"Nothing to ingest for that scope."
            )

        scope_slugs = [slug for _, slug in resolved]

        # --- 2. list files, detect duplicates ------------------------------
        by_hd: dict[str, list[storage.StorageFile]] = {}
        for folder, slug in resolved:
            files = storage.list_json_files(folder)
            by_hd[slug] = files
            stems: dict[str, list[str]] = {}
            for f in files:
                stems.setdefault(clean_sub_dept(f.name), []).append(f.name)
            for stem, names in stems.items():
                if len(names) > 1:
                    job.warnings.append(
                        f"Possible duplicate upload in {folder!r}: {names} all reduce to "
                        f"{stem!r}. Ingested as distinct documents -- confirm this is intended."
                    )

        job.total = sum(len(v) for v in by_hd.values())
        if progress:
            progress(job)

        # --- 3. orphan check (both modes) ----------------------------------
        # Scope it to the HDs actually being processed, so a single-HD run never
        # deletes another department's rows.
        existing = _log_rows(scope_slugs)
        live_paths = {f.path for files in by_hd.values() for f in files}
        orphans = [p for p in existing if p not in live_paths]
        for path in orphans:
            sb.table("documents").delete().eq("source_file", path).execute()
            sb.table("ingestion_log").delete().eq("storage_path", path).execute()
            job.orphans_removed += 1
            job.warnings.append(f"Orphan removed: {path} is no longer in the bucket.")

        # --- 4. full mode: clear the scope ---------------------------------
        if mode == "full":
            for slug in scope_slugs:
                sb.table("documents").delete().eq("head_dept", slug).execute()
                sb.table("ingestion_log").delete().eq("head_dept", slug).execute()
            existing = {}

        # --- 5. per file: download -> chunk -> embed -> store --------------
        for folder, slug in resolved:
            hd_display = display_name(slug)
            files = by_hd[slug]
            touched = False
            profiles_for_summary: list[dict] = []

            for f in files:
                unchanged = False
                try:
                    prior = existing.get(f.path)
                    bucket_ts, log_ts = _parse_ts(f.updated_at), _parse_ts(
                        prior.get("file_updated_at") if prior else None)

                    unchanged = (
                        mode == "incremental" and prior is not None
                        and bucket_ts is not None and log_ts is not None
                        and bucket_ts <= log_ts
                    )

                    doc = storage.download_json(f.path)
                    profiles_for_summary.append(doc)

                    if unchanged:
                        job.files_skipped += 1
                        continue

                    sub_dept = clean_sub_dept(f.name)
                    chunks, _file_meta = chunk_profile(doc, hd_display, sub_dept)
                    if not chunks:
                        job.warnings.append(f"{f.path} produced 0 chunks.")

                    # Replace this file's chunks (incremental re-ingest of a changed file).
                    sb.table("documents").delete().eq("source_file", f.path).execute()

                    if chunks:
                        vectors = embed_texts([c.content for c in chunks])
                        rows = [{
                            "head_dept": slug,
                            "sub_dept": sub_dept,
                            "source_file": f.path,
                            "content": c.content,
                            "embedding": vec,
                            "metadata": {
                                **c.metadata,
                                "section": c.section,
                                "label": c.label,
                                "item_index": c.item_index,
                                "storage_file_name": f.name,
                            },
                        } for c, vec in zip(chunks, vectors)]

                        for i in range(0, len(rows), INSERT_BATCH_SIZE):
                            sb.table("documents").insert(rows[i:i + INSERT_BATCH_SIZE]).execute()

                        job.chunks_inserted += len(rows)
                        job.per_hd[slug] = job.per_hd.get(slug, 0) + len(rows)

                    sb.table("ingestion_log").upsert({
                        "storage_path": f.path,
                        "head_dept": slug,
                        "file_updated_at": f.updated_at,
                        "processed_at": datetime.now(timezone.utc).isoformat(),
                    }).execute()

                    touched = True
                except Exception as exc:  # one bad file must not kill the run
                    job.errors.append(f"{f.path}: {type(exc).__name__}: {exc}")
                finally:
                    job.processed += 1
                    if progress:
                        progress(job)

            # --- 6. regenerate this HD's routing summary --------------------
            if touched or orphans:
                try:
                    summary = generate_summary(hd_display, profiles_for_summary)
                    if summary:
                        sb.table("hd_index").upsert({
                            "head_dept": slug,
                            "summary_md": summary,
                            "updated_at": datetime.now(timezone.utc).isoformat(),
                        }).execute()
                except Exception as exc:
                    job.errors.append(f"hd_index[{slug}]: {type(exc).__name__}: {exc}")

        job.status = "error" if job.errors else "done"
    except Exception as exc:
        job.status = "error"
        job.errors.append(f"fatal: {type(exc).__name__}: {exc}")
    finally:
        job.finished_at = datetime.now(timezone.utc).isoformat()
        if progress:
            progress(job)

    return job
