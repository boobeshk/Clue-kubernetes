"""CLI for the ingestion pipeline.

    python -m ingestion.run --mode incremental
    python -m ingestion.run --head-dept cmo --mode full
    python -m ingestion.run --dry-run --head-dept cmo     # chunk only, no embed/insert

Run from the backend/ directory.
"""
from __future__ import annotations

import argparse
import sys

from ingestion import storage
from ingestion.chunker import chunk_profile, clean_sub_dept
from ingestion.hd_map import display_name, resolve_slug
from ingestion.pipeline import new_job, run_ingestion

_last = {"n": -1}


def _progress(job) -> None:
    if job.processed != _last["n"]:
        _last["n"] = job.processed
        pct = f"{job.processed / job.total * 100:5.1f}%" if job.total else "  ...%"
        print(f"\r  {pct}  {job.processed}/{job.total} files  "
              f"{job.chunks_inserted} chunks", end="", flush=True)


def dry_run(head_dept: str | None) -> int:
    """Chunk everything in scope and report, without embedding or writing."""
    total_chunks = 0
    for folder in storage.list_hd_folders():
        slug = resolve_slug(folder)
        if slug is None:
            print(f"  [skip] {folder!r} -> no matching head department")
            continue
        if head_dept and slug != head_dept:
            continue
        print(f"\n{folder}  ->  {slug}")
        for f in storage.list_json_files(folder):
            doc = storage.download_json(f.path)
            sub = clean_sub_dept(f.name)
            chunks, meta = chunk_profile(doc, display_name(slug), sub)
            total_chunks += len(chunks)
            by_section: dict[str, int] = {}
            for c in chunks:
                by_section[c.section] = by_section.get(c.section, 0) + 1
            print(f"  {f.name:<45} {len(chunks):>4} chunks")
            print(f"      sections: " + ", ".join(f"{k}={v}" for k, v in sorted(by_section.items())))
            if meta.get("do_not_disclose"):
                print(f"      do_not_disclose: {len(meta['do_not_disclose'])} rule(s) -> metadata only")
            if meta.get("needs_review"):
                print(f"      needs_review: {len(meta['needs_review'])} note(s) -> metadata only")
    print(f"\nTOTAL {total_chunks} chunks (dry run -- nothing embedded or written)")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--head-dept", default=None, help="slug, e.g. cmo. Omit for all.")
    ap.add_argument("--mode", default="incremental", choices=["incremental", "full"])
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    if args.dry_run:
        return dry_run(args.head_dept)

    print(f"mode={args.mode}  scope={args.head_dept or 'ALL'}")
    job = run_ingestion(args.head_dept, args.mode, new_job(args.mode, args.head_dept), _progress)
    print()

    s = job.as_status()
    print(f"\nstatus            {s['status']}")
    print(f"files processed   {s['processed']}/{s['total']}  (skipped unchanged: {s['files_skipped']})")
    print(f"chunks inserted   {s['chunks_inserted']}")
    print(f"orphans removed   {s['orphans_removed']}")
    if s["per_head_dept"]:
        print("chunks per head department:")
        for k, v in sorted(s["per_head_dept"].items()):
            print(f"   {k:<38} {v}")
    for w in s["warnings"]:
        print(f"  [warn]  {w}")
    for e in s["errors"]:
        print(f"  [ERROR] {e}")
    return 1 if s["status"] == "error" else 0


if __name__ == "__main__":
    sys.exit(main())
