"""FastAPI app + routes (CLAUDE.md section 4.10).

Run from backend/:  uvicorn main:app --reload
"""
from __future__ import annotations

import base64
import secrets
import threading
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import BackgroundTasks, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

import perf
import responder
import streaming
from clients import supabase
from config import (BACKEND_DIR, DRILLDOWN_KEEP, KB_ADMIN_PASSWORD,
                    KB_ADMIN_USERNAME, SINGLE_DEPT_BREADTH_KEEP)
from docgen import generator
from groundedness import gate
from ingestion.hd_map import ALL_SLUGS, display_name
from ingestion.pipeline import get_job, new_job, run_ingestion
from memory import store
from planner import planner
from retriever import retriever
from skills import registry

@asynccontextmanager
async def _lifespan(_app: FastAPI):
    """Warm the local cross-encoder in the background as the server comes up.

    The reranker model is cached for the life of the process either way -- it is not
    rebuilt per request -- but building it lazily meant the FIRST request after a
    restart spent 24.3s inside the rerank stage (measured), against 118-405ms for
    every request after it. Loading it here moves that one-time cost off a user.

    It runs on a daemon thread rather than inline: an inline load would hold up
    startup for as long as the weights take to materialise, which on a cold
    Hugging Face cache is the same 24s, just moved to boot. On a thread the server
    starts serving immediately, and a request arriving mid-load waits on the very
    same lock it already used, so this is never slower than before.
    """
    threading.Thread(target=retriever.warm_cross_encoder,
                     name="warm-cross-encoder", daemon=True).start()
    yield


app = FastAPI(title="HUB AI", version="0.1.0", lifespan=_lifespan)

# The frontend is a static file opened locally; it is not wired to this API yet
# (CLAUDE.md section 8) but the Embed buttons in section 3.4 do call it.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ------------------------------------------------------------------ /api/chat

class ChatRequest(BaseModel):
    query: str
    head_dept: str | None = None
    session_id: str | None = None
    # Section 4.11: client-generated identity + conversation. Both optional so the
    # section 4.10 contract still works unchanged for callers that send neither.
    anon_user_id: str | None = None
    conversation_id: str | None = None


@app.post("/api/chat")
def chat(req: ChatRequest):
    return _run_chat(req)


@app.post("/api/chat/stream")
def chat_stream(req: ChatRequest):
    """Same pipeline, with live stage status (section 4.13).

    What is streamed is STATUS ONLY. The answer is withheld until the pipeline --
    generation AND the post-generation claim verification in section 4.7 -- has
    completely finished, then sent once in a single `done` event. Streaming the
    model's raw output as it is produced would show the reader claims that
    verification is about to remove, which is exactly what that step exists to
    prevent, so it is not done here and must not be added later.
    """
    _validate_chat(req)
    return StreamingResponse(
        streaming.stream_pipeline(lambda progress: _run_chat(req, progress)),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no",
                 "Connection": "keep-alive"},
    )


def _validate_chat(req: ChatRequest) -> str:
    query = (req.query or "").strip()
    if not query:
        raise HTTPException(400, "query is required")
    if req.head_dept and req.head_dept not in ALL_SLUGS:
        raise HTTPException(400, f"unknown head_dept {req.head_dept!r}")
    return query


def _run_chat(req: ChatRequest, progress: "streaming.Progress | None" = None):
    query = _validate_chat(req)

    sw = perf.Stopwatch(on_stage=progress.on_stage if progress else None)

    # Section 4.11/4.12: prior turns and long-term memory are loaded as INTERPRETATION
    # context only. They are handed to the planner so a follow-up like "what about
    # last quarter?" resolves, and to generation for phrasing. They are never added to
    # the retrieval context and never influence head_dept scoping or the groundedness
    # gate -- only retrieved passages can ground an answer.
    with sw.stage("memory.load"):
        convo_ctx = store.recent_context(req.conversation_id) if req.conversation_id else ""
        memory_ctx = store.memory_context(req.anon_user_id) if req.anon_user_id else ""

    with sw.stage("planner.skills_fetch"):
        skills = registry.list_skills()
    # Two independent judgements about the same message: which lane serves it, and
    # what shape it is (breadth / all-department / drill-down). Run CONCURRENTLY --
    # they share no state, and sequencing them would put a second full round-trip on
    # the critical path of every single request for no reason.
    with sw.stage("planner.lane"):
        with ThreadPoolExecutor(max_workers=2) as pool:
            lane_f = pool.submit(planner.classify_lane, query, skills)
            intent_f = pool.submit(planner.understand, query, convo_ctx)
            lane, skill_id, _ = lane_f.result()
            intent = intent_f.result()
    # The classifier alone was too generous with chitchat: "can you tell me more?",
    # "tell me about it" and "can you help me with something?" were each labelled
    # chitchat and answered with a breezy pleasantry, when each is a request with no
    # subject that should have been asked to clarify. A deterministic check that the
    # message is PURELY social can only ever take the label away, which is the safe
    # direction -- section 4.6: a wrongly-broad chitchat call is a hallucination
    # surface, a wrongly-narrow one costs one wasted lookup.
    if lane == "chitchat" and not planner.is_pure_social(query):
        lane = "retrieval"

    # --- chitchat lane (section 4.6): no retrieval, no citations, no gate ---
    if lane == "chitchat":
        plan = planner.Plan(head_depts=[], confidence=1.0, lane="chitchat")
        planner.log_routing(query, plan)
        body = {"answer": planner.chitchat_reply(query, convo_ctx), "sources": [],
                "inferred_hd": None, "lane": "chitchat", "grounded": True,
                "timing": sw.summary()}
        perf.persist(sw, query, "chitchat", 0, False)
        _record(req, query, body)
        return body

    # --- reference resolution (sections 4.6, 4.8) ---
    # Resolve pronouns BEFORE routing or retrieval. With prior turns, rewrite the
    # query against them; with none, ask. What must never happen is retrieving on
    # the literal pronoun and reporting "not found in the knowledge base" -- that
    # blames the knowledge base for a question that never named its subject.
    effective_query = query
    resolved_from_context = False
    # Whether the message leans on earlier turns is a judgement about its shape, not
    # a regex over a list of referring expressions -- see planner.depends_on_context.
    # It returns False when there is no context, so the clarification branch below
    # still fires for a bare pronoun asked with nothing before it.
    #
    # A drill-down has already done this work: understand() resolved "the first
    # team" against the previous ANSWER, which is where the items being referred to
    # actually live. resolve_reference() looks at prior USER turns, so it cannot see
    # them -- that is the structural reason "what about the first team specifically"
    # came back with the same list of five teams instead of the first one.
    drill_focus = intent.focus if intent.drill_down else None
    if drill_focus:
        effective_query, resolved_from_context = drill_focus, True
    elif planner.depends_on_context(query, convo_ctx):
        with sw.stage("planner.resolve_reference"):
            effective_query, resolved_from_context = planner.resolve_reference(
                query, convo_ctx)
    if not resolved_from_context and planner.needs_reference_resolution(query):
        plan = planner.Plan(head_depts=[], confidence=0.0, lane=lane,
                            needs_clarification=True,
                            clarification=planner.reference_clarification(
                                query, has_prior_context=bool(convo_ctx.strip())))
        planner.log_routing(query, plan)
        body = {"answer": plan.clarification, "sources": [], "inferred_hd": None,
                "lane": lane, "needs_clarification": True, "confidence": 0.0,
                "unresolved_reference": True, "timing": sw.summary()}
        perf.persist(sw, query, lane, 0, False)
        _record(req, query, body)
        return body

    # A docgen request is an instruction, not a question. Route and retrieve on its
    # subject ("the TAG KPIs"), not on the wrapper ("export ... as a spreadsheet") --
    # otherwise the reranker scores every passage low and the gate rejects them all.
    # Route and retrieve on the RESOLVED query -- so a follow-up whose pronoun was
    # just resolved carries its real subject into both scope resolution and search.
    search_text = planner.strip_pleasantries(effective_query)
    # Section 4.8: a broad all-department request has no single subject to extract --
    # its subject IS "everything". Running content_query on it strips the only words
    # it has and retrieves on noise, which is how these fell through to a false
    # "not found".
    broad_request = intent.breadth and intent.all_departments
    retrieval_query = (generator.content_query(search_text)
                       if (lane == "docgen" and not broad_request) else search_text)

    with sw.stage("planner.scope"):
        plan = planner.resolve_scope(retrieval_query, req.head_dept,
                                     convo_ctx=convo_ctx, intent=intent)
    plan.lane, plan.skill_id = lane, skill_id
    # A skill only serves if it actually resolves; resolve it BEFORE logging or
    # reporting the lane, so routing_log and the client's lane badge both describe
    # what really handled the request rather than what the classifier proposed.
    active_skill = None
    if plan.lane == "skill":
        if plan.skill_id:
            with sw.stage("skill.fetch"):
                active_skill = registry.get_skill(str(plan.skill_id))
        if active_skill is None:
            plan.lane = "retrieval"
    with sw.stage("planner.routing_log"):
        planner.log_routing(query, plan)

    if plan.needs_clarification:
        perf.persist(sw, query, plan.lane, 0, False)
        body = {"answer": plan.clarification, "sources": [], "inferred_hd": None,
                "lane": plan.lane, "needs_clarification": True,
                "confidence": plan.confidence, "timing": sw.summary()}
        _record(req, query, body, plan)
        return body

    # Live facts for the status line, so it reports the actual shape of this
    # request rather than a generic phrase (section 4.13: honest status copy).
    if progress:
        scope_detail = (f"{len(plan.head_depts)} departments" if len(plan.head_depts) > 1
                        else plan.scope_label)
        for _stage in ("retrieval.search", "retrieval.broad"):
            progress.detail_for(_stage, scope_detail)

    unavailable: list[str] = []
    if plan.broad_coverage:
        # Representative slice from EVERY in-scope department, not a pooled top-N.
        # `unavailable` names departments that yielded nothing even after retry --
        # section 4.6 requires the ANSWER to disclose those, not just a server log,
        # because a summary that silently omits departments misrepresents its own
        # completeness even when every included fact is grounded.
        # One department in scope means the whole budget goes to it: three chunks
        # spread across fifteen departments is a company overview, but three chunks
        # is a thin basis for summarising a single department on its own.
        per_dept = (SINGLE_DEPT_BREADTH_KEEP if len(plan.head_depts) == 1 else None)
        hits, unavailable = retriever.retrieve_broad(
            retrieval_query, plan.head_depts, sw=sw, per_dept=per_dept)
    elif drill_focus:
        # Search on the resolved item, and keep more than usual -- the ordinary top
        # 5 are the passages that produced the answer already on screen.
        hits = retriever.retrieve(retrieval_query, plan.head_depts, sw=sw,
                                  keep=DRILLDOWN_KEEP)
    else:
        # NB: the all-department phrase is deliberately LEFT IN the query. Removing
        # it looked principled -- scope is routing information, not search content --
        # but measured against the cross-encoder it made things worse on 2 of 3
        # fan-out queries (top relevance 1.79 -> 0.25, 9.11 -> 8.41), because the
        # longer query gives the model more to match on.
        hits = retriever.retrieve(retrieval_query, plan.head_depts, sw=sw)
    inferred = plan.head_depts[0] if (plan.inferred and plan.head_depts) else None

    n_hd, all_flag = len(plan.head_depts), plan.searched_all
    if progress:
        # Only stages that have not started yet can be annotated. The rerank stages
        # run inside retriever.retrieve() above, so their count is not known in time
        # -- they keep the plain label rather than a number invented after the fact.
        n = len(hits)
        progress.detail_for("generation", f"{n} passage{'s' if n != 1 else ''}")

    # --- skill lane ---
    if plan.lane == "skill" and active_skill is not None:
        with sw.stage("skill.execute"):
            text = registry.execute(active_skill, effective_query, hits)
        perf.persist(sw, query, "skill", n_hd, all_flag)
        body = {"answer": text,
                "sources": [{"head_dept": h.head_dept, "source_file": h.source_file}
                            for h in hits],
                "inferred_hd": inferred, "lane": "skill",
                "skill": active_skill["name"], "timing": sw.summary()}
        _record(req, query, body, plan)
        return body

    # --- docgen lane: format only what the gate already grounded ---
    if plan.lane == "docgen":
        # Section 4.8: broad requests carry structurally-selected chunks with no
        # relevance score, so the relevance pre-gate does not apply to them.
        passed, top = (True, None) if (plan.broad_coverage and hits) else gate.pre_gate(hits)
        if not passed and plan.inferred and not plan.searched_all:
            return _ask_instead_of_guessing(req, query, plan, sw)
        if not passed:
            perf.persist(sw, query, "docgen", n_hd, all_flag)
            body = {"answer": gate.not_found_message(plan.scope_label), "sources": [],
                    "inferred_hd": inferred, "lane": "docgen", "grounded": False,
                    "timing": sw.summary()}
            _record(req, query, body, plan)
            return body
        with sw.stage("docgen.build"):
            fmt = generator.detect_format(query)
            data, filename, media_type = generator.build(fmt, effective_query, hits)
        perf.persist(sw, query, "docgen", n_hd, all_flag)
        body = {
            "answer": f"Generated **{filename}** from {len(hits)} grounded passage(s) in "
                      f"{plan.scope_label}. Nothing was added beyond what the sources state.",
            "sources": [{"head_dept": h.head_dept, "source_file": h.source_file} for h in hits],
            "inferred_hd": inferred, "lane": "docgen",
            "document": {"filename": filename, "media_type": media_type,
                         "base64": base64.b64encode(data).decode()},
            "timing": sw.summary(),
        }
        # Record BEFORE returning. Both docgen returns previously skipped this, so a
        # document turn never reached chat_turns -- the next message then resolved its
        # pronouns against a history with a hole in it.
        _record(req, query, body, plan)
        return body

    # --- retrieval lane ---
    # An inferred scope that yields nothing is evidence the inference was WRONG, not
    # evidence the knowledge base is empty. Asserting "I couldn't find any
    # information related to Support Services" for a vague question that was never
    # about Support Services tells the user something false about the knowledge base
    # AND hides the fact that a guess was made. Explicit scope is different: the user
    # named the department, so "nothing there" is the honest answer.
    if plan.inferred and not plan.searched_all and _looks_unroutable(hits, plan):
        return _ask_instead_of_guessing(req, query, plan, sw)

    # On a drill-down, hand generation the answer the user has already read. Without
    # it the model is answering a question it just answered, from much the same
    # passages, and returns the same text -- which is what it did.
    prior_answer = (store.last_assistant_answer(req.conversation_id)
                    if drill_focus else "")
    answer = gate.generate(effective_query, hits, plan.head_depts, plan.scope_label,
                           multi_department=n_hd > 1, sw=sw,
                           convo_ctx=convo_ctx, memory_ctx=memory_ctx,
                           broad_coverage=plan.broad_coverage,
                           unavailable=unavailable,
                           prior_answer=prior_answer, focus=drill_focus or "")
    perf.persist(sw, query, "retrieval", n_hd, all_flag)
    body = {"answer": answer.text, "sources": answer.sources, "inferred_hd": inferred,
            "lane": "retrieval", "grounded": answer.grounded,
            "confidence": plan.confidence, "searched_all": plan.searched_all,
            "blank_section": answer.blank_section,
            "unavailable_departments": unavailable, "timing": sw.summary()}
    # inferred_hd is returned as a field; the client renders it as a badge. Prefixing
    # the answer text with it too would show it twice.
    if answer.dropped_claims:
        body["dropped_claims"] = answer.dropped_claims
    _record(req, query, body, plan)
    return body


def _looks_unroutable(hits, plan) -> bool:
    """Nothing retrieved, or nothing that clears the relevance gate.

    Takes the plan so the broad-coverage exemption is applied here exactly as
    gate.generate applies it. Re-deriving the test without it turned every
    structurally-retrieved breadth request into a false "which department did you
    mean?" -- those chunks are selected by section and carry no relevance score, so
    the pre-gate rejects them by construction, not because nothing was found.
    """
    if plan.broad_coverage and hits:
        return False
    return not hits or not gate.pre_gate(hits)[0]


def _ask_instead_of_guessing(req: "ChatRequest", query: str, plan, sw) -> dict:
    """Ask which department, rather than assert a gap in a department we only
    guessed at. Composed from the live plan, never a fixed string."""
    text = responder.compose("inferred_miss", {
        "user_question": query,
        "department_tried": display_name(plan.head_depts[0]) if plan.head_depts else None,
        "can_search_all": True,
    })
    plan.needs_clarification = True
    perf.persist(sw, query, plan.lane, len(plan.head_depts), plan.searched_all)
    body = {"answer": text, "sources": [], "inferred_hd": None, "lane": plan.lane,
            "needs_clarification": True, "confidence": plan.confidence,
            "grounded": False, "timing": sw.summary()}
    _record(req, query, body, plan)
    return body


def _record(req: "ChatRequest", query: str, body: dict, plan=None) -> None:
    """Persist the exchange (section 4.11). Never breaks the response."""
    if not req.conversation_id:
        return
    try:
        convo = store.get_conversation(req.conversation_id)
        first_turn = not store.get_turns(req.conversation_id, limit=1)
        # Prefer the department that actually served this turn. A home conversation
        # has head_dept NULL, but its individual turns may each be scoped -- recording
        # only the conversation's NULL threw that away.
        turn_hd = None
        if plan is not None and getattr(plan, "head_depts", None):
            turn_hd = plan.head_depts[0] if len(plan.head_depts) == 1 else None
        turn_hd = turn_hd or req.head_dept or (convo or {}).get("head_dept")
        store.record_turn(req.conversation_id, "user", query, head_dept=turn_hd)
        store.record_turn(req.conversation_id, "assistant", body.get("answer", ""),
                          head_dept=turn_hd, sources=body.get("sources") or [])
        if first_turn and not (convo or {}).get("title"):
            store.set_title(req.conversation_id, store.generate_title(query))
    except Exception:
        pass


# --------------------------------------------------------- Knowledge Base admin
#
# The ingest controls are gated here, on the endpoints that do the work, not in the
# UI. A frontend-only prompt is not a control: POST /api/documents/ingest is an
# ordinary HTTP endpoint, so anyone who skipped the page and called it directly
# would still trigger a full re-embed. The button being hidden and the action being
# refused are different things, and only the second one is security.
#
# Credentials come from KB_ADMIN_USERNAME / KB_ADMIN_PASSWORD in backend/.env
# (gitignored). They are never sent to the client.

# One message for every failure mode. It must not say WHICH half was wrong -- naming
# the username as correct confirms a valid account to someone guessing.
_KB_AUTH_ERROR = "Incorrect username or password."


def _check_kb_admin(authorization: str | None) -> None:
    """Verify HTTP Basic credentials for a Knowledge Base admin action.

    Fails closed: if the server has no credentials configured, every admin action is
    refused rather than left open.
    """
    if not (KB_ADMIN_USERNAME and KB_ADMIN_PASSWORD):
        raise HTTPException(
            503, "Knowledge Base admin credentials are not configured on the server.")
    if not authorization or not authorization.lower().startswith("basic "):
        raise HTTPException(401, _KB_AUTH_ERROR,
                            headers={"WWW-Authenticate": "Basic"})
    try:
        decoded = base64.b64decode(authorization.split(" ", 1)[1]).decode("utf-8")
    except Exception:
        raise HTTPException(401, _KB_AUTH_ERROR)
    user, _, password = decoded.partition(":")
    # Both halves are always compared, and with compare_digest, so neither the
    # response nor the time taken reveals which one failed.
    ok_user = secrets.compare_digest(user, KB_ADMIN_USERNAME)
    ok_password = secrets.compare_digest(password, KB_ADMIN_PASSWORD)
    if not (ok_user and ok_password):
        raise HTTPException(401, _KB_AUTH_ERROR)


@app.post("/api/kb-admin/login")
def kb_admin_login(authorization: str | None = Header(default=None)):
    """Credential check for the UI gate. Returns 200 or 401 and nothing else --
    no token, no echo of the submitted values."""
    _check_kb_admin(authorization)
    return {"ok": True}


# ------------------------------------------------------- /api/documents/ingest

class IngestRequest(BaseModel):
    head_dept: str | None = None
    mode: Literal["incremental", "full"] = "incremental"


@app.post("/api/documents/ingest")
def ingest(req: IngestRequest, background: BackgroundTasks,
           authorization: str | None = Header(default=None)):
    # Checked BEFORE the job is created, so an unauthorised call starts nothing.
    _check_kb_admin(authorization)
    if req.head_dept and req.head_dept not in ALL_SLUGS:
        raise HTTPException(400, f"unknown head_dept {req.head_dept!r}")
    job = new_job(req.mode, req.head_dept)
    background.add_task(run_ingestion, req.head_dept, req.mode, job, None)
    return {"job_id": job.job_id}


@app.get("/api/documents/ingest/status/{job_id}")
def ingest_status(job_id: str, authorization: str | None = Header(default=None)):
    # Gated too: the status payload carries the error list, which can name storage
    # paths from the bucket.
    _check_kb_admin(authorization)
    job = get_job(job_id)
    if not job:
        raise HTTPException(404, "unknown job_id")
    return job.as_status()


# ------------------------------------------------------------ /api/skills

class SkillUpload(BaseModel):
    name: str
    description: str
    instructions_md: str
    trigger_keywords: list[str] = Field(default_factory=list)
    head_dept_scope: str | None = None
    script: str | None = None
    owner: str | None = None


@app.post("/api/skills/upload")
def upload_skill(req: SkillUpload):
    if req.head_dept_scope and req.head_dept_scope not in ALL_SLUGS:
        raise HTTPException(400, f"unknown head_dept_scope {req.head_dept_scope!r}")
    return registry.create_skill(
        name=req.name, description=req.description, instructions_md=req.instructions_md,
        trigger_keywords=req.trigger_keywords, head_dept_scope=req.head_dept_scope,
        script=req.script, owner=req.owner)


@app.get("/api/skills")
def get_skills():
    return registry.list_skills()


# ------------------------------------------------- /api/head-departments

@app.get("/api/head-departments")
def head_departments():
    rows = supabase().table("hd_index").select("head_dept,summary_md").execute().data or []
    summaries = {r["head_dept"]: r["summary_md"] for r in rows}
    return [{"slug": s, "name": display_name(s), "summary": summaries.get(s)}
            for s in ALL_SLUGS]


# ------------------------------------------------- conversations (section 4.11)

class ConversationCreate(BaseModel):
    anon_user_id: str
    head_dept: str | None = None


class TitlePatch(BaseModel):
    title: str


@app.post("/api/conversations")
def create_conversation(req: ConversationCreate):
    if req.head_dept and req.head_dept not in ALL_SLUGS:
        raise HTTPException(400, f"unknown head_dept {req.head_dept!r}")
    convo = store.create_conversation(req.anon_user_id, req.head_dept)
    return {"conversation_id": convo["id"], "head_dept": convo.get("head_dept")}


@app.get("/api/conversations")
def list_conversations(anon_user_id: str, head_dept: str | None = None,
                       scope: str = "auto"):
    """scope: auto | department | global | all.

    The sidebar's per-department Recents and the home view's global Recents are this
    same endpoint with and without head_dept -- matching the UI's existing split.
    """
    if head_dept and head_dept not in ALL_SLUGS:
        raise HTTPException(400, f"unknown head_dept {head_dept!r}")
    rows = store.list_conversations(anon_user_id, head_dept, scope)
    return [{"conversation_id": r["id"], "title": r.get("title"),
             "head_dept": r.get("head_dept"), "updated_at": r.get("updated_at")}
            for r in rows]


# Declared BEFORE /api/conversations/{conversation_id}: FastAPI matches routes in
# declaration order, so the dynamic route would otherwise capture "search" as an id.
@app.get("/api/conversations/search")
def search_conversations(anon_user_id: str, q: str, limit: int = 25):
    """Sidebar "Search chats" -- this user's own history, by title and by content.

    Returns [] for a blank query rather than the whole history, so an empty search
    box shows nothing instead of appearing to match everything.
    """
    rows = store.search_conversations(anon_user_id, q, limit=limit)
    return [{"conversation_id": r["id"], "title": r.get("title"),
             "head_dept": r.get("head_dept"), "updated_at": r.get("updated_at"),
             "match": r.get("match"), "excerpt": r.get("excerpt"),
             "excerpt_role": r.get("excerpt_role")}
            for r in rows]


@app.get("/api/conversations/{conversation_id}")
def get_conversation(conversation_id: str):
    convo = store.get_conversation(conversation_id)
    if not convo:
        raise HTTPException(404, "unknown conversation_id")
    return {"conversation_id": convo["id"], "title": convo.get("title"),
            "head_dept": convo.get("head_dept"),
            "turns": store.get_turns(conversation_id)}


@app.patch("/api/conversations/{conversation_id}")
def patch_conversation(conversation_id: str, req: TitlePatch):
    if not store.get_conversation(conversation_id):
        raise HTTPException(404, "unknown conversation_id")
    store.set_title(conversation_id, req.title)
    return {"conversation_id": conversation_id, "title": req.title}


@app.delete("/api/conversations/{conversation_id}")
def remove_conversation(conversation_id: str):
    store.delete_conversation(conversation_id)
    return {"deleted": conversation_id}


# ------------------------------------------------ long-term memory (section 4.12)

@app.get("/api/memory")
def get_memory(anon_user_id: str):
    """Section 4.12: a person must be able to see everything remembered about them."""
    return store.list_memories(anon_user_id)


@app.delete("/api/memory/{memory_id}")
def remove_memory(memory_id: str):
    store.delete_memory(memory_id)
    return {"deleted": memory_id}


@app.delete("/api/memory")
def remove_all_memory(anon_user_id: str):
    store.delete_all_memories(anon_user_id)
    return {"deleted_all_for": anon_user_id}


@app.post("/api/conversations/{conversation_id}/extract-memory")
def extract_memory(conversation_id: str, anon_user_id: str):
    """Conservative end-of-conversation extraction. Every candidate still passes the
    section 9 safety filter before it is written."""
    return {"written": store.propose_memories(anon_user_id, conversation_id)}


@app.get("/api/health")
def health():
    return {"status": "ok"}


# --------------------------------------------------------------- static frontend
# Serve frontend/index.html from this app so the page and the API share an origin
# and the client's relative /api/... paths resolve without any CORS or port
# juggling. Mounted LAST so every /api route above wins the match. Opening the file
# directly off disk still works -- the client falls back to http://127.0.0.1:8000.
_FRONTEND = BACKEND_DIR.parent / "frontend"
if _FRONTEND.is_dir():
    app.mount("/", StaticFiles(directory=str(_FRONTEND), html=True), name="frontend")
