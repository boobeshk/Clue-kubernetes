"""Live pipeline status over SSE, and the safe answer hand-off (section 4.13).

Two things live here, and section 4.13 is explicit that they are NOT the same thing:

  1. STATUS is streamed live. Each message is emitted as a real pipeline stage
     starts, and says what that stage is actually doing.

  2. THE ANSWER IS NOT STREAMED. It is sent once, in a single `done` event, only
     after the full pipeline -- including section 4.7's post-generation claim
     verification -- has finished. Streaming raw generation token-by-token would
     let someone read a claim that verification is about to strip, which defeats
     the entire purpose of having that step. The typing effect the user sees is a
     client-side reveal of already-verified text, not a live model stream.

Status is driven off the existing Stopwatch rather than a parallel set of emit()
calls. Every genuine stage in the pipeline is already wrapped in `sw.stage(...)`
for latency profiling (section 8.2), so hanging status off the same hook makes it
structurally impossible to show progress for work that did not run, or to forget
to update the status copy when a stage is added or removed.
"""
from __future__ import annotations

import json
import queue
import threading
from typing import Any, Callable, Iterator

# Real stage names, exactly as the pipeline records them in Stopwatch.stages.
# Anything not listed is deliberately silent rather than given invented copy: a
# stage with no honest description is better shown as nothing at all.
# The KEYS must be the names the pipeline really records. An earlier version used
# names that merely looked right ("groundedness.generate", "groundedness.verify")
# where the code actually records "generation" and "verification" -- and because an
# unlabelled stage is silently skipped, the two slowest, most important stages
# reported nothing at all and the user watched 16 seconds of silence. test_streaming
# now asserts this map and the pipeline agree in both directions.
STAGE_LABELS: dict[str, str] = {
    "memory.load": "Loading the conversation so far",
    "planner.skills_fetch": "Checking registered skills",
    "planner.lane": "Working out what you're asking for",
    "planner.resolve_reference": "Resolving what that refers to",
    "planner.scope": "Deciding which department to search",
    "planner.routing_log": "",          # bookkeeping, nothing worth showing
    "skill.fetch": "Loading the matching skill",
    "skill.execute": "Applying the skill",
    "retrieval.search": "Searching the knowledge base",
    "retrieval.broad": "Pulling a section from every department in scope",
    "rerank.single": "Ranking the passages by relevance",
    "rerank.fanout": "Ranking passages across departments",
    "groundedness.do_not_disclose": "Applying confidentiality rules",
    "generation": "Drafting the answer from the sources",
    "verification": "Checking every claim against the sources",
    "docgen.build": "Building the document",
}

# Every stage name the pipeline can record. Kept beside the labels so the test that
# compares them has one thing to check rather than a scrape of the whole codebase.
KNOWN_STAGES: frozenset[str] = frozenset(STAGE_LABELS)


def describe_stage(name: str, detail: str = "") -> str:
    """Status copy for a real stage. Empty means: say nothing.

    `detail` carries live facts from the request (how many departments, how many
    passages) so the line reports what is happening rather than decorating it.
    """
    label = STAGE_LABELS.get(name, "")
    if not label:
        return ""
    return f"{label} ({detail})" if detail else label


def sse(event: str, data: Any) -> str:
    """One Server-Sent Event frame."""
    payload = json.dumps(data, ensure_ascii=False)
    return f"event: {event}\ndata: {payload}\n\n"


class Progress:
    """Collects stage-start notifications and forwards them to a sink.

    Attached to a Stopwatch, so it fires on the same boundaries the latency
    profiler measures -- one source of truth for "what the pipeline is doing".
    """

    def __init__(self, sink: Callable[[str, dict], None] | None = None) -> None:
        self._sink = sink
        self._detail: dict[str, str] = {}
        self.seen: list[str] = []

    def detail_for(self, stage: str, detail: str) -> None:
        """Attach live facts to a stage before it starts (e.g. '15 departments')."""
        self._detail[stage] = detail

    def on_stage(self, name: str) -> None:
        self.seen.append(name)
        if self._sink is None:
            return
        text = describe_stage(name, self._detail.get(name, ""))
        if text:
            self._sink("status", {"stage": name, "message": text})

    def note(self, message: str, stage: str = "note") -> None:
        """A status line that is not a Stopwatch stage (e.g. 'answer verified')."""
        if self._sink is not None and message:
            self._sink("status", {"stage": stage, "message": message})


def stream_pipeline(run: Callable[[Progress], dict]) -> Iterator[str]:
    """Run the blocking pipeline in a worker thread, streaming its status.

    Yields SSE frames: any number of `status` events, then exactly one terminal
    event -- `done` carrying the finished, already-verified response body, or
    `error`. The answer only ever leaves here inside that single `done` frame.
    """
    events: queue.Queue = queue.Queue()
    DONE = object()

    def sink(event: str, data: dict) -> None:
        events.put((event, data))

    progress = Progress(sink)

    def worker() -> None:
        try:
            body = run(progress)
            events.put(("done", body))
        except Exception as exc:                      # noqa: BLE001
            events.put(("error", {"message": f"{type(exc).__name__}: {exc}"}))
        finally:
            events.put((DONE, None))

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()

    while True:
        event, data = events.get()
        if event is DONE:
            return
        yield sse(event, data)
