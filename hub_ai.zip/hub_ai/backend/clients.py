"""Shared Supabase and OpenAI clients."""
from __future__ import annotations

import time
from functools import lru_cache
from typing import Callable, TypeVar

import httpx
from openai import OpenAI
from supabase import Client, create_client

from config import OPENAI_API_KEY, SUPABASE_KEY, SUPABASE_URL

T = TypeVar("T")

# Transport-level failures: the connection broke, so nothing was computed and the
# call is safe to repeat. Measured on this project: five HTTP 500s across two full
# matrix runs, every one an httpx.RemoteProtocolError (StreamReset) raised out of a
# hybrid_search RPC, and a different case each time.
#
# postgrest ships a send_with_retry, but it only covers GET/HEAD returning 503/520
# (Cloudflare). An RPC is a POST, and a stream reset carries no status code at all,
# so none of these were ever retried -- one dropped HTTP/2 stream became a
# user-visible 500. The OpenAI SDK already retries its own transport errors
# (max_retries=2), which is why this sits on the Supabase side rather than there.
_TRANSIENT = (
    httpx.RemoteProtocolError,
    httpx.ReadError,
    httpx.WriteError,
    httpx.ConnectError,
    httpx.ConnectTimeout,
    httpx.ReadTimeout,
    httpx.PoolTimeout,
    ConnectionResetError,
)


def db_call(fn: "Callable[[], T]", attempts: int = 3, base_delay: float = 0.25) -> T:
    """Run a Supabase call, retrying transport failures with a short backoff.

    Deliberately narrow: only the exceptions above are retried. A PostgREST error
    (bad filter, missing table, RLS refusal) is a real answer from the server and
    is re-raised immediately -- retrying it would just hide the bug three times.
    """
    delay = base_delay
    for attempt in range(attempts):
        try:
            return fn()
        except _TRANSIENT:
            if attempt == attempts - 1:
                raise
            time.sleep(delay)
            delay *= 2
    raise AssertionError("unreachable")


@lru_cache(maxsize=1)
def supabase() -> Client:
    return create_client(SUPABASE_URL, SUPABASE_KEY)


@lru_cache(maxsize=1)
def openai_client() -> OpenAI:
    return OpenAI(api_key=OPENAI_API_KEY)
