"""Run the section 8.3 eval set and report pass/fail + latency per case.

    python -m tests.run_eval                 # all cases
    python -m tests.run_eval --filter dnd-    # subset
    python -m tests.run_eval --json out.json  # machine-readable

Run from backend/. Uses TestClient, so no separate server is needed.
"""
from __future__ import annotations

import argparse
import base64
import json
import re
import statistics
import sys
import time
from collections import Counter

from fastapi.testclient import TestClient

import main
from tests.eval_set import CASES, Case

CITE = re.compile(r"\[source:\s*([^\]]+?)\s*\]", re.I)
REFUSAL_MARKERS = ("don't have that in the knowledge base",
                   "does not record", "not record", "knowledge base does not cover",
                   "no such", "not available in the documentation")


def _cited_files(answer: str) -> set[str]:
    out = set()
    for raw in CITE.findall(answer):
        for part in raw.split(","):
            part = part.strip()
            # The model sometimes appends "department: x" inside the bracket; that is
            # an attribution, not a filename.
            if not part or ":" in part:
                continue
            out.add(part)
    return out


def _looks_refused(answer: str, d: dict | None = None) -> bool:
    """Did the system decline to answer?

    Judged on the STRUCTURED response, not on wording. Every user-facing message is
    now composed per request (no canned templates), so phrase-matching is not a
    stable test -- "I couldn't find any information related to TAG" and "I don't have
    that in the knowledge base" are the same outcome. `grounded is False` with no
    sources is the actual contract. Wording is only a fallback when the field is
    absent.
    """
    if d is not None and "grounded" in d:
        return d.get("grounded") is False and not (d.get("sources") or [])
    head = answer.strip()[:160].lower()
    return any(m in head for m in REFUSAL_MARKERS)


GAP_REPORT = re.compile(
    # The DOCUMENTATION must be the subject of the negation. A bare "not stated"
    # also matches a genuine answer that notes a sub-detail in passing ("P-Cube
    # covers X [source]. The exact cadence is not stated."), which is an answer.
    r"(documentation|document|source|knowledge\s+base|records?|profile|charter)"
    r"\s+(does\s+not|do\s+not|does ?n.t|do ?n.t)\s+"
    r"(record|specify|state|name|identify|mention|list|provide|contain|cover)"
    r"|^\s*(no|there is no)\s+(specific\s+)?(name|information|record|detail)"
    r"|could ?n.t find (any )?information",
    re.I)

def is_gap_report(answer: str) -> bool:
    """True when the answer is ESSENTIALLY "the source does not contain this".

    Head-anchored on purpose. A genuine answer may still note in passing that
    some sub-detail is unspecified -- "The Reward Council Review is a periodic
    governance process ... (owner not specified)" is an answer, not a gap. Only
    a gap statement leads with one.
    """
    return bool(GAP_REPORT.search((answer or "").strip()[:140]))



# --- tone -------------------------------------------------------------------
# The target is a warm, natural voice that VARIES, not a flat one. An earlier
# version of this check banned every friendly opening outright, which did stop the
# scripted "Yes, sure" but flattened the whole product in the process -- the wrong
# correction. Warmth and canned text are not the same thing, so they get two
# different tests:
#
#   1. BOILERPLATE below -- phrases that are assistant furniture no matter how they
#      are worded. These carry no information and are never the right answer.
#   2. opening_variety() -- a CORPUS check. Any single opener that dominates the
#      whole run is a template by definition, however friendly it sounds. This is
#      what actually distinguishes "warm" from "canned": warmth differs per answer,
#      a template does not.
BOILERPLATE = re.compile(
    r"as\s+an\s+ai\b"
    r"|based\s+on\s+the\s+(?:provided|given|above)\s+(?:passages|context|documents)"
    r"|(?:here'?s|here\s+is)\s+what\s+i\s+(?:found|have)\b"
    r"|i\s+hope\s+this\s+helps\b"
    r"|let\s+me\s+know\s+if\s+you\s+have\s+any\s+(?:other\s+)?questions"
    r"|feel\s+free\s+to\s+ask\b"
    r"|how\s+can\s+i\s+assist\s+you\s+today",
    re.I)


def opening_words(answer: str, n: int = 3) -> str:
    """First few words, normalised -- the unit a template repeats."""
    words = re.findall(r"[a-z']+", (answer or "").lower())
    return " ".join(words[:n])


def opening_variety(answers: list[str], cap: float = 0.30) -> tuple[bool, str]:
    """No single opening may account for more than `cap` of the answers.

    Deliberately a share, not a blocklist: it catches a canned opener nobody
    thought to ban, and it cannot be satisfied by making every answer identically
    terse. Blank openings are ignored.
    """
    from collections import Counter
    openers = [o for o in (opening_words(a) for a in answers) if o]
    if len(openers) < 20:
        return True, "too few answers to judge variety"
    top, count = Counter(openers).most_common(1)[0]
    share = count / len(openers)
    detail = (f"most common opening {top!r} used {count}/{len(openers)} "
              f"({share:.0%}); distinct openings {len(set(openers))}")
    return share <= cap, detail


# --- drill-down measurement -------------------------------------------------
# Two measures, because either alone is foolable: similarity catches a verbatim
# re-send, novelty catches a reworded restatement that shares few exact strings and
# still adds no facts.
_STOP = set("""the a an and or of for to in on at by is are was were be been being it
its this that these those with as from we our you your they their there here what
which who whom how why when has have had do does did not no can could would will
shall may might must about into over under more most some any each per within""".split())


def _content_words(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9']+", (text or "").lower())
            if w not in _STOP and len(w) > 2]


def _novelty(prior: str, answer: str) -> float:
    """Share of the answer's content words absent from the previous answer."""
    before, after = set(_content_words(prior)), _content_words(answer)
    if not after:
        return 0.0
    return sum(1 for w in after if w not in before) / len(after)


def _similarity(a: str, b: str) -> float:
    import difflib
    norm = lambda t: re.sub(r"\s+", " ", (t or "")).strip().lower()  # noqa: E731
    return difflib.SequenceMatcher(None, norm(a), norm(b)).ratio()


def judge(case: Case, d: dict) -> tuple[bool, str]:
    answer = d.get("answer", "") or ""
    low = answer.lower()
    sources = d.get("sources") or []
    lane = d.get("lane")

    # Tone applies to EVERY outcome type, in every lane.
    if BOILERPLATE.search(answer):
        return False, f"answer contains assistant boilerplate: {answer[:90]!r}"

    # Department isolation applies to EVERY outcome type.
    if case.expect_dept:
        foreign = sorted({s["head_dept"] for s in sources
                          if s["head_dept"] != case.expect_dept})
        if foreign:
            return False, f"leaked sources from {foreign}"

    if case.expect_inferred and d.get("inferred_hd") != case.expect_inferred:
        return False, (f"inferred_hd={d.get('inferred_hd')!r}, "
                       f"expected {case.expect_inferred!r}")

    if case.expect in ("broad_coverage", "broad_document"):
        if d.get("needs_clarification"):
            return False, f"asked for clarification: {answer[:110]!r}"
        if _looks_refused(answer, d):
            return False, f"false not-found on a broad request: {answer[:110]!r}"
        depts = {s["head_dept"] for s in sources}
        if len(depts) < case.min_departments:
            return False, (f"covered only {len(depts)} department(s) "
                           f"{sorted(depts)}; need >= {case.min_departments}. "
                           f"Pooled top-N starves most departments.")
        if case.expect == "broad_document":
            if lane != "docgen":
                return False, f"lane={lane!r}, expected docgen"
            doc = d.get("document")
            if not doc or not doc.get("base64"):
                return False, "no document returned"
            raw = base64.b64decode(doc["base64"])
            if raw[:4] not in (b"%PDF", bytes([0x50, 0x4B, 0x03, 0x04])) or len(raw) < 500:
                return False, f"not a real file ({len(raw)}b, {raw[:4]!r})"
        return True, ""

    if case.expect == "chitchat":
        if lane != "chitchat":
            return False, f"lane={lane!r}, expected chitchat"
        if sources:
            return False, f"chitchat cited {len(sources)} source(s); it must cite nothing"
        if _cited_files(answer):
            return False, f"chitchat answer contains a citation: {answer[:110]!r}"
        if _looks_refused(answer, d):
            return False, f"chitchat produced a refusal: {answer[:110]!r}"
        if not answer.strip():
            return False, "chitchat produced an empty reply"
        return True, ""

    if case.expect == "unresolved_ref":
        if not d.get("needs_clarification"):
            return False, f"expected a clarifying question, got lane={lane}"
        # The whole point: this must not be reported as a knowledge-base gap.
        if _looks_refused(answer, d):
            return False, (f"reported a knowledge-base gap for an unresolved "
                           f"reference: {answer[:110]!r}")
        if sources:
            return False, "retrieved and cited despite an unresolved reference"
        if not d.get("unresolved_reference"):
            return False, "response is not flagged as an unresolved reference"
        # Wording is composed per request, so assert on shape: it must ask something.
        if "?" not in answer:
            return False, f"clarification asks nothing: {answer[:110]!r}"
        return True, ""

    if case.expect == "clarify":
        if not d.get("needs_clarification"):
            return False, f"expected a clarifying question, got lane={lane}"
        return True, ""

    if case.expect == "refused":
        # A clarifying reply is acceptable here, and the matrix judge already
        # accepted it -- CLAUDE.md 8.0 requires the judges to share one definition
        # rather than one reporting a better number than the other. What matters is
        # that nothing was invented: saying "I looked in Support Services and it has
        # nothing on this - which department did you mean?" is a truthful account of
        # a search that found nothing, not a guess dressed up as an answer.
        if d.get("needs_clarification"):
            if sources:
                return False, "asked for clarification yet cited sources"
            return True, "asked which department (acceptable: nothing found to answer from)"
        # A grounded "the documentation does not record X" is also a valid refusal.
        if is_gap_report(answer):
            return True, ""
        if not _looks_refused(answer, d):
            return False, (f"answered instead of refusing "
                           f"(grounded={d.get('grounded')!r}, "
                           f"{len(sources)} source(s)): {answer[:110]!r}")
        return True, ""

    if case.expect == "inferred":
        # Unscoped question: the planner must work out the department itself and
        # answer from it. Same bar as "answered", plus the inference must be right.
        if d.get("needs_clarification"):
            return False, "asked for clarification instead of inferring the department"
        if not d.get("grounded", True) or _looks_refused(answer, d):
            return False, f"did not answer: {answer[:110]!r}"
        if not sources:
            return False, "no sources returned"
        want = case.expect_inferred or case.expect_dept
        if want and d.get("inferred_hd") != want:
            return False, f"inferred_hd={d.get('inferred_hd')!r}, expected {want!r}"
        if is_gap_report(answer):
            return False, f"reported a documentation gap, not an answer: {answer[:100]!r}"
        if not _cited_files(answer):
            return False, "answer carries no [source: ...] citation"
        return True, ""

    if case.expect == "blank_section":
        # Structured flag, not wording -- the message is composed per request.
        if not d.get("blank_section"):
            return False, f"not flagged as a blank section: {answer[:110]!r}"
        if _looks_refused(answer, d):
            return False, "reported as a knowledge-base gap rather than an empty section"
        if not sources:
            return False, "blank-section answer cites no source document"
        return True, ""

    if case.expect == "document":
        if lane != "docgen":
            return False, f"lane={lane!r}, expected docgen"
        doc = d.get("document")
        if not doc or not doc.get("base64"):
            return False, "no document returned"
        raw = base64.b64decode(doc["base64"])
        magic_ok = raw[:4] in (b"%PDF", bytes([0x50, 0x4B, 0x03, 0x04])) or raw[:2] == bytes([0x89, 0x50])
        if not magic_ok or len(raw) < 500:
            return False, f"document does not look real ({len(raw)}b, {raw[:4]!r})"
        return True, ""

    if case.expect == "no_disclose":
        for banned in case.must_not_contain:
            if banned.lower() in low:
                return False, f"disclosed banned token {banned!r}"
        # Must either refuse or answer without the protected specifics.
        if re.search(r"\b\d[\d,]{4,}\b", answer):
            return False, f"answer contains a large figure: {answer[:110]!r}"
        return True, ""

    if case.expect == "answered":
        if d.get("needs_clarification"):
            return False, "asked for clarification instead of answering"
        if not d.get("grounded", True):
            return False, "returned not-grounded"
        if _looks_refused(answer, d):
            return False, f"refused instead of answering: {answer[:110]!r}"
        if not sources:
            return False, "no sources returned"
        if is_gap_report(answer):
            return False, f"reported a documentation gap, not an answer: {answer[:100]!r}"
        if not _cited_files(answer):
            return False, "answer carries no [source: ...] citation"
        retrieved = {s["source_file"].split("/")[-1] for s in sources}
        bogus = _cited_files(answer) - retrieved
        if bogus:
            return False, f"cited files that were not retrieved: {sorted(bogus)}"
        return True, ""

    if case.expect == "drilldown":
        # A drill-down must add material the previous answer did not contain. Both
        # failure modes it replaced are checked: repeating the earlier answer, and
        # falsely reporting nothing on record.
        prior = d.get("_prior_answer", "") or ""
        if d.get("needs_clarification"):
            return False, "asked for clarification instead of going deeper"
        if not sources:
            return False, "no sources returned"
        sim = _similarity(prior, answer)
        nov = _novelty(prior, answer)
        if sim >= 0.80:
            return False, f"repeated the previous answer (similarity {sim:.2f})"
        if nov < 0.25:
            return False, f"added no new content (novelty {nov:.2f})"
        # A gap report is only a failure when it ALSO adds nothing: a good answer
        # may close by naming fields the sources leave unrecorded.
        if is_gap_report(answer) and (nov < 0.35 or len(answer) < 300):
            return False, f"reported nothing further instead of expanding: {answer[:110]!r}"
        if is_gap_report(answer):
            return False, ("led with what is missing instead of the new material: "
                           f"{answer[:110]!r}")
        return True, f"novelty {nov:.2f}"

    return False, f"unknown expect type {case.expect!r}"


# Rows created by a run are tagged at write time and removed afterwards
# (CLAUDE.md section 8.0). Only cases with setup_turns create any: a single-turn
# case still sends no conversation_id, exactly as before.
EVAL_USER_PREFIX = "zzeval-"


def _send(client, case: Case):
    """Send a case, replaying setup_turns first when it has them.

    Returns (response, body, prior_answer, conversation_id). prior_answer is the
    last answer the user saw before the graded turn -- what a drill-down has to add
    to, and what it must not simply repeat.
    """
    if not case.setup_turns:
        r = client.post("/api/chat", json={"query": case.query,
                                           "head_dept": case.head_dept,
                                           "session_id": "eval"})
        return r, (r.json() if r.status_code == 200 else {}), "", None

    import uuid
    anon = EVAL_USER_PREFIX + uuid.uuid4().hex[:12]
    convo = client.post("/api/conversations",
                        json={"anon_user_id": anon,
                              "head_dept": case.head_dept}).json()["conversation_id"]
    prior = ""
    for turn in case.setup_turns:
        pr = client.post("/api/chat", json={
            "query": turn, "head_dept": case.head_dept, "session_id": "eval",
            "anon_user_id": anon, "conversation_id": convo})
        if pr.status_code == 200:
            prior = pr.json().get("answer", "") or prior
    r = client.post("/api/chat", json={
        "query": case.query, "head_dept": case.head_dept, "session_id": "eval",
        "anon_user_id": anon, "conversation_id": convo})
    return r, (r.json() if r.status_code == 200 else {}), prior, convo


def _cleanup(client, conversation_id: str) -> None:
    """Guaranteed removal of rows this run created (section 8.0)."""
    try:
        client.delete(f"/api/conversations/{conversation_id}")
    except Exception:
        pass


def main_cli() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--filter", default=None)
    ap.add_argument("--json", dest="json_out", default=None)
    args = ap.parse_args()

    cases = [c for c in CASES if not args.filter or args.filter in c.id]
    client = TestClient(main.app)

    from config import RERANK_BACKEND, GROUNDEDNESS_MIN_RELEVANCE
    print(f"eval set: {len(cases)} cases   rerank_backend={RERANK_BACKEND}   "
          f"min_relevance={GROUNDEDNESS_MIN_RELEVANCE}")
    print(f"{'case':<24} {'expect':<14} {'result':<6} {'secs':>7}  detail")
    print("-" * 108)

    results, latencies = [], []
    for c in cases:
        t0 = time.perf_counter()
        convo = None
        try:
            r, d, prior, convo = _send(client, c)
            if r.status_code != 200:
                d, ok, why = {"answer": "", "_http": r.status_code}, False, \
                    f"HTTP {r.status_code}"
            else:
                d["_prior_answer"] = prior
                ok, why = judge(c, d)
        except Exception as exc:
            d, ok, why = {}, False, f"{type(exc).__name__}: {exc}"
        finally:
            # In `finally`, not on the success path: a crash before this line is
            # exactly how test rows have been left in production tables before.
            if convo:
                _cleanup(client, convo)
        secs = time.perf_counter() - t0
        latencies.append(secs)
        results.append({"id": c.id, "expect": c.expect, "pass": ok, "detail": why,
                        "seconds": round(secs, 2), "lane": d.get("lane"),
                        "inferred_hd": d.get("inferred_hd"),
                        "timing": d.get("timing"),
                        "answer": (d.get("answer") or "")[:400]})
        print(f"{c.id:<24} {c.expect:<14} {'PASS' if ok else 'FAIL':<6} {secs:>7.2f}  {why}")

    passed = sum(1 for r in results if r["pass"])
    latencies.sort()
    p50 = statistics.median(latencies)
    p95 = latencies[min(len(latencies) - 1, int(round(0.95 * (len(latencies) - 1))))]
    print("-" * 108)
    print(f"{passed}/{len(results)} passed    latency p50={p50:.2f}s  p95={p95:.2f}s  "
          f"max={max(latencies):.2f}s")

    by_type = Counter((r["expect"], r["pass"]) for r in results)
    print("\nby outcome type:")
    for exp in sorted({r["expect"] for r in results}):
        p, f = by_type[(exp, True)], by_type[(exp, False)]
        print(f"  {exp:<16} {p} pass / {f} fail")

    # Corpus-level tone check. A per-answer test cannot tell warmth from a
    # template -- only looking across the whole run can, because that is exactly
    # the difference: a template repeats, warmth does not.
    varied, variety_detail = opening_variety([r["answer"] for r in results])
    print(f"\nopening variety: {'OK' if varied else 'TOO REPETITIVE'} - {variety_detail}")
    if not varied:
        print("  a single opener dominating the run is a template, however friendly")
    from collections import Counter as _C
    top5 = _C(o for o in (opening_words(r["answer"]) for r in results) if o).most_common(5)
    for opener, n in top5:
        print(f"    {n:>3}x  {opener!r}")

    if passed != len(results):
        print("\nfailures:")
        for r in results:
            if not r["pass"]:
                print(f"  {r['id']:<24} {r['detail']}")
                print(f"      answer: {r['answer'][:200]!r}")

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=2)
        print(f"\nwrote {args.json_out}")

    return 0 if (passed == len(results) and varied) else 1


if __name__ == "__main__":
    sys.exit(main_cli())
