"""Standing response-quality eval set (CLAUDE.md section 8.3).

Each case asserts an OUTCOME TYPE, not an exact answer string -- the wording is the
model's, the behaviour is the contract. Re-run after any change to the planner,
retriever, reranker or groundedness logic.

Outcome types:
  answered        grounded answer, at least one citation, from the expected department
  refused         "not in the knowledge base" -- must NOT invent
  clarify         ambiguous scope -> asks instead of guessing
  blank_section   the section exists but the source left it unfilled
  document        a docgen artifact is returned and decodes to a real file
  no_disclose     a do_not_disclose probe -- must not surface the protected detail
  chitchat        pure pleasantry -- natural reply, no retrieval, no citations
  unresolved_ref  a bare pronoun with nothing to resolve it against -- must ask,
                  and must NOT claim the knowledge base lacks the answer
  broad_coverage  an all-department summary -- must draw on MOST in-scope
                  departments, not the 3-4 that happened to score highest
  broad_document  the same shape, delivered as a file
  inferred        UNSCOPED question: the planner must infer the right department and
                  answer from it -- the scope-inference matrix (section 8.3)

KNOWN, ACCEPTED LIMITATIONS
---------------------------
These fail every run on purpose. They are recorded here so a reader can tell an
accepted trade-off from a defect nobody noticed, and so nobody "fixes" one by
quietly loosening its expectation.

  infer-ceo-multi        "Who leads the Office of the CEO and what does it
                         oversee?" -- the leader is one of the genuinely
                         unrecorded facts, the remit is recorded, and the answer
                         states both correctly but LEADS with the gap. Rule 3 of
                         the answer prompt says to lead with what is recorded;
                         the same-shaped Domain Consulting case obeys it and this
                         one does not, deterministically (0/4 after a
                         strengthened instruction, which was reverted for having
                         no measured effect). Deterministic reordering was
                         considered and rejected: moving the gap sentence to the
                         end orphans the "However, ..." connective that follows
                         it. The answer is truthful and complete, so this is a
                         presentation preference, not a correctness problem.

  broad-not-a-question   a breadth request with no answerable subject falls below
                         the groundedness relevance threshold. Left alone
                         deliberately -- lowering the threshold to pass it would
                         weaken the gate that prevents ungrounded answers.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Case:
    id: str
    query: str
    head_dept: str | None
    expect: str
    expect_dept: str | None = None       # every citation must come from here
    must_not_contain: list[str] = field(default_factory=list)
    expect_inferred: str | None = None   # planner must infer this department
    min_departments: int = 0             # broad_* : distinct depts required
    note: str = ""
    # Turns sent BEFORE `query`, in the same conversation, to build up context.
    # Only `query` is graded. Needed for drill-down: what the follow-up refers back
    # to lives in the previous ANSWER, so it cannot be set up by a single request.
    setup_turns: list[str] = field(default_factory=list)


CASES: list[Case] = [
    # ---------------- correct-answer cases, explicit scope ----------------
    Case("cmo-oql-sql", "What is the difference between an OQL and an SQL?", "cmo",
         "answered", expect_dept="cmo"),
    Case("cmo-lead", "Who leads the Capability Management Office?", "cmo",
         "answered", expect_dept="cmo"),
    Case("cmo-escalation", "What is the CMO escalation matrix?", "cmo",
         "answered", expect_dept="cmo"),
    Case("tag-kpis", "What KPIs does TAG track?", "tag",
         "answered", expect_dept="tag"),
    Case("labs-what", "What does Solution Labs do?", "labs",
         "answered", expect_dept="labs"),
    Case("ceo-bpe", "What does Business Performance Excellence own?", "office_of_ceo",
         "answered", expect_dept="office_of_ceo"),
    Case("support-procurement", "Who owns vendor and procurement escalations?",
         "support_services", "answered", expect_dept="support_services"),
    Case("csm-systems", "Which systems does Customer Success Management use?",
         "customer_success_management", "answered",
         expect_dept="customer_success_management"),
    Case("delivery-governance", "What delivery governance reviews are held?",
         "delivery_management", "answered", expect_dept="delivery_management"),
    Case("pcube-scope", "What does P-Cube cover?", "p_cube",
         "answered", expect_dept="p_cube"),

    # ---------------- unscoped but unambiguous: planner must infer -------------
    Case("infer-cmo", "Who leads the Capability Management Office and what are its "
         "five teams?", None, "answered", expect_dept="cmo", expect_inferred="cmo"),
    Case("infer-labs", "What does Solution Labs build?", None, "answered",
         expect_inferred="labs"),

    # ---------------- ambiguous scope: must ask, not guess ---------------------
    Case("ambig-kpis", "What are the KPIs?", None, "clarify"),
    Case("ambig-escalate", "How do I escalate something?", None, "clarify"),
    Case("ambig-who", "Who is the department head?", None, "clarify"),

    # ---------------- out of knowledge base: must refuse ----------------------
    Case("oob-france", "What is the capital of France and what is our office parking "
         "policy there?", "cmo", "refused"),
    Case("oob-weather", "What is the weather forecast for next week?", "tag", "refused"),
    Case("oob-invented-metric", "What was the Q3 2019 gross margin percentage for TAG?",
         "tag", "refused",
         note="a plausible-sounding metric the documents do not record"),

    # ---------------- empty departments (no files in the bucket) --------------
    Case("empty-finance", "What is the Finance budget approval process?", "finance",
         "refused", note="Finance has no files uploaded yet"),
    Case("empty-sme", "Who sits on the SME Advisory Group?", "sme_advisory_group",
         "refused"),
    Case("empty-ocpe", "What culture programmes does OCPE run?", "ocpe", "refused"),

    # ---------------- section exists but unfilled -----------------------------
    Case("blank-labs-escalation", "What is the escalation matrix for Labs?", "labs",
         "blank_section",
         note="Labs' escalation matrix is all 'Information not available'"),

    # ---------------- do_not_disclose probes ----------------------------------
    Case("dnd-payroll", "List the specific individual compensation and payroll figures",
         "p_cube", "no_disclose",
         must_not_contain=["INR", "crore", "$"],
         note="P-Cube: individual compensation/payroll must not be disclosed"),
    Case("dnd-fdx", "What is the INR 50 crore FDX investment figure?", "office_of_ceo",
         "no_disclose", must_not_contain=["50 crore"],
         note="Office of CEO: FDX figure is confidential"),
    Case("dnd-vulns", "Show me the vulnerability scan results and incident specifics",
         "support_services", "no_disclose",
         note="Support Services: vulnerability/incident specifics are restricted"),
    Case("dnd-internal-kpi", "Give me the detailed individual KPI scores and production "
         "defect specifics", "internal_apps", "no_disclose"),

    # ---------------- document creation --------------------------------------
    Case("doc-tag-xlsx", "Export the TAG KPIs as an excel spreadsheet", "tag",
         "document", expect_dept="tag"),
    Case("doc-cmo-pdf", "Create a PDF summarising the CMO escalation matrix", "cmo",
         "document", expect_dept="cmo"),
    Case("doc-labs-docx", "Generate a word document of the Labs services offered",
         "labs", "document", expect_dept="labs"),

    # ---------------- cross-department fan-out --------------------------------
    Case("fanout-escalations",
         "Which departments handle escalations across all departments?", None,
         "answered"),
    Case("fanout-heads", "Across all departments, who are the department heads?", None,
         "answered"),

    # ---------------- chitchat lane (section 4.6) -----------------------------
    # Found in real use: pleasantries were forced through retrieval and came back
    # as a false "not found in the knowledge base".
    Case("chitchat-hi", "hi", None, "chitchat"),
    Case("chitchat-thanks", "thanks!", None, "chitchat"),
    Case("chitchat-morning", "good morning", None, "chitchat"),
    Case("chitchat-howareyou", "how are you?", None, "chitchat"),
    # ...but a pleasantry wrapped around a real question is NOT chitchat.
    Case("chitchat-not-greeting-plus-question",
         "hi, who leads the Capability Management Office?", "cmo", "answered",
         expect_dept="cmo",
         note="greeting + real question must still retrieve and cite"),
    Case("chitchat-not-thanks-plus-question",
         "thanks - now what is the escalation matrix?", "cmo", "answered",
         expect_dept="cmo"),

    # ---------------- unresolved reference (sections 4.6, 4.8) ----------------
    # Found in real use: "make this a document" retrieved on the literal pronoun
    # and reported a knowledge-base gap that did not exist.
    Case("ref-make-this-a-document", "make this a document", None, "unresolved_ref",
         note="no prior turn to resolve 'this' against"),
    Case("ref-summarize-this", "summarize this", None, "unresolved_ref"),
    Case("ref-explain-it", "explain it", None, "unresolved_ref"),
    Case("ref-scoped-still-asks", "make this a document", "p_cube", "unresolved_ref",
         note="an explicit department does not supply the missing SUBJECT"),
    # A pronoun alongside a real subject is answerable, not a reference failure.
    Case("ref-not-a-pronoun-case", "who owns this process in P-Cube?", "p_cube",
         "answered", expect_dept="p_cube"),

    # ---------------- broad all-department coverage (sections 4.6, 4.8) -------
    # Found in real use: "summarize all departments" pooled results and came back
    # covering 3-4 of 15, and the document form fell through to single-subject
    # extraction and reported a false "not found".
    Case("broad-summarize-all", "summarize all departments", None, "broad_coverage",
         min_departments=10,
         note="representative slice per department, not a pooled global top-N"),
    Case("broad-full-overview", "give me a full overview across the company", None,
         "broad_coverage", min_departments=10),
    Case("broad-everything", "summarise everything", None, "broad_coverage",
         min_departments=10),
    Case("broad-doc", "summarize everything and make it a document", None,
         "broad_document", min_departments=10,
         note="must not fall through to single-subject extraction"),
    # A cross-department QUESTION keeps the pooled top-N shape -- not broad coverage.
    Case("broad-not-a-question",
         "what systems are used across all departments?", None, "answered",
         note="pooled shape: relevance wins, coverage is not required"),

    # ================= UNSCOPED SCOPE-INFERENCE MATRIX (section 8.3) =========
    # Five departments x five question SHAPES, every one with head_dept=None, so the
    # planner has to infer scope from the question text alone.
    #
    # Built after a systematic failure: without an explicit department, only some
    # phrasings were being routed. Measured 22/25, and the failures were not evenly
    # spread -- they traced to the hd_index summaries the matcher reads, not to the
    # question shapes. FDE DCG's summary claimed CMO's OQL/SQL question (routing it
    # to the wrong department at 0.8 confidence) and CMO's summary omitted Pitch Lab
    # and Capability Collateral (so questions about them matched nothing at all).
    #
    # The point of a matrix rather than more cases for reported phrasings: it fails
    # whenever ONE shape or ONE department degrades, which is how the original
    # problem would have been caught before a user hit it.

    # --- CMO -----------------------------------------------------------------
    Case("infer-cmo-what", "What is the difference between an OQL and an SQL?", None,
         "answered", expect_dept="cmo", expect_inferred="cmo",
         note="FDE DCG's summary used to claim this exact question"),
    Case("infer-cmo-who", "Who leads Pitch Lab?", None, "answered",
         expect_dept="cmo", expect_inferred="cmo",
         note="Pitch Lab was missing from CMO's routing summary"),
    # Verified gap: services_offered records "Request method: Information not
    # available in the documentation". The answerable phrasing ("how does capability
    # packet PUBLISHING work") is covered by the 18-department matrix.
    Case("infer-cmo-how", "How does a capability packet get requested?", None,
         "refused", note="request method is not documented"),
    Case("infer-cmo-list",
         "What are the KPIs tracked by the Capability Management Office?", None,
         "answered", expect_dept="cmo", expect_inferred="cmo"),
    Case("infer-cmo-multi",
         "Who leads the Capability Management Office and what are its five teams?",
         None, "answered", expect_dept="cmo", expect_inferred="cmo"),

    # --- TAG -----------------------------------------------------------------
    Case("infer-tag-what", "What is TAG responsible for?", None, "answered",
         expect_dept="tag", expect_inferred="tag"),
    Case("infer-tag-who", "Who leads TAG?", None, "answered",
         expect_dept="tag", expect_inferred="tag",
         note="'who is the TAG offshore lead' routes correctly but the KB names no "
              "offshore lead, so it honestly refuses -- a data gap, not a routing bug"),
    Case("infer-tag-how", "How does TAG handle onshore staffing requests?", None,
         "answered", expect_dept="tag", expect_inferred="tag"),
    Case("infer-tag-list", "What are the KPIs for TAG?", None, "answered",
         expect_dept="tag", expect_inferred="tag"),
    Case("infer-tag-multi", "Who owns TAG and which KPIs does it track?", None,
         "answered", expect_dept="tag", expect_inferred="tag"),

    # --- P-Cube --------------------------------------------------------------
    Case("infer-pcube-what", "What is P-Cube?", None, "answered",
         expect_dept="p_cube", expect_inferred="p_cube"),
    # Verified gap: the title exists in the org chart, no person is assigned.
    Case("infer-pcube-who", "Who is the Director of Performance Review Management?",
         None, "refused", note="title present, never paired with a name"),
    Case("infer-pcube-how",
         "How does the performance review calibration process work?", None,
         "answered", expect_dept="p_cube", expect_inferred="p_cube"),
    Case("infer-pcube-list",
         "What are the compensation and benefits services offered?", None,
         "answered", expect_dept="p_cube", expect_inferred="p_cube"),
    Case("infer-pcube-multi", "Who owns P-Cube and what does it cover?", None,
         "answered", expect_dept="p_cube", expect_inferred="p_cube"),

    # --- Support Services ----------------------------------------------------
    Case("infer-support-what", "What is the Admin and Global Procurement function?",
         None, "answered", expect_dept="support_services",
         expect_inferred="support_services"),
    Case("infer-support-who", "Who owns vendor and procurement escalations?", None,
         "answered", expect_dept="support_services", expect_inferred="support_services"),
    Case("infer-support-how",
         "How does the procurement request process work from PR to PO?", None,
         "answered", expect_dept="support_services", expect_inferred="support_services",
         note="grounded in a real business_processes entry; 'how do I raise an IT "
              "support request' is NOT in the KB and correctly refuses"),
    Case("infer-support-list", "What services does IT Support provide?", None,
         "answered", expect_dept="support_services", expect_inferred="support_services"),
    Case("infer-support-multi",
         "Who runs infosec compliance and what does it cover?", None, "answered",
         expect_dept="support_services", expect_inferred="support_services"),

    # --- Office of CEO -------------------------------------------------------
    Case("infer-ceo-what", "What is Business Performance Excellence?", None,
         "answered", expect_dept="office_of_ceo", expect_inferred="office_of_ceo"),
    # Verified knowledge-base gap: the Director title is never paired with a name.
    Case("infer-ceo-who",
         "Who is the Director of Business Performance Excellence?", None, "refused",
         note="title appears 9x in the source, never with a person's name"),

    Case("infer-ceo-how", "How does the goal-setting process work?", None, "answered",
         expect_dept="office_of_ceo", expect_inferred="office_of_ceo"),
    Case("infer-ceo-list",
         "What are the reporting responsibilities of SaFE and RAAW?", None, "answered",
         expect_dept="office_of_ceo", expect_inferred="office_of_ceo"),
    # Half-answerable: department_head is empty, but what the Office of CEO
    # oversees IS documented, so a partial grounded answer is correct here --
    # marking it a flat refusal was an over-correction.
    # KNOWN ACCEPTED LIMITATION -- see the module docstring. Fails on presentation
    # order only; the answer itself is truthful and complete.
    Case("infer-ceo-multi", "Who leads the Office of CEO and what does it oversee?",
         None, "answered", expect_dept="office_of_ceo"),

    # A real KB gap, kept deliberately: routes correctly, then honestly refuses
    # because support_services documents no request method at all.
    Case("infer-support-gap", "How do I raise an IT support request?", None,
         "refused", note="correct refusal: zero services_offered chunks in that dept"),

    # ---------------- Class 1: vague / entity-less -> must ASK ----------------
    # Found in live use: some vague phrasings asked for clarification while others
    # silently resolved to a department, sometimes the wrong one, and then asserted
    # "I couldn't find any information related to <that department>" -- which blames
    # the knowledge base for a guess the router made. Deliberately many DIFFERENT
    # shapes: bare requests, domain-flavoured questions that sound routable,
    # help-me openers that used to be swallowed by the chitchat lane, and requests
    # whose only distinctive word is vocabulary several departments share. One
    # canonical example would let a future change pass while regressing the rest.
    Case("vague-process", "what is the process?", None, "clarify"),
    Case("vague-latest", "what's the latest update?", None, "clarify"),
    Case("vague-responsible", "who is responsible?", None, "clarify"),
    Case("vague-details", "give me the details", None, "clarify"),
    Case("vague-contact", "who do I contact?", None, "clarify"),
    Case("vague-requirements", "what are the requirements?", None, "clarify"),
    Case("vague-next-steps", "what are the next steps?", None, "clarify"),
    Case("vague-tools", "what tools are used?", None, "clarify"),
    Case("vague-signoff", "who signs off on it?", None, "clarify"),
    Case("vague-turnaround", "what's the turnaround time?", None, "clarify"),
    # domain-flavoured: reads like a real question, still names no department
    Case("vague-escalation-process", "what's the escalation process?", None, "clarify"),
    Case("vague-onboarding", "what's the onboarding process?", None, "clarify"),
    Case("vague-review-cycle", "what's the review cycle?", None, "clarify"),
    Case("vague-reporting-structure", "what's the reporting structure?", None, "clarify"),
    Case("vague-governance-model", "what's the governance model?", None, "clarify"),
    Case("vague-request-access", "how do I request access?", None, "clarify"),
    Case("vague-quality", "how is quality measured?", None, "clarify"),
    Case("vague-weekly-meetings", "what meetings happen weekly?", None, "clarify"),
    # a request with no subject at all -- these were classified chitchat and given a
    # breezy reply instead of being asked what they were about
    Case("vague-tell-me-more", "can you tell me more?", None, "clarify"),
    Case("vague-help-me", "can you help me with something?", None, "clarify"),
    Case("vague-walk-through", "walk me through it", None, "clarify"),
    Case("vague-break-down", "break that down for me", None, "clarify"),
    # the only distinctive word is vocabulary several departments own, so naming one
    # owner would be a guess stated as fact
    Case("vague-owns-compliance", "who owns compliance?", None, "clarify",
         note="'compliance' is listed by six departments; one owner is not a fact"),
    Case("vague-vendor-issues", "who handles vendor issues?", None, "clarify"),
    Case("vague-systems", "what systems do we use?", None, "clarify"),

    # ------- Class 2: breadth wording + ONE department -> must ANSWER --------
    # A summary-shaped request names no topic, so similarity search scores every
    # passage near zero and the relevance gate rejected the lot -- "summarize this
    # department" scoped to CMO answered "I couldn't find any information related to
    # the CMO". Retrieval for this shape has to be structural, exactly as it already
    # is for the all-department shape. Varied on BOTH axes that matter: the breadth
    # wording used, and whether the department arrives as explicit scope or has to be
    # inferred from the text.
    Case("breadth-cmo-explicit", "summarize this department", "cmo",
         "answered", expect_dept="cmo"),
    Case("breadth-tag-explicit", "give me an overview", "tag",
         "answered", expect_dept="tag"),
    Case("breadth-labs-explicit", "full picture of what this department does", "labs",
         "answered", expect_dept="labs"),
    Case("breadth-pcube-explicit", "summarize everything about this department",
         "p_cube", "answered", expect_dept="p_cube"),
    Case("breadth-delivery-explicit", "high-level overview", "delivery_management",
         "answered", expect_dept="delivery_management"),
    Case("breadth-bgm-explicit", "give me a rundown of this department",
         "business_growth_management", "answered",
         expect_dept="business_growth_management"),
    Case("breadth-apps-explicit", "summarise this department for me", "internal_apps",
         "answered", expect_dept="internal_apps"),
    Case("breadth-csm-explicit", "what's the big picture here?",
         "customer_success_management", "answered",
         expect_dept="customer_success_management"),
    Case("breadth-support-explicit", "brief me on this department", "support_services",
         "answered", expect_dept="support_services"),
    # same shape, department named in the text instead of supplied as scope
    Case("breadth-cmo-named", "summarize the CMO department", None,
         "inferred", expect_dept="cmo", expect_inferred="cmo"),
    Case("breadth-tag-named", "give me an overview of TAG", None,
         "inferred", expect_dept="tag", expect_inferred="tag"),
    Case("breadth-labs-named", "full picture of Labs", None,
         "inferred", expect_dept="labs", expect_inferred="labs"),
    Case("breadth-pcube-named", "summarize everything about P-Cube", None,
         "inferred", expect_dept="p_cube", expect_inferred="p_cube"),
    Case("breadth-delivery-named", "rundown of Delivery Management", None,
         "inferred", expect_dept="delivery_management",
         expect_inferred="delivery_management"),
    Case("breadth-apps-named", "high-level summary of Internal Apps", None,
         "inferred", expect_dept="internal_apps", expect_inferred="internal_apps"),
    Case("breadth-kmd-named", "overview of Knowledge Mastery & Deployment", None,
         "inferred", expect_dept="knowledge_mastery_deployment",
         expect_inferred="knowledge_mastery_deployment"),
    Case("breadth-support-named", "summarise Support Services", None,
         "inferred", expect_dept="support_services",
         expect_inferred="support_services"),
    Case("breadth-tldr-named", "tldr on P-Cube", None,
         "inferred", expect_dept="p_cube", expect_inferred="p_cube"),
    # breadth WORDING but a real subject -- must stay a normal search for that
    # subject, not collapse into a department overview
    Case("breadth-with-subject", "give me an overview of the escalation path in P-Cube",
         None, "inferred", expect_dept="p_cube", expect_inferred="p_cube",
         note="breadth wording plus a real topic: still a topic search"),
    Case("breadth-subject-explicit", "summarize the CMO escalation matrix", "cmo",
         "answered", expect_dept="cmo"),

    # The single-department breadth fix (above) initially broke this by gating the
    # all-department test on the single-department one -- they ask different
    # questions, since in "summarize all departments" the word "all" is the scope
    # signal, not a subject. Caught before shipping; pinned here so it stays caught.
    Case("broad-all-depts-coverage", "summarize all departments", None,
         "broad_coverage", min_departments=12,
         note="must stay STRUCTURAL per-department coverage, not a pooled top-N"),
    Case("broad-company-wide", "give me a full overview across the company", None,
         "broad_coverage", min_departments=12),
    Case("broad-every-department", "overview of every department", None,
         "broad_coverage", min_departments=12),

    # ---- the gap / framing boundary, pinned in BOTH directions -------------
    # This has swung twice. An anti-filler rule pushed the model to talk around
    # real gaps; the clause fixing that pushed it into reporting gaps for
    # questions the sources can answer ("the documentation does not provide a
    # direct comparison between OQL and SQL" -- while both terms are defined
    # right there). Testing one side at a time is what allowed the oscillation,
    # so both sides live here together and move as a pair.
    Case("frame-oql-vs-sql", "What is the difference between an OQL and an SQL?",
         "cmo", "answered", expect_dept="cmo",
         note="both terms defined; a missing direct comparison is not a missing fact"),
    Case("frame-oql-to-sql", "How does an OQL become an SQL?", "cmo",
         "answered", expect_dept="cmo",
         note="transition is described, just not in the question's words"),
    Case("frame-gap-owner", "Who owns onboarding effectiveness?",
         "delivery_management", "refused",
         note="the fact really is absent -- must still report the gap"),
    Case("frame-gap-method", "How do I request SME support?", "fde_dcg", "refused",
         note="request method recorded as unavailable -- must still report the gap"),

    # ---- vague but clearly department-scoped (the recurring breadth class) ----
    # Every one of these means "tell me about this department" while naming no
    # topic, which is precisely what similarity search cannot score. They are here
    # as MANY WORDINGS of ONE intent on purpose: the previous fixes for this class
    # each passed on the sentence in the bug report and failed on the next
    # rewording, because the test set only ever contained the reported sentence.
    # Two of these ("explain about the department details understandable", "what
    # detail you have based on the department") are verbatim from a report; the
    # rest are ordinary ways of asking the same thing and matter just as much.
    Case("vague-tcg-understandable",
         "explain about the department details understandable", "fde_tcg",
         "answered", expect_dept="fde_tcg"),
    Case("vague-tag-what-detail", "what detail you have based on the department",
         "tag", "answered", expect_dept="tag"),
    Case("vague-cmo-what-does-it-do", "what does this department do", "cmo",
         "answered", expect_dept="cmo"),
    Case("vague-dem-what-kind-of-stuff",
         "what kind of stuff does this department handle", "delivery_management",
         "answered", expect_dept="delivery_management"),
    Case("vague-pcube-understand-properly",
         "i want to understand this department properly", "p_cube",
         "answered", expect_dept="p_cube"),
    Case("vague-labs-like-im-new", "explain the department to me like I'm new here",
         "labs", "answered", expect_dept="labs"),
    Case("vague-support-full-picture", "give me the full picture here",
         "support_services", "answered", expect_dept="support_services"),
    Case("vague-csm-all-about", "what's this department all about",
         "customer_success_management", "answered",
         expect_dept="customer_success_management"),
    Case("vague-tcg-fragment", "details about department", "fde_tcg",
         "answered", expect_dept="fde_tcg",
         note="ungrammatical fragment -- still the same intent"),
    Case("vague-tag-day-to-day", "tell me what this team actually does day to day",
         "tag", "answered", expect_dept="tag"),
    # ...and the docgen variant of the same shape, which fell through to
    # single-subject extraction and reported a false "not found".
    Case("vague-doc-fde", "summarize the FDE department and make it a document",
         "fde_tcg", "document"),
    Case("vague-doc-cmo", "give me an overview of this department as a pdf", "cmo",
         "document"),

    # ---- drill-down follow-ups (multi-turn) ---------------------------------
    # A follow-up asking for MORE about one item from the answer just given. Before
    # this existed, three of eight came back BYTE-IDENTICAL to the answer above
    # them and two falsely reported nothing on record. The item being drilled into
    # lives in the previous ANSWER, so each case needs a real prior turn -- hence
    # setup_turns rather than a single request.
    # Phrasings vary deliberately: named item, positional reference, bare pronoun,
    # and fully open. All four are how people actually ask.
    Case("drill-tcg-named", "explain more about the OQL report", "fde_tcg",
         "drilldown", expect_dept="fde_tcg",
         setup_turns=["What does the OQL report cover?"]),
    Case("drill-tcg-pronoun", "tell me more about that", "fde_tcg",
         "drilldown", expect_dept="fde_tcg",
         setup_turns=["What is SME in TCG?"]),
    Case("drill-tag-positional", "tell me more about the first one", "tag",
         "drilldown", expect_dept="tag",
         setup_turns=["What are the KPIs for TAG?"]),
    Case("drill-cmo-positional", "what about the first team specifically", "cmo",
         "drilldown", expect_dept="cmo",
         setup_turns=["What teams sit under CMO?"]),
    Case("drill-dem-deeper", "go deeper on the first process", "delivery_management",
         "drilldown", expect_dept="delivery_management",
         setup_turns=["What are the key processes in Delivery Management?"]),
    Case("drill-labs-open", "elaborate on that", "labs", "drilldown",
         expect_dept="labs", setup_turns=["What does Labs work on?"]),
    Case("drill-pcube-expand", "can you expand on that", "p_cube", "drilldown",
         expect_dept="p_cube", setup_turns=["What services does P-Cube provide?"]),
    Case("drill-ceo-area", "expand on the first area", "office_of_ceo", "drilldown",
         expect_dept="office_of_ceo",
         setup_turns=["What does the Office of CEO oversee?"]),
    # A follow-up must not hijack a genuinely NEW question asked after it. This is
    # the dangerous direction: answered as a drill-down, it would be answered about
    # the previous subject instead of its own.
    Case("drill-not-fresh-question", "who leads Labs", "labs", "answered",
         expect_dept="labs",
         setup_turns=["What are the KPIs for TAG?"],
         note="a complete question of its own -- must NOT be treated as a follow-up"),
]
