"""Broad all-department coverage + failure disclosure (CLAUDE.md 4.6, 4.8).

Writes NOTHING to production tables (section 8.0) -- it monkeypatches the retrieval
helper in-process and restores it in a finally block.

    python -m tests.test_broad_coverage
"""
from __future__ import annotations

import sys

from groundedness import gate
from planner import planner
from retriever import retriever

failures: list[str] = []


def check(name, ok, detail=""):
    print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f"  -- {detail}" if detail and not ok else ""))
    if not ok:
        failures.append(f"{name}: {detail}")


hds = planner.populated_head_depts()
print(f"populated departments: {len(hds)}")

print("\n### every in-scope department is represented (not a pooled top-N)")
hits, missing = retriever.retrieve_broad("summarize all departments", hds)
covered = {h.head_dept for h in hits}
check("all departments covered", len(covered) == len(hds),
      f"covered {len(covered)} of {len(hds)}: missing {sorted(set(hds) - covered)}")
check("nothing reported unavailable on a healthy run", not missing, str(missing))
per = {hd: sum(1 for h in hits if h.head_dept == hd) for hd in hds}
check("no department is starved", all(v >= 1 for v in per.values()),
      f"zero-chunk departments: {[k for k, v in per.items() if v == 0]}")

print("\n### coverage is stable, not order-dependent")
runs = []
for _ in range(3):
    h2, _m = retriever.retrieve_broad("give me a full overview across the company", hds)
    runs.append(len({x.head_dept for x in h2}))
check("3 consecutive runs cover the same department count",
      len(set(runs)) == 1 and runs[0] == len(hds), f"runs={runs}")

print("\n### a department that cannot be retrieved is DISCLOSED, not dropped")
BROKEN = {"labs", "tag", "p_cube"}
real = retriever._representative_for


def _flaky(hd, keep):
    if hd in BROKEN:
        raise RuntimeError("simulated transient failure")
    return real(hd, keep)


try:
    retriever._representative_for = _flaky
    hits2, missing2 = retriever.retrieve_broad("summarize all departments", hds)
finally:
    retriever._representative_for = real          # guaranteed restore

check("failures survive retry and are reported, not swallowed",
      sorted(missing2) == sorted(BROKEN), f"reported {sorted(missing2)}")
check("the other departments still came through",
      len({h.head_dept for h in hits2}) == len(hds) - len(BROKEN),
      f"covered {len({h.head_dept for h in hits2})}")

ans = gate.generate("summarize all departments", hits2, hds, "any department",
                    multi_department=True, broad_coverage=True,
                    unavailable=sorted(missing2))
check("Answer carries the structured gap list",
      sorted(ans.unavailable_departments) == sorted(BROKEN),
      str(ans.unavailable_departments))
tail = ans.text[-700:].lower()
named = [d for d in ("labs", "tag", "p-cube") if d in tail]
check("the answer TEXT names every uncovered department", len(named) == 3,
      f"named only {named} in: {ans.text[-220:]!r}")
print(f"        disclosure: {ans.text.strip().splitlines()[-1][:160]!r}")

print("\n" + "=" * 78)
print("ALL PASS" if not failures else f"{len(failures)} FAILURE(S)")
for f in failures:
    print("  -", f)
sys.exit(1 if failures else 0)
