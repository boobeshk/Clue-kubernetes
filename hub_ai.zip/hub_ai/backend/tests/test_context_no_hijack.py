"""Regression guard: context resolution must not hijack a self-contained question.

    python -m tests.test_context_no_hijack

planner.depends_on_context decides whether a message leans on earlier turns. It
replaced a regex over a fixed list of referring expressions, which is what let
"above details" and "make the detail as a document" fall through unresolved. The
risk a shape judgement introduces is the opposite one: a brand-new question asked
inside an existing thread must NOT be rewritten to the previous subject.

So this pins both directions:
  * a follow-up that points backwards is resolved against the prior turn
  * a question that names its own subject is answered on its own terms, even when
    the conversation was about something else entirely

Test hygiene (section 8.0): conversations are removed in a finally block.
"""
from __future__ import annotations

import sys
import uuid

from fastapi.testclient import TestClient

import main
from clients import supabase

c = TestClient(main.app)
USER = f"e2e-nohijack-{uuid.uuid4()}"

failures: list[str] = []
created: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f"  -- {detail}" if not ok else ""))
    if not ok:
        failures.append(f"{name}: {detail}")


def new_conversation() -> str:
    cid = c.post("/api/conversations",
                 json={"anon_user_id": USER}).json()["conversation_id"]
    created.append(cid)
    return cid


def ask(query: str, cid: str) -> dict:
    return c.post("/api/chat", json={
        "query": query, "head_dept": None, "session_id": "nohijack",
        "anon_user_id": USER, "conversation_id": cid}).json()


# (opening question, opening department, follow-up, department the follow-up needs)
#
# Every department used here must actually hold chunks. Finance, OCPE and SME
# Advisory Group are empty, so a question about one cannot route to it and would
# fail this test for a reason that has nothing to do with hijacking.
CASES = [
    ("What does the CMO department do?", "cmo",
     "What KPIs does TAG track?", "tag"),
    ("Who leads P-Cube?", "p_cube",
     "What does the CMO department do?", "cmo"),
    ("What is Labs' role, and who leads it?", "labs",
     "Who leads P-Cube?", "p_cube"),
]


def main_run() -> int:
    print("=" * 92)
    print("### a self-contained question is NOT rewritten to the previous subject")
    for opener, opener_dept, follow, want_dept in CASES:
        cid = new_conversation()
        first = ask(opener, cid)
        got_first = first.get("inferred_hd")
        second = ask(follow, cid)
        got = second.get("inferred_hd")
        check(f"{follow!r} after a {opener_dept} thread routes to {want_dept}",
              got == want_dept,
              f"inferred_hd={got} (opener inferred {got_first})")
        check(f"{follow!r} is not reported as an unresolved reference",
              not second.get("unresolved_reference"),
              f"unresolved_reference={second.get('unresolved_reference')}")

    print("\n### a backward-pointing follow-up IS resolved (the other direction)")
    for opener, opener_dept, follow in [
        ("What is Labs' role, and who leads it?", "labs", "above details"),
        ("What does the CMO department do?", "cmo", "make the detail as a document"),
        ("Who leads P-Cube?", "p_cube", "can you explain more about that?"),
    ]:
        cid = new_conversation()
        ask(opener, cid)
        second = ask(follow, cid)
        check(f"{follow!r} resolves against the {opener_dept} thread",
              second.get("inferred_hd") == opener_dept
              and not second.get("needs_clarification"),
              f"inferred_hd={second.get('inferred_hd')} "
              f"clarify={second.get('needs_clarification')}")

    print()
    print("=" * 92)
    if failures:
        print(f"FAILED ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
    else:
        print("ALL PASS")
    return 1 if failures else 0


if __name__ == "__main__":
    try:
        code = main_run()
    finally:
        sb = supabase()
        for cid in created:
            try:
                sb.table("chat_turns").delete().eq("conversation_id", cid).execute()
                sb.table("conversations").delete().eq("id", cid).execute()
            except Exception as exc:      # noqa: BLE001
                print(f"  cleanup warning: {cid} -> {exc}")
        print(f"  cleaned up {len(created)} test conversations")
    sys.exit(code)
