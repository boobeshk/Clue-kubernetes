"""Section 4.13 regression tests: live status, and the safe answer hand-off.

    python -m tests.test_streaming --base http://127.0.0.1:8020

Covers the two properties that matter, and one that turned out to matter more than
expected: the status map and the pipeline must agree on stage NAMES. The first
version of STAGE_LABELS used plausible-looking names ("groundedness.generate",
"groundedness.verify") where the code records "generation" and "verification".
Unlabelled stages are silently skipped, so the two slowest stages in the whole
request emitted nothing and the user watched 16 seconds of dead air with no error
anywhere. A name mismatch cannot be caught by reading either file alone.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from streaming.progress import STAGE_LABELS, describe_stage  # noqa: E402

BACKEND = Path(__file__).resolve().parent.parent

# Every module that can time a pipeline stage. Scanned rather than hand-listed so a
# stage added in a new module is not quietly missed.
STAGE_SOURCES = ["main.py", "groundedness/gate.py", "retriever/retriever.py",
                 "planner/planner.py", "docgen/generator.py", "skills/registry.py",
                 "memory/store.py"]

STAGE_CALL = re.compile(r'(?:sw\.stage|_timed\(sw,)\(?\s*"([a-z_.]+)"')


def real_stage_names() -> set[str]:
    """Stage names the code actually records, read from the source."""
    found: set[str] = set()
    for rel in STAGE_SOURCES:
        path = BACKEND / rel
        if path.exists():
            found |= set(STAGE_CALL.findall(path.read_text(encoding="utf-8")))
    # retriever picks its rerank stage from a variable; both values are literals
    # right above the call, so read them the same way.
    rt = (BACKEND / "retriever/retriever.py").read_text(encoding="utf-8")
    found |= set(re.findall(r'"(rerank\.[a-z]+)"', rt))
    return found


def test_every_real_stage_has_a_label() -> None:
    real = real_stage_names()
    missing = sorted(real - set(STAGE_LABELS))
    assert not missing, (
        f"pipeline records stages with no status label, so they show nothing: "
        f"{missing}")


def test_no_label_names_a_stage_that_does_not_exist() -> None:
    real = real_stage_names()
    invented = sorted(set(STAGE_LABELS) - real)
    assert not invented, (
        f"status labels name stages the pipeline never records: {invented}")


def test_describe_stage_is_silent_for_unknown() -> None:
    assert describe_stage("not.a.real.stage") == ""
    assert describe_stage("planner.routing_log") == ""   # deliberately blank
    assert describe_stage("generation", "5 passages") == \
        "Drafting the answer from the sources (5 passages)"


def stream(base: str, query: str, head_dept: str | None = None):
    body = json.dumps({"query": query, "head_dept": head_dept,
                       "session_id": "sse-test"}).encode()
    req = urllib.request.Request(base + "/api/chat/stream", data=body,
                                 headers={"Content-Type": "application/json"},
                                 method="POST")
    t0 = time.perf_counter()
    out, event, data = [], None, None
    with urllib.request.urlopen(req, timeout=300) as resp:
        for raw in resp:
            line = raw.decode("utf-8").rstrip("\r\n")
            if line.startswith("event: "):
                event = line[7:]
            elif line.startswith("data: "):
                data = line[6:]
            elif line == "" and event:
                out.append((round(time.perf_counter() - t0, 2), event, json.loads(data)))
                event, data = None, None
    return out


def test_live_stream(base: str) -> None:
    events = stream(base, "What are the KPIs for TAG?")
    statuses = [(t, d["stage"], d["message"]) for t, e, d in events if e == "status"]
    done = [d for _, e, d in events if e == "done"]

    assert len(done) == 1, f"expected exactly one done event, got {len(done)}"
    body = done[0]
    assert statuses, "no status events were streamed"

    # status must precede the answer, and describe real work
    answer_at = [t for t, e, _ in events if e == "done"][0]
    assert answer_at > statuses[-1][0], "answer did not arrive after the last status"
    ran = {k for k in (body.get("timing") or {}) if not k.startswith("_")}
    named = {s for _, s, _ in statuses}
    assert not (named - ran), f"status named stages that never ran: {sorted(named - ran)}"

    # the two expensive stages must actually be reported -- this is the regression
    for required in ("generation", "verification"):
        if required in ran:
            assert required in named, (
                f"{required} ran but was never reported to the user")

    # THE ANSWER IS NEVER STREAMED IN PIECES (section 4.13)
    answer = body.get("answer") or ""
    assert answer, "done event carried no answer"
    for _, _, msg in statuses:
        assert msg not in answer or len(msg) < 8, \
            f"answer text leaked into a status message: {msg!r}"
    assert not any(e == "answer_chunk" for _, e, _ in events), \
        "the answer must not be streamed incrementally"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=None,
                    help="run the live stream test against this server too")
    args = ap.parse_args()

    tests = [("every real stage has a status label", test_every_real_stage_has_a_label),
             ("no label names a non-existent stage", test_no_label_names_a_stage_that_does_not_exist),
             ("describe_stage is silent for unknown stages", test_describe_stage_is_silent_for_unknown)]
    if args.base:
        tests.append(("live SSE stream behaves per 4.13",
                      lambda: test_live_stream(args.base)))

    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"  PASS  {name}")
        except AssertionError as exc:
            failed += 1
            print(f"  FAIL  {name}\n          {exc}")
    print(f"\n{len(tests) - failed}/{len(tests)} streaming tests passed")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
