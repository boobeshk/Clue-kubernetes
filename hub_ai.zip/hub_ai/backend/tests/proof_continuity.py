"""Conversation-continuity PROOF (CLAUDE.md 4.11 verification requirement).

Section 4.11 requires evidence, not a description: several real HTTP requests in
sequence, each reusing the same conversation_id, and a later answer that demonstrably
depends on an earlier turn. This prints the transcript AND the server-side rows.

    python -m tests.proof_continuity
"""
from __future__ import annotations

import sys
import textwrap
import uuid

# Windows consoles default to cp1252; knowledge-base text contains characters
# like the >= sign, which would crash the transcript print rather than the code.
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

from fastapi.testclient import TestClient

import main
from clients import supabase

c = TestClient(main.app)
sb = supabase()
USER = f"proof-{uuid.uuid4()}"
failures = []

print("=" * 100)
print("CONVERSATION CONTINUITY PROOF")
print("=" * 100)

convo = c.post("/api/conversations", json={"anon_user_id": USER}).json()["conversation_id"]
print(f"conversation_id issued by POST /api/conversations : {convo}")
print(f"anon_user_id                                      : {USER}\n")

TURNS = [
    ("What does P-Cube cover?", "p_cube"),
    ("who owns it?", None),
    ("and what are its KPIs?", None),
    ("make this a document", None),
]

sent_ids = []
for i, (q, hd) in enumerate(TURNS, 1):
    payload = {"query": q, "head_dept": hd, "session_id": "proof",
               "anon_user_id": USER, "conversation_id": convo}
    sent_ids.append(payload["conversation_id"])
    d = c.post("/api/chat", json=payload).json()
    doc = d.get("document")
    print(f"--- REQUEST {i} -------------------------------------------------------")
    print(f"  POST /api/chat  conversation_id={payload['conversation_id']}")
    print(f"  query      : {q!r}   head_dept={hd!r}")
    print(f"  lane={d.get('lane')}  inferred_hd={d.get('inferred_hd')}  "
          f"grounded={d.get('grounded')}  clarify={d.get('needs_clarification')}")
    print(f"  sources    : {sorted({s['head_dept'] for s in (d.get('sources') or [])})}")
    if doc:
        print(f"  document   : {doc['filename']}")
    print(textwrap.indent(textwrap.fill(d.get("answer", "")[:420], 92), "  | "))
    print()

print("=" * 100)
print("EVIDENCE 1 - every request carried the SAME conversation_id")
print(f"  ids sent: {sent_ids}")
same = len(set(sent_ids)) == 1 and sent_ids[0] == convo
print(f"  distinct ids: {len(set(sent_ids))}  ->  {'PASS' if same else 'FAIL'}")
if not same:
    failures.append("conversation_id changed across requests")

print("\nEVIDENCE 2 - server-side chat_turns rows for that conversation")
rows = (sb.table("chat_turns").select("role,content,head_dept,sources,created_at")
        .eq("conversation_id", convo).order("created_at").execute().data or [])
print(f"  chat_turns rows persisted: {len(rows)} (expect {len(TURNS) * 2})")
for r in rows:
    print(f"    [{r['created_at'][11:19]}] {r['role']:<9} hd={str(r['head_dept']):<8} "
          f"{r['content'][:66]!r}")
if len(rows) != len(TURNS) * 2:
    failures.append(f"expected {len(TURNS)*2} turns, found {len(rows)}")

print("\nEVIDENCE 3 - a later answer DEPENDS on an earlier turn")
# Turn 2 says "it" and turn 3 says "its"; neither names P-Cube. If continuity were
# broken they could not resolve, which is exactly the reported bug.
t2 = rows[3]["content"] if len(rows) > 3 else ""
t3 = rows[5]["content"] if len(rows) > 5 else ""
# Assert STRUCTURALLY: the turn resolved to P-Cube sources even though its query
# names no department. Matching on the word "P-Cube" appearing in the prose is
# brittle -- a correct KPI list can answer without repeating the department name.
for idx, (label, turn_q) in enumerate((("turn 2", "who owns it?"),
                                       ("turn 3", "and what are its KPIs?")), start=1):
    row = rows[idx * 2 + 1] if len(rows) > idx * 2 + 1 else {}
    text = row.get("content", "")
    srcs = {s.get("head_dept") for s in (row.get("sources") or [])}
    resolved = row.get("head_dept") == "p_cube" or srcs == {"p_cube"}
    print(f"  {label} {turn_q!r} -> resolved to P-Cube: {'PASS' if resolved else 'FAIL'}"
          f"  (turn head_dept={row.get('head_dept')!r}, sources={sorted(srcs)})")
    print(f"        {text[:130]!r}")
    if not resolved:
        failures.append(f"{label} did not resolve its pronoun to P-Cube")

print("\nEVIDENCE 4 - routing_log shows the same query sequence server-side")
rl = (sb.table("routing_log").select("query,resolved_head_depts,task_lane,created_at")
      .order("created_at", desc=True).limit(len(TURNS)).execute().data or [])
for r in reversed(rl):
    print(f"    [{r['created_at'][11:19]}] lane={r['task_lane']:<10} "
          f"hds={r['resolved_head_depts']}  {r['query'][:50]!r}")

c.request("DELETE", f"/api/conversations/{convo}")
print("\n" + "=" * 100)
print("PROOF RESULT:", "ALL EVIDENCE PASSES" if not failures else f"{len(failures)} FAILURE(S)")
for f in failures:
    print("  -", f)
sys.exit(1 if failures else 0)
