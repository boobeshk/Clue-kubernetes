"""Full 18-department diagnostic matrix (CLAUDE.md section 8.3).

Five question SHAPES per department plus two document-generation cases, driven from
entities that actually exist in each department's indexed content -- the questions
were derived from documents.metadata labels, not invented, so a refusal here means a
real failure rather than a question the knowledge base was never able to answer.

For the 15 POPULATED departments the question avoids the head department's own display
name wherever the data allows, so scope must be inferred from a sub-entity (a team,
function, process or KPI). `names_hd` marks the few where the entity unavoidably
contains it (e.g. Solution Labs under the "Labs" department).

The 3 EMPTY departments (Finance, SME Advisory Group, OCPE) DO name themselves -- with
no content there is no sub-entity to name, and the property under test is that they
refuse rather than silently mis-routing to a populated department.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class MatrixCase:
    dept: str
    shape: str            # what_is | who | how_do_i | list | multi_fact
    query: str
    expect: str = "answered"      # answered | refused | no_record
    names_hd: bool = False


@dataclass
class DocCase:
    dept: str
    mode: str             # explicit | inferred
    query: str
    head_dept: str | None


POPULATED = [
    "business_growth_management", "business_growth_support", "cmo",
    "customer_success_management", "delivery_management", "fde_dcg", "fde_tcg",
    "holding_co_family_office_management", "internal_apps",
    "knowledge_mastery_deployment", "labs", "office_of_ceo", "p_cube",
    "support_services", "tag",
]
EMPTY = ["finance", "sme_advisory_group", "ocpe"]

Q: list[MatrixCase] = [
    MatrixCase("business_growth_management", "what_is", "What is the Prototype Lab?"),
    MatrixCase("business_growth_management", "who", "Who owns Net New Farming Hunting?"),
    MatrixCase("business_growth_management", "how_do_i", "How does the RFP build process work?"),
    MatrixCase("business_growth_management", "list", "What are the KPIs for Revenue Strategy?"),
    MatrixCase("business_growth_management", "multi_fact", "Who leads Lead Gen and what does it cover?"),

    MatrixCase("business_growth_support", "what_is", "What is the Creatives Team?"),
    MatrixCase("business_growth_support", "who", "Who owns Creative Intake and Governance?"),
    MatrixCase("business_growth_support", "how_do_i", "How does the demand intake process work?"),
    MatrixCase("business_growth_support", "list", "What are the KPIs for the Creatives Team?"),
    MatrixCase("business_growth_support", "multi_fact", "Who runs Employer Branding and what does it include?"),

    MatrixCase("cmo", "what_is", "What is the difference between an OQL and an SQL?"),
    MatrixCase("cmo", "who", "Who leads Pitch Lab?"),
    MatrixCase("cmo", "how_do_i", "How does capability packet publishing work?"),
    MatrixCase("cmo", "list", "What are the KPIs for Pitch Lab?"),
    MatrixCase("cmo", "multi_fact", "Who leads Capability Marketing and what does it do?"),

    MatrixCase("customer_success_management", "what_is", "What is Chronicle AI used for?"),
    MatrixCase("customer_success_management", "who", "Who owns pipeline health monitoring?"),
    MatrixCase("customer_success_management", "how_do_i", "How does CSAT health escalation work?"),
    MatrixCase("customer_success_management", "list", "What KPIs are tracked for customer visits?"),
    MatrixCase("customer_success_management", "multi_fact", "Who owns KEBS data capture and what does it involve?"),

    MatrixCase("delivery_management", "what_is", "What is CM% margin achievement?"),
    # business_processes."Resource & Skill Readiness" has
    # "Process owner: Information not available in the documentation".
    MatrixCase("delivery_management", "who", "Who owns resource and skill readiness?", "no_record"),
    MatrixCase("delivery_management", "how_do_i", "How does milestone and deliverable predictability governance work?"),
    MatrixCase("delivery_management", "list", "What are the KPIs for customer engagement and satisfaction?"),
    # Same: "Onboarding Effectiveness" records no process owner.
    MatrixCase("delivery_management", "multi_fact", "Who owns onboarding effectiveness and what does it measure?", "no_record"),

    MatrixCase("fde_dcg", "what_is", "What is the Domain Consulting Group?"),
    # DCG documents no leader at all: department_head and leadership_team are both
    # empty and the source notes the cover-page name is "not explicitly confirmed".
    # Correct behaviour is to say so, not to name someone.
    MatrixCase("fde_dcg", "who", "Who leads the Domain Consulting Group?", "no_record"),
    # services_offered records "Request method: Information not available in the
    # documentation" for both DCG services -- there is no request method to report.
    MatrixCase("fde_dcg", "how_do_i", "How do I request SME support?", "no_record"),
    MatrixCase("fde_dcg", "list", "What functions does the Domain Consulting Group cover?"),
    MatrixCase("fde_dcg", "multi_fact", "Who leads Domain Consulting and what are its key activities?"),

    MatrixCase("fde_tcg", "what_is", "What is the Technology Consulting Group?"),
    MatrixCase("fde_tcg", "who", "Who leads the Technology Consulting Group?"),
    MatrixCase("fde_tcg", "how_do_i", "How is SME utilization reported?"),
    MatrixCase("fde_tcg", "list", "What reports does the Technology Consulting Group produce?"),
    MatrixCase("fde_tcg", "multi_fact", "Who leads Technology Consulting and what does it deliver?"),

    MatrixCase("holding_co_family_office_management", "what_is", "What is the Family Office Manager role?"),
    MatrixCase("holding_co_family_office_management", "who", "Who is the Family Office Manager?"),
    MatrixCase("holding_co_family_office_management", "how_do_i", "How does the quarterly net worth assessment work?"),
    MatrixCase("holding_co_family_office_management", "list", "What are the KPIs for portfolio performance?"),
    MatrixCase("holding_co_family_office_management", "multi_fact", "Who handles annual tax return filing and what does it involve?"),

    MatrixCase("internal_apps", "what_is", "What is Business Excellence internal applications development?"),
    MatrixCase("internal_apps", "who", "Who owns QA and change management?"),
    MatrixCase("internal_apps", "how_do_i", "How does SDLC sprint execution work?"),
    MatrixCase("internal_apps", "list", "What are the KPIs for project delivery timeliness?"),
    MatrixCase("internal_apps", "multi_fact", "Who owns requirements gathering and what does it produce?"),

    MatrixCase("knowledge_mastery_deployment", "what_is", "What is the Forward Deployment Expert programme?"),
    # "Mentors / SMEs" exists only as a ROLE in the org structure; no person is
    # designated a mentor in the contact directory.
    MatrixCase("knowledge_mastery_deployment", "who", "Who are the mentors in the FDE programme?", "no_record"),
    MatrixCase("knowledge_mastery_deployment", "how_do_i", "How does at-risk learner intervention work?"),
    MatrixCase("knowledge_mastery_deployment", "list", "What are the WIGs for platform readiness and cohort onboarding?"),
    MatrixCase("knowledge_mastery_deployment", "multi_fact", "Who runs capability readiness and what does it cover?"),

    MatrixCase("labs", "what_is", "What is Solution Labs?", names_hd=True),
    MatrixCase("labs", "who", "Who leads Solution Labs?", names_hd=True),
    MatrixCase("labs", "how_do_i", "How does accelerator development work?"),
    MatrixCase("labs", "list", "What functions does Solution Labs cover?", names_hd=True),
    MatrixCase("labs", "multi_fact", "Who leads multi-cloud engineering and what does it involve?"),

    MatrixCase("office_of_ceo", "what_is", "What is Business Performance Excellence?"),
    # The title "Director, Business Performance Excellence" appears 9 times in the
    # source but is never paired with a person; the one contact record has
    # "Designation: Information not available". Correct answer is to say so.
    MatrixCase("office_of_ceo", "who", "Who is the Director of Business Performance Excellence?", "no_record"),
    MatrixCase("office_of_ceo", "how_do_i", "How does the goal-setting process work?"),
    MatrixCase("office_of_ceo", "list", "What are the reporting responsibilities of SaFE and RAAW?"),
    MatrixCase("office_of_ceo", "multi_fact", "Who owns year-end assessment and calibration and what does it involve?"),

    MatrixCase("p_cube", "what_is", "What is the Reward Council Review?"),
    # The org chart lists the TITLE "Director, Performance Review Management" but no
    # person is assigned to it -- the contact directory names only HR Ops roles.
    MatrixCase("p_cube", "who", "Who is the Director of Performance Review Management?", "no_record"),
    MatrixCase("p_cube", "how_do_i", "How does the off-cycle adjustment protocol work?"),
    MatrixCase("p_cube", "list", "What are the compensation and benefits services offered?"),
    MatrixCase("p_cube", "multi_fact", "Who owns variable pay design and what does it cover?"),

    MatrixCase("support_services", "what_is", "What is the Admin and Global Procurement function?"),
    MatrixCase("support_services", "who", "Who owns vendor and procurement escalations?"),
    MatrixCase("support_services", "how_do_i", "How does the procurement request process work from PR to PO?"),
    MatrixCase("support_services", "list", "What services does IT Support provide?"),
    MatrixCase("support_services", "multi_fact", "Who runs infosec compliance and what does it cover?"),

    MatrixCase("tag", "what_is", "What is the Talent Acquisition Group responsible for?", names_hd=True),
    MatrixCase("tag", "who", "Who leads the US Onshore hiring team?"),
    MatrixCase("tag", "how_do_i", "How does external hiring fulfillment work from RMG handoff to DOJ?"),
    MatrixCase("tag", "list", "What are the fulfillment SLAs for offshore hiring?"),
    MatrixCase("tag", "multi_fact", "Who owns vendor path routing and what does it involve?"),

    # ---- EMPTY departments: must refuse, never mis-route to a populated one ----
    MatrixCase("finance", "what_is", "What does the Finance department own?", "refused", True),
    MatrixCase("finance", "who", "Who is the Finance controller?", "refused", True),
    MatrixCase("finance", "how_do_i", "How does the Finance month-end close process work?", "refused", True),
    MatrixCase("finance", "list", "What are the Finance department KPIs?", "refused", True),
    MatrixCase("finance", "multi_fact", "Who leads Finance and what does it cover?", "refused", True),

    MatrixCase("sme_advisory_group", "what_is", "What is the SME Advisory Group?", "refused", True),
    MatrixCase("sme_advisory_group", "who", "Who sits on the SME Advisory Group?", "refused", True),
    MatrixCase("sme_advisory_group", "how_do_i", "How does the SME Advisory Group review process work?", "refused", True),
    MatrixCase("sme_advisory_group", "list", "What are the SME Advisory Group KPIs?", "refused", True),
    MatrixCase("sme_advisory_group", "multi_fact", "Who chairs the SME Advisory Group and what does it advise on?", "refused", True),

    MatrixCase("ocpe", "what_is", "What is Organizational Culture and People Experience?", "refused", True),
    MatrixCase("ocpe", "who", "Who leads Organizational Culture and People Experience?", "refused", True),
    MatrixCase("ocpe", "how_do_i", "How does the OCPE engagement survey process work?", "refused", True),
    MatrixCase("ocpe", "list", "What culture programmes does OCPE run?", "refused", True),
    MatrixCase("ocpe", "multi_fact", "Who owns OCPE and what programmes does it run?", "refused", True),
]

DOCS: list[DocCase] = [
    DocCase("business_growth_management", "explicit", "Create a PDF summarising the BGM governance function", "business_growth_management"),
    DocCase("business_growth_management", "inferred", "Create a PDF summarising the Prototype Lab and Net New Farming Hunting", None),
    DocCase("business_growth_support", "explicit", "Create a PDF summarising the creative intake and governance process", "business_growth_support"),
    DocCase("business_growth_support", "inferred", "Create a PDF summarising the Creatives Team collateral design work", None),
    DocCase("cmo", "explicit", "Create a PDF summarising the CMO escalation matrix", "cmo"),
    DocCase("cmo", "inferred", "Create a PDF summarising Pitch Lab and OQL generation", None),
    DocCase("customer_success_management", "explicit", "Create a PDF summarising pipeline health monitoring", "customer_success_management"),
    DocCase("customer_success_management", "inferred", "Create a PDF summarising KEBS and Chronicle AI data capture", None),
    DocCase("delivery_management", "explicit", "Create a PDF summarising delivery governance", "delivery_management"),
    DocCase("delivery_management", "inferred", "Create a PDF summarising onboarding effectiveness and resource readiness", None),
    DocCase("fde_dcg", "explicit", "Create a PDF summarising the delivery support function", "fde_dcg"),
    DocCase("fde_dcg", "inferred", "Create a PDF summarising the Domain Consulting Group functions", None),
    DocCase("fde_tcg", "explicit", "Create a PDF summarising the growth function", "fde_tcg"),
    DocCase("fde_tcg", "inferred", "Create a PDF summarising the Technology Consulting Group reports", None),
    DocCase("holding_co_family_office_management", "explicit", "Create a PDF summarising the quarterly net worth assessment", "holding_co_family_office_management"),
    DocCase("holding_co_family_office_management", "inferred", "Create a PDF summarising the Family Office Manager mandate", None),
    DocCase("internal_apps", "explicit", "Create a PDF summarising the QA and change management function", "internal_apps"),
    DocCase("internal_apps", "inferred", "Create a PDF summarising Business Excellence internal application development", None),
    DocCase("knowledge_mastery_deployment", "explicit", "Create a PDF summarising capability readiness", "knowledge_mastery_deployment"),
    DocCase("knowledge_mastery_deployment", "inferred", "Create a PDF summarising the Forward Deployment Expert programme WIGs", None),
    DocCase("labs", "explicit", "Create a PDF summarising accelerator development", "labs"),
    DocCase("labs", "inferred", "Create a PDF summarising Solution Labs multi-cloud engineering", None),
    DocCase("office_of_ceo", "explicit", "Create a PDF summarising the goal setting framework", "office_of_ceo"),
    DocCase("office_of_ceo", "inferred", "Create a PDF summarising Business Performance Excellence governance", None),
    DocCase("p_cube", "explicit", "Create a PDF summarising the annual compensation cycle", "p_cube"),
    DocCase("p_cube", "inferred", "Create a PDF summarising the Reward Council Review and variable pay design", None),
    DocCase("support_services", "explicit", "Create a PDF summarising vendor management", "support_services"),
    DocCase("support_services", "inferred", "Create a PDF summarising the PR to PO procurement request process", None),
    DocCase("tag", "explicit", "Create a PDF summarising demand fulfillment", "tag"),
    DocCase("tag", "inferred", "Create a PDF summarising the Talent Acquisition Group offshore fulfillment SLAs", None),
]
