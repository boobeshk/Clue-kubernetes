"""Skill lane + lane-reporting regression (CLAUDE.md 4.9, 4.10).

Creates a skill, asserts routing, then DELETES it. Earlier ad-hoc testing left three
copies of a test skill in the live database; its broad trigger keywords
("briefing", "overview of") then captured ordinary questions into the skill lane, so
plain retrieval answers were badged "skill". Any test that writes to the skills table
must clean up after itself.

    python -m tests.test_skills
"""
from __future__ import annotations

import sys
import uuid

from fastapi.testclient import TestClient

import main
from clients import supabase

c = TestClient(main.app)
failures: list[str] = []
created: list[str] = []


def check(name, ok, detail=""):
    print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f"  -- {detail}" if detail and not ok else ""))
    if not ok:
        failures.append(f"{name}: {detail}")


def ask(q, hd=None):
    return c.post("/api/chat", json={"query": q, "head_dept": hd,
                                     "session_id": "skills-test"}).json()


try:
    sb = supabase()
    pre = sb.table("skills").select("id").execute().data or []
    print(f"skills in DB before: {len(pre)}")

    print("\n### with NO skills registered, nothing may be badged 'skill'")
    d = ask("Give me an overview of Labs", "labs")
    check("overview question -> retrieval, not skill", d.get("lane") != "skill",
          f"lane={d.get('lane')!r} skill={d.get('skill')!r}")

    print("\n### register a narrowly-triggered skill")
    marker = uuid.uuid4().hex[:8]
    r = c.post("/api/skills/upload", json={
        "name": f"Escalation Ladder {marker}",
        "description": f"Renders a department's escalation ladder as numbered levels. "
                       f"Only for requests using the exact phrase 'escalation ladder {marker}'.",
        "trigger_keywords": [f"escalation ladder {marker}"],
        "instructions_md": "List escalation levels as '1.', '2.', '3.' with the owner "
                           "of each. If a level is not recorded, say so.",
    })
    check("skill created", r.status_code == 200, r.text)
    created.append(r.json()["id"])

    print("\n### the lane badge must match what actually served")
    d = ask(f"show me the escalation ladder {marker} for CMO", "cmo")
    served_by_skill = bool(d.get("skill"))
    check("skill-triggering request reports lane=skill",
          d.get("lane") == "skill" and served_by_skill,
          f"lane={d.get('lane')!r} skill={d.get('skill')!r}")
    check("lane and skill field agree",
          (d.get("lane") == "skill") == served_by_skill,
          f"lane={d.get('lane')!r} but skill={d.get('skill')!r}")

    d = ask("Who leads the Capability Management Office?", "cmo")
    check("plain question still reports lane=retrieval",
          d.get("lane") == "retrieval" and not d.get("skill"),
          f"lane={d.get('lane')!r} skill={d.get('skill')!r}")

    print("\n### routing_log records the SERVING lane, not the classifier's guess")
    rows = (sb.table("routing_log").select("query,task_lane")
            .order("created_at", desc=True).limit(6).execute().data or [])
    row = next((x for x in rows if "Capability Management Office" in (x["query"] or "")), None)
    check("routing_log lane for the plain question is retrieval",
          row is not None and row["task_lane"] == "retrieval",
          f"logged {row['task_lane']!r}" if row else "row not found")

finally:
    for sid in created:
        supabase().table("skills").delete().eq("id", sid).execute()
    left = supabase().table("skills").select("id").execute().data or []
    print(f"\ncleanup: removed {len(created)}; skills remaining: {len(left)}")
    if left:
        failures.append(f"cleanup left {len(left)} skill(s) behind")

print("\n" + "=" * 70)
print("ALL PASS" if not failures else f"{len(failures)} FAILURE(S)")
for f in failures:
    print(f"  - {f}")
sys.exit(1 if failures else 0)
