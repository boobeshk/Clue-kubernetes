"""Browser-level sweep across all 18 departments (CLAUDE.md 8.1 + 8.3).

Drives the real UI the way a person does -- opens the department, types into the chat
box, submits, and reads the RENDERED answer -- rather than calling the API. Asserts on
what is actually on screen: answer text, citation badge, inferred-HD badge, lane badge,
and for docgen a download link whose data-URI decodes to a real file.

    python -m tests.e2e.test_all_departments --base http://127.0.0.1:8003
    python -m tests.e2e.test_all_departments --dept cmo --headed
    python -m tests.e2e.test_all_departments --mode mention

Modes:
  sidebar   open the department from the sidebar / Apps overlay, then ask unscoped
            questions in that department's own thread
  mention   ask from the HOME thread using @<Department>, testing mention scoping
  docgen    both document-generation cases per department

Failures write a screenshot and the browser console log to artifacts/.
"""
from __future__ import annotations

import argparse
import base64
import json
import re
import socket
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ingestion.hd_map import display_name                      # noqa: E402
from tests.matrix_18 import DOCS, EMPTY, POPULATED, Q          # noqa: E402
# ONE definition of what counts as a documentation gap, shared with the API
# judge. Three harnesses each carrying their own regex is how the same
# response ended up scored differently depending on which one ran it.
from tests.run_matrix_18 import is_gap_report                  # noqa: E402

HERE = Path(__file__).resolve().parent
ARTIFACTS = HERE / "artifacts"

ANSWER = '[data-testid="bot-answer"]'
SOURCES = '[data-testid="sources"]'
INFERRED = '[data-testid="badge-inferred"]'
LANE = '[data-testid="badge-lane"]'
DOWNLOAD = '[data-testid="doc-download"]'
ANSWER_TIMEOUT = 180_000

PDF = b"%PDF"
ZIP = bytes([0x50, 0x4B, 0x03, 0x04])


class Fail(Exception):
    pass


class UI:
    def __init__(self, page, base):
        self.page, self.base = page, base
        self.console: list[str] = []
        page.on("console", lambda m: self.console.append(f"[{m.type}] {m.text}"))
        page.on("pageerror", lambda e: self.console.append(f"[pageerror] {e}"))

    def reset(self):
        self.console.clear()
        self.page.goto(self.base, wait_until="domcontentloaded")

    def open_department(self, slug, name):
        """Sidebar shows 5; everything else via the Apps overlay grid."""
        item = self.page.locator(f'.app-item:has-text("{name}")').first
        if item.count() and item.is_visible():
            item.click()
        else:
            self.page.click('button.nav-item:has-text("Apps")')
            self.page.wait_for_selector("#appsOverlay.active")
            self.page.locator(f'.apps-card:has-text("{name}")').first.click()
        self.page.wait_for_selector(f"#view-{slug}.active, #thread-{slug}.active")

    def ask_in_department(self, slug, text):
        before = self.page.locator(f"#thread-inner-{slug} {ANSWER}").count()
        box = self.page.locator(f"#empty-input-{slug}")
        if not box.is_visible():
            box = self.page.locator(f"#input-{slug}")
        box.fill(text)
        box.press("Enter")
        self.page.wait_for_function(
            f'() => document.querySelectorAll("#thread-inner-{slug} '
            f'[data-testid=\\"bot-answer\\"]").length > {before}',
            timeout=ANSWER_TIMEOUT)
        return f"#thread-inner-{slug}"

    def ask_home(self, text):
        before = self.page.locator(f"#thread-inner-home {ANSWER}").count()
        box = self.page.locator("#homeInput")
        if not box.is_visible():
            box = self.page.locator("#homeComposerInput")
        box.fill(text)
        box.press("Enter")
        self.page.wait_for_function(
            '() => document.querySelectorAll("#thread-inner-home '
            '[data-testid=\\"bot-answer\\"]").length > %d' % before,
            timeout=ANSWER_TIMEOUT)
        return "#thread-inner-home"

    def rendered(self, container):
        el = self.page.locator(f"{container} {ANSWER}").last
        return el.inner_text().strip()

    def last(self, container, sel):
        loc = self.page.locator(f"{container} {sel}")
        return loc.last if loc.count() else None

    def shot(self, slug_name):
        ARTIFACTS.mkdir(parents=True, exist_ok=True)
        s = re.sub(r"[^a-z0-9]+", "-", slug_name.lower()).strip("-")[:70]
        png, log = ARTIFACTS / f"{s}.png", ARTIFACTS / f"{s}.console.txt"
        try:
            self.page.screenshot(path=str(png), full_page=True)
        except Exception:
            png = None
        log.write_text("\n".join(self.console) or "(no console output)", encoding="utf-8")
        return png, log


REFUSAL = re.compile(r"could ?n.t find|do ?n.t have|does not (record|cover)|"
                     r"not record|no information", re.I)


def check_answer(ui, container, case, expect_inferred):
    """Assert on RENDERED output for one question."""
    text = ui.rendered(container)
    if "Couldn't reach the knowledge base" in text:
        raise Fail(f"frontend could not reach the API: {text[:120]}")
    if not text:
        raise Fail("empty answer rendered")

    lane = ui.last(container, LANE)
    lane_txt = lane.inner_text().strip() if lane and lane.count() else None
    src = ui.last(container, SOURCES)
    src_txt = src.inner_text() if src and src.count() else ""

    if case.expect == "refused":
        if not (REFUSAL.search(text) or "specify" in text.lower()
                or "which department" in text.lower()):
            raise Fail(f"empty department did not refuse: {text[:140]!r}")
        if re.search(r"\.json", src_txt):
            raise Fail(f"empty department returned citations: {src_txt[:100]!r}")
        return f"refused on screen, no citations"

    if case.expect == "no_record":
        if not is_gap_report(text):
            raise Fail(f"did not report the documentation gap: {text[:140]!r}")
        return "reported the gap on screen"

    # expect == answered
    if is_gap_report(text) or REFUSAL.search(text):
        raise Fail(f"refused instead of answering: {text[:140]!r}")
    if not src or not src.count():
        raise Fail(f"no citation rendered. answer={text[:140]!r}")
    if not re.search(r"\.json", src_txt):
        raise Fail(f"citation names no source file: {src_txt[:110]!r}")
    want = display_name(case.dept)
    if want not in src_txt:
        raise Fail(f"citation is not from {want}: {src_txt[:130]!r}")
    if lane_txt != "retrieval":
        raise Fail(f"lane badge is {lane_txt!r}, expected 'retrieval'")
    inf = ui.last(container, INFERRED)
    if expect_inferred:
        if not inf or not inf.count():
            raise Fail("inferred-HD badge missing on an unscoped question")
        if want not in inf.inner_text():
            raise Fail(f"inferred badge names {inf.inner_text()!r}, expected {want}")
    return f"answered, cited {want}" + (", inferred badge shown" if expect_inferred else "")


def check_doc(ui, container, case):
    text = ui.rendered(container)
    lane = ui.last(container, LANE)
    lane_txt = lane.inner_text().strip() if lane and lane.count() else None
    if lane_txt != "docgen":
        raise Fail(f"lane badge is {lane_txt!r}, expected 'docgen'. answer={text[:120]!r}")
    link = ui.last(container, DOWNLOAD)
    if not link or not link.count():
        raise Fail(f"no download link rendered. answer={text[:140]!r}")
    href = link.get_attribute("href") or ""
    if not href.startswith("data:"):
        raise Fail(f"download href is not a data URI: {href[:60]!r}")
    raw = base64.b64decode(href.split(",", 1)[1])
    if raw[:4] not in (PDF, ZIP) or len(raw) < 800:
        raise Fail(f"download is not a real file ({len(raw)}b, magic {raw[:4]!r})")
    name = link.get_attribute("download") or ""
    src = ui.last(container, SOURCES)
    src_txt = src.inner_text() if src and src.count() else ""
    want = display_name(case.dept)
    if want not in src_txt:
        raise Fail(f"document not grounded in {want}: {src_txt[:120]!r}")
    return f"{name} ({len(raw)}b) grounded in {want}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8003")
    ap.add_argument("--mode", choices=["sidebar", "mention", "docgen", "all"], default="all")
    ap.add_argument("--dept", default=None)
    ap.add_argument("--headed", action="store_true")
    ap.add_argument("--out", default="ui_results.json")
    args = ap.parse_args()

    results = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=not args.headed)
        ctx = browser.new_context(viewport={"width": 1440, "height": 980})
        page = ctx.new_page()
        ui = UI(page, args.base)

        # ---- sidebar: unscoped questions inside each department's own thread ----
        if args.mode in ("sidebar", "all"):
            depts = [d for d in POPULATED + EMPTY if not args.dept or d == args.dept]
            for slug in depts:
                name = display_name(slug)
                for case in [c for c in Q if c.dept == slug]:
                    label = f"sidebar/{slug}/{case.shape}"
                    t0 = time.perf_counter()
                    try:
                        ui.reset()
                        ui.open_department(slug, name)
                        cont = ui.ask_in_department(slug, case.query)
                        # scope came from the sidebar, so no inferred badge expected
                        detail = check_answer(ui, cont, case, expect_inferred=False)
                        ok = True
                    except Exception as exc:
                        png, log = ui.shot(label)
                        detail, ok = f"{type(exc).__name__}: {exc}", False
                    secs = round(time.perf_counter() - t0, 1)
                    results.append({"mode": "sidebar", "dept": slug, "shape": case.shape,
                                    "query": case.query, "pass": ok, "detail": detail,
                                    "secs": secs})
                    print(f"  {'PASS' if ok else 'FAIL'} {label:<46}{secs:>6}s  {detail[:78]}")

        # ---- @mention from the home thread ----
        if args.mode in ("mention", "all"):
            depts = [d for d in POPULATED if not args.dept or d == args.dept]
            for slug in depts:
                name = display_name(slug)
                case = next(c for c in Q if c.dept == slug)
                label = f"mention/{slug}"
                t0 = time.perf_counter()
                try:
                    ui.reset()
                    cont = ui.ask_home(f"@{name} {case.query}")
                    detail = check_answer(ui, cont, case, expect_inferred=False)
                    ok = True
                except Exception as exc:
                    png, log = ui.shot(label)
                    detail, ok = f"{type(exc).__name__}: {exc}", False
                secs = round(time.perf_counter() - t0, 1)
                results.append({"mode": "mention", "dept": slug, "shape": case.shape,
                                "query": case.query, "pass": ok, "detail": detail,
                                "secs": secs})
                print(f"  {'PASS' if ok else 'FAIL'} {label:<46}{secs:>6}s  {detail[:78]}")

        # ---- docgen: explicit (sidebar) and inferred (home, no dept named) ----
        if args.mode in ("docgen", "all"):
            cases = [d for d in DOCS if not args.dept or d.dept == args.dept]
            for case in cases:
                label = f"docgen/{case.dept}/{case.mode}"
                t0 = time.perf_counter()
                try:
                    ui.reset()
                    if case.mode == "explicit":
                        ui.open_department(case.dept, display_name(case.dept))
                        cont = ui.ask_in_department(case.dept, case.query)
                    else:
                        cont = ui.ask_home(case.query)
                    detail = check_doc(ui, cont, case)
                    ok = True
                except Exception as exc:
                    png, log = ui.shot(label)
                    detail, ok = f"{type(exc).__name__}: {exc}", False
                secs = round(time.perf_counter() - t0, 1)
                results.append({"mode": f"docgen-{case.mode}", "dept": case.dept,
                                "shape": "docgen", "query": case.query, "pass": ok,
                                "detail": detail, "secs": secs})
                print(f"  {'PASS' if ok else 'FAIL'} {label:<46}{secs:>6}s  {detail[:78]}")

        browser.close()

    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=1)
    passed = sum(1 for r in results if r["pass"])
    print(f"\n{passed}/{len(results)} UI checks passed -> {args.out}")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
