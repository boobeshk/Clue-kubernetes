"""End-to-end UI regression suite (CLAUDE.md section 8.1).

Drives a real headless Chromium against the running app and asserts on rendered DOM.

  python -m tests.e2e.test_ui              # start our own uvicorn, run all
  python -m tests.e2e.test_ui --headed     # watch it
  python -m tests.e2e.test_ui --base http://127.0.0.1:8000   # use a running server

Playwright is a TEST dependency, not frontend build tooling -- the frontend is still
one static HTML file with no build step (section 9). Nothing here is shipped to the
browser in production.

On any failure a screenshot and the browser console log are written to
backend/tests/e2e/artifacts/.
"""
from __future__ import annotations

import argparse
import base64
import re
import socket
import subprocess
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
ARTIFACTS = HERE / "artifacts"
BACKEND = HERE.parent.parent

sys.path.insert(0, str(BACKEND))
# One shared definition of "refused / no record" across every harness
# (CLAUDE.md 8.0) -- the API judge, the department sweep and this suite.
from tests.run_matrix_18 import is_gap_report  # noqa: E402

ANSWER = '[data-testid="bot-answer"]'
SOURCES = '[data-testid="sources"]'
INFERRED = '[data-testid="badge-inferred"]'
LANE = '[data-testid="badge-lane"]'
DOWNLOAD = '[data-testid="doc-download"]'

ANSWER_TIMEOUT = 90_000   # LLM pipeline: several sequential model calls


class Failure(Exception):
    pass


def _free(port: int) -> bool:
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def start_server(port: int) -> subprocess.Popen | None:
    if not _free(port):
        print(f"  reusing server already on :{port}")
        return None
    py = BACKEND / ".venv" / "Scripts" / "python.exe"
    if not py.exists():
        py = Path(sys.executable)
    proc = subprocess.Popen(
        [str(py), "-m", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", str(port)],
        cwd=str(BACKEND), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(60):
        if not _free(port):
            time.sleep(1.5)
            return proc
        time.sleep(1)
    raise Failure(f"server never came up on :{port}")


class Runner:
    def __init__(self, page, base):
        self.page, self.base = page, base
        self.console: list[str] = []
        self.results: list[tuple[str, bool, str]] = []
        page.on("console", lambda m: self.console.append(f"[{m.type}] {m.text}"))
        page.on("pageerror", lambda e: self.console.append(f"[pageerror] {e}"))

    def run(self, name, fn):
        print(f"\n--- {name}")
        self.console.clear()
        try:
            self.page.goto(self.base, wait_until="domcontentloaded")
            fn()
            print(f"    PASS  {name}")
            self.results.append((name, True, ""))
        except Exception as exc:
            ARTIFACTS.mkdir(parents=True, exist_ok=True)
            slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
            shot = ARTIFACTS / f"{slug}.png"
            log = ARTIFACTS / f"{slug}.console.txt"
            try:
                self.page.screenshot(path=str(shot), full_page=True)
            except Exception:
                shot = None
            log.write_text("\n".join(self.console) or "(no console output)",
                           encoding="utf-8")
            print(f"    FAIL  {name}: {type(exc).__name__}: {exc}")
            print(f"          screenshot: {shot}")
            print(f"          console:    {log}")
            for line in self.console[-6:]:
                print(f"            {line}")
            self.results.append((name, False, f"{type(exc).__name__}: {exc}"))

    # ---- helpers ------------------------------------------------------------
    def open_department(self, slug: str, name: str):
        """Sidebar shows only 5; everything else via the Apps overlay grid."""
        item = self.page.locator(f'.app-item:has-text("{name}")').first
        if item.count() and item.is_visible():
            item.click()
        else:
            self.page.click('button.nav-item:has-text("Apps")')
            self.page.wait_for_selector("#appsOverlay.active")
            self.page.locator(f'.apps-card:has-text("{name}")').first.click()
        self.page.wait_for_selector(f"#view-{slug}.active, #thread-{slug}.active")

    def ask_department(self, slug: str, text: str):
        box = self.page.locator(f"#empty-input-{slug}")
        if not box.is_visible():
            box = self.page.locator(f"#input-{slug}")
        box.fill(text)
        box.press("Enter")
        return self.wait_answer(f"#thread-inner-{slug}")

    def ask_home(self, text: str):
        box = self.page.locator("#homeInput")
        box.fill(text)
        box.press("Enter")
        return self.wait_answer("#thread-inner-home")

    def wait_answer(self, container: str):
        """Wait for the answer element AND for its text to finish appearing.

        Section 4.13 reveals the verified answer with a typing animation, so the
        element exists and is empty for a moment, then fills in. Reading
        inner_text() on sight returned '' or a fragment like 'It loo' -- three
        tests failed on truncated text that was correct a few hundred ms later.
        The reveal is capped at ~650ms, so poll until the text stops changing.
        """
        self.page.wait_for_selector(f"{container} {ANSWER}", timeout=ANSWER_TIMEOUT)
        el = self.page.locator(f"{container} {ANSWER}").last
        previous, txt = None, ""
        for _ in range(40):                       # ~4s ceiling, reveal caps at 650ms
            txt = el.inner_text().strip()
            if txt and txt == previous:
                break
            previous = txt
            self.page.wait_for_timeout(100)
        if not txt:
            raise Failure("answer rendered empty")
        if "Couldn't reach the knowledge base" in txt:
            raise Failure(f"frontend could not reach the API: {txt[:160]}")
        return txt

    def last(self, container: str, sel: str):
        loc = self.page.locator(f"{container} {sel}")
        return loc.last if loc.count() else None


def build_tests(r: Runner):
    page = r.page

    def t_sidebar_hd():
        r.open_department("cmo", "CMO")
        txt = r.ask_department("cmo", "What is the difference between an OQL and an SQL?")
        src = r.last("#thread-inner-cmo", SOURCES)
        if not src or not src.count():
            raise Failure(f"no citation badge rendered. answer={txt[:160]!r}")
        s = src.inner_text()
        if "CMO" not in s:
            raise Failure(f"citation does not name CMO: {s!r}")
        if not re.search(r"\.json", s):
            raise Failure(f"citation names no source file: {s!r}")
        lane = r.last("#thread-inner-cmo", LANE)
        if not lane or lane.inner_text().strip() != "retrieval":
            raise Failure(f"lane badge wrong: {lane.inner_text() if lane else None!r}")
        # explicit scope -> nothing was inferred
        inf = page.locator(f"#thread-inner-cmo {INFERRED}")
        if inf.count():
            raise Failure(f"inferred badge shown for an explicitly scoped query")

    def t_mention():
        box = page.locator("#homeInput")
        box.fill("@CMO ")
        page.wait_for_timeout(300)
        box.fill("@CMO who leads the Capability Management Office?")
        box.press("Enter")
        txt = r.wait_answer("#thread-inner-home")
        src = r.last("#thread-inner-home", SOURCES)
        if not src or not src.count():
            raise Failure(f"@mention produced no citations: {txt[:160]!r}")
        if "CMO" not in src.inner_text():
            raise Failure(f"@mention did not scope to CMO: {src.inner_text()!r}")
        # scope came from the mention, so the planner inferred nothing
        if page.locator(f"#thread-inner-home {INFERRED}").count():
            raise Failure("inferred badge shown though @mention set the scope")

    def t_mention_special_chars():
        box = page.locator("#homeInput")
        box.fill("@Organizational Culture & People Experience (OCPE) what do you cover?")
        box.press("Enter")
        txt = r.wait_answer("#thread-inner-home")
        # OCPE has no files; the point is the mention resolved and scoped
        bubble = page.locator(f"#thread-inner-home {ANSWER}").last.inner_text()
        if "Couldn't reach" in bubble:
            raise Failure("mention with & and parens broke the request")
        # Structural, not wording -- see t_empty_department.
        el = page.locator(f"#thread-inner-home {ANSWER}").last
        if el.get_attribute("data-grounded") != "false":
            raise Failure(f"expected an empty-department style answer, got {bubble[:160]!r}")

    def t_ambiguous():
        txt = r.ask_home("What are the KPIs?")
        el = page.locator(f"#thread-inner-home {ANSWER}").last
        if el.get_attribute("data-clarify") != "1":
            raise Failure(f"expected a clarifying response, got {txt[:200]!r}")
        # Assert on SHAPE, not wording. These messages are composed per request and
        # required to vary (responder.py: "do not sound like a template"), so a
        # phrase list is guaranteed to break on a correct answer -- it did, on
        # "search across all departments" vs the literal "search all departments".
        # What is actually invariant: it asks a question, and it is about which
        # department to use.
        if "?" not in txt:
            raise Failure(f"clarification does not ask anything: {txt[:200]!r}")
        if not re.search(r"department", txt, re.I):
            raise Failure(f"clarification does not mention departments: {txt[:200]!r}")
        if page.locator(f"#thread-inner-home {SOURCES}").count():
            raise Failure("clarifying response should carry no citations")

    def t_unscoped_clear_match():
        txt = r.ask_home("Who leads the Capability Management Office and what are its five teams?")
        inf = r.last("#thread-inner-home", INFERRED)
        if not inf or not inf.count():
            raise Failure(f"no inferred-HD badge on an unscoped clear match: {txt[:160]!r}")
        if "CMO" not in inf.inner_text():
            raise Failure(f"inferred badge names the wrong department: {inf.inner_text()!r}")
        src = r.last("#thread-inner-home", SOURCES)
        if not src or "CMO" not in src.inner_text():
            raise Failure("citations missing or not from CMO")

    def t_document():
        r.open_department("tag", "TAG")
        r.ask_department("tag", "Export the TAG KPIs as an excel spreadsheet")
        lane = r.last("#thread-inner-tag", LANE)
        if not lane or lane.inner_text().strip() != "docgen":
            raise Failure(f"lane badge is {lane.inner_text() if lane else None!r}, expected docgen")
        link = r.last("#thread-inner-tag", DOWNLOAD)
        if not link or not link.count():
            raise Failure("no download link rendered for a docgen answer")
        href = link.get_attribute("href") or ""
        if not href.startswith("data:"):
            raise Failure(f"download href is not a data URI: {href[:60]!r}")
        b64 = href.split(",", 1)[1]
        raw = base64.b64decode(b64)
        if raw[:4] != b"PK\x03\x04" or len(raw) < 1000:
            raise Failure(f"download does not resolve to a real xlsx "
                          f"({len(raw)} bytes, magic {raw[:4]!r})")
        name = link.get_attribute("download") or ""
        if not name.endswith(".xlsx"):
            raise Failure(f"download filename wrong: {name!r}")

    def t_empty_department():
        r.open_department("finance", "Finance")
        txt = r.ask_department("finance", "What is the Finance budget approval process?")
        # Assert on the STRUCTURAL flag, not the wording. These messages are
        # composed and required to vary: three consecutive runs produced three
        # different refusals ("I couldn't find any information...", "there isn't
        # any information available...", "there's nothing in the knowledge
        # base..."), and a phrase list went stale against each one in turn.
        el = page.locator(f"#thread-inner-finance {ANSWER}").last
        if el.get_attribute("data-grounded") != "false":
            raise Failure(f"empty department did not refuse: {txt[:200]!r}")
        if page.locator(f"#thread-inner-finance {SOURCES}").count():
            raise Failure("empty department returned citations")

    def t_do_not_disclose():
        r.open_department("p_cube", "P-Cube")
        txt = r.ask_department(
            "p_cube", "List the specific individual compensation and payroll figures")
        low = txt.lower()
        for banned in ("inr", "crore"):
            if banned in low:
                raise Failure(f"disclosed protected token {banned!r}: {txt[:200]!r}")
        if re.search(r"\b\d[\d,]{4,}\b", txt):
            raise Failure(f"answer contains a large figure: {txt[:200]!r}")

    def t_embed_buttons():
        page.click('button.nav-item:has-text("Knowledge Base")')
        page.wait_for_selector("#adminOverlay.active")
        for btn in ("#ingestIncrementalBtn", "#ingestFullBtn"):
            if not page.locator(btn).is_visible():
                raise Failure(f"{btn} not visible in the admin panel")
        page.once("dialog", lambda d: d.dismiss())        # Full Re-embed confirm
        page.click("#ingestFullBtn")
        page.wait_for_timeout(600)
        status = page.locator("#ingestStatus")
        if status.is_visible():
            raise Failure("dismissing the confirm still started a full re-embed")
        page.click("#ingestIncrementalBtn")
        page.wait_for_selector("#ingestStatus", state="visible", timeout=30_000)
        page.wait_for_function(
            "() => { const e = document.getElementById('ingestStatus');"
            " return e && /files|complete|error|Could not/i.test(e.innerText); }",
            timeout=120_000)
        text = status.inner_text()
        if "Could not start ingestion" in text:
            raise Failure(f"incremental embed failed to start: {text!r}")

    def t_recents_populate():
        """Section 4.11: Recents is real chat history, split global vs department."""
        # A department conversation.
        r.open_department("cmo", "CMO")
        r.ask_department("cmo", "Who leads the Capability Management Office?")
        page.wait_for_function(
            "() => document.querySelectorAll('#recentsList [data-testid=\"recent-item\"]').length > 0",
            timeout=30_000)
        dept_items = page.locator('#recentsList [data-testid="recent-item"]')
        dept_titles = [dept_items.nth(i).inner_text() for i in range(dept_items.count())]
        if not dept_titles:
            raise Failure("department Recents did not populate")
        label = page.locator("#recentsLabel").inner_text()
        if "CMO" not in label:
            raise Failure(f"recents label is {label!r}, expected it scoped to CMO")

        # A home conversation, which must NOT appear under the department.
        page.click('button.nav-item:has-text("New chat")')
        r.ask_home("What does Solution Labs build?")
        page.wait_for_function(
            "() => document.querySelectorAll('#recentsList [data-testid=\"recent-item\"]').length > 0",
            timeout=30_000)
        home_items = page.locator('#recentsList [data-testid="recent-item"]')
        home_titles = [home_items.nth(i).inner_text() for i in range(home_items.count())]
        if page.locator("#recentsLabel").inner_text().strip() != "Recents":
            raise Failure("home view should show the global Recents label")
        overlap = set(dept_titles) & set(home_titles)
        if overlap:
            raise Failure(f"department conversation leaked into global Recents: {overlap}")

        # Clicking a recent replays that conversation.
        home_items.first.click()
        page.wait_for_selector(f"#thread-inner-home {ANSWER}", timeout=30_000)
        bubbles = page.locator("#thread-inner-home .bubble-user")
        if not bubbles.count():
            raise Failure("replayed conversation shows no user turn")
        if "Solution Labs" not in bubbles.first.inner_text():
            raise Failure(f"replayed the wrong conversation: {bubbles.first.inner_text()!r}")

    def t_conversation_continuity():
        """Section 4.11: prove the SAME conversation_id is reused across a thread.

        An isolated backend test is explicitly not sufficient here -- this captures
        the actual POST bodies the browser sends, in order, from one session.
        """
        # Section 4.13 moved the client onto /api/chat/stream, with /api/chat kept
        # only as a fallback. Watching the old path alone captured 0 requests and
        # failed loudly -- which is what this assertion is for, but it means both
        # paths have to be watched now.
        sent = []
        page.on("request", lambda req: sent.append(req.post_data)
                if req.method == "POST"
                and req.url.rstrip("/").endswith(("/api/chat", "/api/chat/stream"))
                else None)

        # Turn 1 establishes a department by @mention, from the HOME thread.
        box = page.locator("#homeInput")
        box.fill("@P-Cube what does this department cover?")
        box.press("Enter")
        r.wait_answer("#thread-inner-home")

        # Turn 2 is a plain follow-up in the same visible thread, no mention.
        box2 = page.locator("#homeComposerInput")
        box2.fill("who owns it?")
        box2.press("Enter")
        page.wait_for_function(
            "() => document.querySelectorAll('#thread-inner-home [data-testid=\"bot-answer\"]').length >= 2",
            timeout=ANSWER_TIMEOUT)

        # Turn 3 is the reported failure case.
        box2.fill("make this a document")
        box2.press("Enter")
        page.wait_for_function(
            "() => document.querySelectorAll('#thread-inner-home [data-testid=\"bot-answer\"]').length >= 3",
            timeout=ANSWER_TIMEOUT)

        import json as _json
        ids, depts = [], []
        for body in [b for b in sent if b]:
            d = _json.loads(body)
            ids.append(d.get("conversation_id"))
            depts.append(d.get("head_dept"))
        if len(ids) < 3:
            raise Failure(f"expected 3 chat requests, captured {len(ids)}")
        if any(i is None for i in ids):
            raise Failure(f"a request carried no conversation_id: {ids}")
        if len(set(ids)) != 1:
            raise Failure(
                f"conversation_id changed mid-thread: {ids} (head_dept per turn: {depts}). "
                f"Every message in one visible thread must reuse one conversation.")


    # ---------------- section 4.13: live status, safe reveal ----------------

    def t_live_status_and_safe_reveal():
        """Status streams live; the answer does not.

        The two halves are tested together because the risk lives between them: if
        the answer were ever streamed as it was generated, a claim that
        verification later strips would be visible on screen first. So this asserts
        both that real progress appeared AND that nothing resembling answer text
        showed up before the verified answer arrived whole.
        """
        page.evaluate("""() => {
          window.__status = []; window.__answerStates = [];
          const obs = new MutationObserver(() => {
            document.querySelectorAll('[data-testid="status-line"]').forEach(el => {
              const t = el.innerText.trim();
              if (t && window.__status[window.__status.length-1] !== t)
                window.__status.push(t);
            });
            document.querySelectorAll('[data-testid="bot-answer"]').forEach(el => {
              const t = el.innerText.trim();
              if (t && window.__answerStates[window.__answerStates.length-1] !== t)
                window.__answerStates.push(t);
            });
          });
          obs.observe(document.body, {subtree:true, childList:true, characterData:true});
        }""")
        r.ask_home("What are the KPIs for TAG?")
        page.wait_for_timeout(2500)          # let the reveal finish

        seen = page.evaluate("() => window.__status")
        if len(seen) < 4:
            raise Failure(f"expected live progress through several real stages, "
                          f"saw {seen}")
        # every line must correspond to a real stage label, not invented copy
        from streaming.progress import STAGE_LABELS
        known = [v for v in STAGE_LABELS.values() if v]
        for line in seen:
            base = line.split(" (")[0]
            if base not in known:
                raise Failure(f"status line is not a known pipeline stage: {line!r}")

        # the answer element must not have existed while status was still running:
        # its first state arrives only once the done event lands
        states = page.evaluate("() => window.__answerStates")
        if not states:
            raise Failure("no answer was rendered")
        final = page.locator(f"#thread-inner-home {ANSWER}").last.inner_text().strip()
        if not final:
            raise Failure("final answer is empty")
        if page.locator('[data-testid="status-line"]').count():
            raise Failure("status line still visible after the answer arrived")

    # ---------------- layout regressions, found by using the app ------------
    # Both were invisible to every assertion this suite had, because every earlier
    # test asserted on CONTENT (is the answer there, is it cited) and these are
    # failures of GEOMETRY. They are measured here, not eyeballed.

    def t_department_view_layout():
        """A department thread must behave like the home thread: bounded height,
        its own scrollbar, composer pinned in view.

        It did not. #appViews was a plain wrapper div, so .thread-view's flex:1 had
        no flex parent to size against and grew to fit its content instead. Measured
        at 1280x800 before the fix: the CMO thread was 1261px tall in an 800px
        viewport, nothing scrolled, and the composer's bottom edge sat at y=1095 --
        295px below the fold, with the page itself not scrollable either, so there
        was no way to reach the input at all.
        """
        r.open_department("cmo", "CMO")
        # Three turns, so the thread is definitely longer than the viewport -- the
        # bug only shows once there is more content than fits. wait_answer returns
        # as soon as ANY answer exists, so wait on the count instead: otherwise the
        # geometry gets measured while later answers are still in flight.
        sel = f"#thread-inner-cmo {ANSWER}"
        for i, q in enumerate(("What is the difference between an OQL and an SQL?",
                               "What are the CMO KPIs?",
                               "Which systems does CMO use?"), start=1):
            box = page.locator("#empty-input-cmo")
            if not box.is_visible():
                box = page.locator("#input-cmo")
            box.fill(q)
            box.press("Enter")
            page.wait_for_function(
                "([s, n]) => document.querySelectorAll(s).length >= n",
                arg=[sel, i], timeout=ANSWER_TIMEOUT)

        m = page.evaluate("""() => {
          const vh = window.innerHeight;
          const sc = document.getElementById('scroll-cmo');
          const bar = document.querySelector('#thread-cmo .composer-bar');
          const br = bar.getBoundingClientRect();
          return {
            scrollable: sc.scrollHeight > sc.clientHeight + 2,
            scroll_h: sc.clientHeight,
            composer_bottom: Math.round(br.bottom),
            composer_in_view: br.bottom <= vh + 1 && br.top >= 0,
            viewport: vh};
        }""")
        if not m["composer_in_view"]:
            raise Failure(f"composer is out of view: bottom={m['composer_bottom']} "
                          f"viewport={m['viewport']} (must be <= viewport)")
        if not m["scrollable"]:
            raise Failure(f"message area does not scroll: clientHeight="
                          f"{m['scroll_h']} with a thread longer than the viewport")
        if m["scroll_h"] >= m["viewport"]:
            raise Failure(f"thread is not bounded by the viewport: scroll area "
                          f"{m['scroll_h']}px in a {m['viewport']}px window")

    def t_department_view_new_chat():
        """A department view must offer a way to start a fresh chat without leaving
        the department. There was none: the only "New chat" was the sidebar's, which
        navigates back to home."""
        r.open_department("cmo", "CMO")
        r.ask_department("cmo", "What does the CMO do?")
        btn = page.locator('[data-testid="new-chat"]')
        if not btn.count() or not btn.first.is_visible():
            raise Failure("no reachable New chat control while a department is open")
        btn.first.click()
        page.wait_for_timeout(400)
        if not page.locator("#view-cmo.active").count():
            raise Failure("New chat did not return the department to its empty state")
        if page.locator(f"#thread-inner-cmo {ANSWER}").count():
            raise Failure("New chat left the previous thread's messages behind")
        # and it must still be CMO, not home
        if page.locator("#view-home.active").count():
            raise Failure("New chat inside a department dropped the user to home")

    def t_mention_dropdown_scrollable():
        """Every department must be reachable in the @mention list.

        The list opens upward with overflow:hidden and no max-height, so with 18
        departments it ran off the top of the window: measured at 1280x800, its top
        edge was at y=-308 and 8 of 18 entries were unreachable, including the last.
        Asserted here as the real user action -- scroll to the end and select it --
        rather than as a CSS property, so any future change that breaks reachability
        by another route still fails.
        """
        page.fill("#homeInput", "@")
        page.wait_for_timeout(400)
        d = "#homeMentionDropdown"
        opts = page.locator(f"{d} .mention-option")
        n = opts.count()
        if n < 18:
            raise Failure(f"expected all 18 departments in the list, got {n}")
        box = page.evaluate("""() => {const d=document.getElementById('homeMentionDropdown');
            const r=d.getBoundingClientRect();
            return {top: r.top, bottom: r.bottom, vh: window.innerHeight,
                    scrollable: d.scrollHeight > d.clientHeight + 2};}""")
        if box["top"] < 0 or box["bottom"] > box["vh"] + 1:
            raise Failure(f"dropdown runs outside the viewport: top={box['top']:.0f} "
                          f"bottom={box['bottom']:.0f} viewport={box['vh']}")
        if not box["scrollable"]:
            raise Failure("dropdown does not scroll, so a longer list would be cut off")

        page.evaluate("""() => {const d=document.getElementById('homeMentionDropdown');
            d.scrollTop = d.scrollHeight;}""")
        page.wait_for_timeout(250)
        visible = page.evaluate("""() => {
            const o=[...document.querySelectorAll('#homeMentionDropdown .mention-option')].pop();
            const r=o.getBoundingClientRect();
            const d=document.getElementById('homeMentionDropdown').getBoundingClientRect();
            return r.top >= d.top-1 && r.bottom <= d.bottom+1
                   && r.top >= 0 && r.bottom <= window.innerHeight;}""")
        if not visible:
            raise Failure("the last department cannot be brought into view by scrolling")
        opts.nth(n - 1).click()
        page.wait_for_timeout(300)
        val = page.input_value("#homeInput")
        if "OCPE" not in val:
            raise Failure(f"selecting the last department did not fill the input: {val!r}")

    return [
        ("sidebar HD selection + citations", t_sidebar_hd),
        ("Recents populates, global vs department", t_recents_populate),
        ("conversation_id persists across a thread", t_conversation_continuity),
        ("@mention scoping", t_mention),
        ("@mention with & and parentheses", t_mention_special_chars),
        ("ambiguous query asks instead of guessing", t_ambiguous),
        ("unscoped clear match shows inferred-HD badge", t_unscoped_clear_match),
        ("document creation returns a real file", t_document),
        ("empty department refuses", t_empty_department),
        ("do_not_disclose probe", t_do_not_disclose),
        ("both Embed buttons function", t_embed_buttons),
        ("live status streams; answer revealed only after verification",
         t_live_status_and_safe_reveal),
        ("department view: composer pinned, messages scroll", t_department_view_layout),
        ("department view: New chat without leaving the department",
         t_department_view_new_chat),
        ("@mention list is scrollable to the last department",
         t_mention_dropdown_scrollable),
    ]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=None)
    ap.add_argument("--headed", action="store_true")
    ap.add_argument("--filter", default=None)
    ap.add_argument("--port", type=int, default=8000)
    args = ap.parse_args()

    proc = None
    base = args.base
    if not base:
        proc = start_server(args.port)
        base = f"http://127.0.0.1:{args.port}"
    print(f"e2e against {base}")

    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=not args.headed)
            ctx = browser.new_context(viewport={"width": 1400, "height": 950})
            page = ctx.new_page()
            r = Runner(page, base)
            for name, fn in build_tests(r):
                if args.filter and args.filter.lower() not in name.lower():
                    continue
                r.run(name, fn)
            browser.close()
    finally:
        if proc:
            proc.terminate()

    passed = sum(1 for _, ok, _ in r.results if ok)
    print(f"\n{'=' * 70}\n{passed}/{len(r.results)} e2e tests passed")
    for name, ok, why in r.results:
        if not ok:
            print(f"  FAIL  {name}: {why}")
    return 0 if passed == len(r.results) else 1


if __name__ == "__main__":
    sys.exit(main())
