"""Step 9 verification against real tables (CLAUDE.md 4.11, 4.12, 7).

    python -m tests.test_memory

Creates its own conversations under a throwaway anon_user_id and cleans up after
itself, so it is safe to re-run.
"""
from __future__ import annotations

import re
import sys
import uuid

from fastapi.testclient import TestClient

import main
from clients import supabase
from memory import store

c = TestClient(main.app)
USER = f"e2e-test-{uuid.uuid4()}"
failures: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f"  -- {detail}" if detail and not ok else ""))
    if not ok:
        failures.append(f"{name}: {detail}")


def ask(query, head_dept=None, conversation_id=None):
    return c.post("/api/chat", json={
        "query": query, "head_dept": head_dept, "session_id": "mem-test",
        "anon_user_id": USER, "conversation_id": conversation_id}).json()


print("=" * 92)
print("### 4.11 conversations are head_dept-aware")
r = c.post("/api/conversations", json={"anon_user_id": USER, "head_dept": "cmo"})
check("create department conversation", r.status_code == 200, r.text)
cmo_convo = r.json()["conversation_id"]
check("head_dept persisted", r.json().get("head_dept") == "cmo", str(r.json()))

r = c.post("/api/conversations", json={"anon_user_id": USER})
home_convo = r.json()["conversation_id"]
check("create home conversation (head_dept null)", r.json().get("head_dept") is None)

r = c.post("/api/conversations", json={"anon_user_id": USER, "head_dept": "nope"})
check("unknown head_dept rejected", r.status_code == 400, r.text)

print("\n### turns are recorded and titles generated")
d1 = ask("Who leads the Capability Management Office?", "cmo", cmo_convo)
check("chat answered inside a conversation", bool(d1.get("answer")))
turns = c.get(f"/api/conversations/{cmo_convo}").json()["turns"]
check("2 turns recorded", len(turns) == 2, f"got {len(turns)}")
check("roles are user then assistant",
      [t["role"] for t in turns] == ["user", "assistant"], str([t["role"] for t in turns]))
check("assistant turn kept its sources", bool(turns[1].get("sources")))
check("turn carries head_dept", turns[1].get("head_dept") == "cmo", str(turns[1].get("head_dept")))
title = c.get(f"/api/conversations/{cmo_convo}").json().get("title")
check("title generated from first turn", bool(title), f"title={title!r}")
print(f"        title: {title!r}")

print("\n### the follow-up case from section 7")
ask("What are its five teams?", "cmo", cmo_convo)
turns = c.get(f"/api/conversations/{cmo_convo}").json()["turns"]
check("follow-up recorded", len(turns) == 4, f"got {len(turns)}")
follow = turns[3]["content"]
resolved = bool(re.search(r"pitch lab|capability marketing|capability research|cmd",
                          follow, re.I))
check("elliptical follow-up resolved using conversation context", resolved,
      f"answer={follow[:150]!r}")
print(f"        {follow[:170]!r}")

print("\n### memory context must NOT relax HD scoping or the gate")
ask("Tell me about TAG offshore staffing", "tag", home_convo)
d = ask("What is the capital of France?", "cmo", home_convo)
# Assert on the STRUCTURED result: refusal wording is composed per request now,
# so phrase-matching is not a stable test.
check("prior turns do not let an out-of-KB question through",
      d.get("grounded") is False and not (d.get("sources") or []),
      f"grounded={d.get('grounded')!r} sources={len(d.get('sources') or [])} "
      f"answer={d.get('answer','')[:120]!r}")
srcs = {s["head_dept"] for s in (d.get("sources") or [])}
check("no cross-department leak via conversation history",
      srcs <= {"cmo"}, f"sources from {srcs}")

print("\n### sidebar recents: global vs per-department (the UI's split)")
dept = c.get("/api/conversations", params={"anon_user_id": USER, "head_dept": "cmo"}).json()
glob = c.get("/api/conversations", params={"anon_user_id": USER, "scope": "global"}).json()
allc = c.get("/api/conversations", params={"anon_user_id": USER, "scope": "all"}).json()
check("department recents contain only that department",
      all(x["head_dept"] == "cmo" for x in dept) and len(dept) == 1,
      f"{[(x['head_dept'], x['title']) for x in dept]}")
check("global recents contain only home conversations",
      all(x["head_dept"] is None for x in glob) and len(glob) == 1,
      f"{[(x['head_dept'], x['title']) for x in glob]}")
check("all-scope returns both", len(allc) == 2, f"got {len(allc)}")
check("recents carry a title for the sidebar", all("title" in x for x in allc))

print("\n### 4.12 long-term memory safety filter (section 9)")
# Section 4.12 requires explicit blocked/allowed cases for EACH named category, not
# a spot check. The employment-standing category exists because testing found a real
# gap: the filter caught "PIP" but not "performance improvement plan" spelled out.
# Keep every category populated -- deleting a category is a coverage regression.
BLOCKED_BY_CATEGORY = {
    "compensation figures": [
        "User's salary is 42,00,000 INR",
        "User asked about individual payroll figures for the finance team",
        "User's bonus was 12 lakh this cycle",
        "The FDX investment is INR 50 crore",
    ],
    "health": [
        "User has a medical condition affecting their schedule",
        "User disclosed a mental health diagnosis",
        "User is on long-term disability leave",
    ],
    "employment standing": [
        "User is on a performance improvement plan",     # spelled out, not just "PIP"
        "User was put on a PIP in March",
        "User received a warning letter last quarter",
        "User is serving their notice period",
        "User is on probation until June",
        "User filed a grievance against their manager",
        "There was a misconduct investigation involving the user",
        "User's team is affected by the layoff",
        "User's appraisal rating was 3 out of 5",
        "User's performance review is overdue",
    ],
    "protected characteristics": [
        "User mentioned their religion",
        "User's ethnicity came up in conversation",
        "User discussed their sexual orientation",
    ],
    "visa / immigration": [
        "User mentioned their visa status",
        "User's passport renewal is pending",
    ],
    "do_not_disclose-sourced": [
        "Vulnerability scan results show 3 critical issues",
        "The risk register lists 4 open items",
        "This document is marked confidential - internal only",
    ],
}
ALLOWED = [
    "Prefers concise, bulleted answers",
    "Usually asks about CMO",
    "Works in the delivery organisation",
    "Often asks for spreadsheets rather than PDFs",
    "Interested in escalation paths across departments",
    "Prefers answers that cite the source file",
    "Tends to ask about TAG and Delivery Management",
]

for category, samples in BLOCKED_BY_CATEGORY.items():
    missed = []
    for t in samples:
        ok, _ = store.is_safe_memory(t)
        if ok:
            missed.append(t)
    check(f"blocked category: {category} ({len(samples)} cases)", not missed,
          f"allowed through: {missed}")
    for t in missed:
        print(f"          LEAKED: {t!r}")

for t in ALLOWED:
    ok, why = store.is_safe_memory(t)
    check(f"allowed: {t[:48]!r}", ok, f"was blocked ({why})")

check("every 4.12 category has test cases",
      all(len(v) >= 2 for v in BLOCKED_BY_CATEGORY.values()),
      f"thin categories: {[k for k, v in BLOCKED_BY_CATEGORY.items() if len(v) < 2]}")

print("\n### add / list / delete memory")
store.add_memory(USER, "Usually asks about CMO", "default_scope", cmo_convo)
store.add_memory(USER, "Prefers concise answers", "preference", cmo_convo)
blocked_row = store.add_memory(USER, "User's salary is 42,00,000 INR", "fact", cmo_convo)
check("unsafe memory refused at the write path", blocked_row is None)

mems = c.get("/api/memory", params={"anon_user_id": USER}).json()
check("GET /api/memory lists what is held", len(mems) == 2, f"got {len(mems)}")
check("no blocked text was persisted",
      not any("salary" in m["memory_text"].lower() for m in mems))

r = c.request("DELETE", f"/api/memory/{mems[0]['id']}")
check("DELETE one memory", r.status_code == 200 and
      len(c.get("/api/memory", params={"anon_user_id": USER}).json()) == 1)
r = c.request("DELETE", "/api/memory", params={"anon_user_id": USER})
check("DELETE all memories", r.status_code == 200 and
      c.get("/api/memory", params={"anon_user_id": USER}).json() == [])

print("\n### conversation delete cascades to turns")
sb = supabase()
before = len(sb.table("chat_turns").select("id").eq("conversation_id", cmo_convo).execute().data or [])
c.request("DELETE", f"/api/conversations/{cmo_convo}")
after = len(sb.table("chat_turns").select("id").eq("conversation_id", cmo_convo).execute().data or [])
check("turns cascade-deleted with the conversation", before > 0 and after == 0,
      f"{before} -> {after}")

print("\n### 8.2 latency_log now persists")
rows = (sb.table("latency_log").select("lane,total_ms,stages")
        .order("created_at", desc=True).limit(3).execute().data or [])
check("latency rows written", len(rows) > 0, "no rows")
if rows:
    print(f"        newest: lane={rows[0]['lane']} total={rows[0]['total_ms']}ms "
          f"stages={sorted((rows[0]['stages'] or {}).keys())[:5]}...")

# cleanup
c.request("DELETE", f"/api/conversations/{home_convo}")
sb.table("user_memory").delete().eq("anon_user_id", USER).execute()

print("\n" + "=" * 92)
print(f"{'ALL PASS' if not failures else str(len(failures)) + ' FAILURE(S)'}")
for f in failures:
    print(f"  - {f}")
sys.exit(1 if failures else 0)
