"""Run the 18-department matrix + docgen sweep against a LIVE server.

    python -m tests.run_matrix_18 --base http://127.0.0.1:8001
    python -m tests.run_matrix_18 --only questions
    python -m tests.run_matrix_18 --only docs --out docs.json

Writes JSON so results can be analysed rather than eyeballed.
"""
from __future__ import annotations

import argparse
import base64
import json
import re
import sys
import time
import urllib.request
from collections import defaultdict

from tests.matrix_18 import DOCS, EMPTY, POPULATED, Q

CITE = re.compile(r"\[source:\s*([^\]]+?)\s*\]", re.I)
# A grounded, cited "the documentation does not record X" is a GAP REPORT, not an
# answer. The API judge used to accept it (grounded=True with sources) while the
# browser judge called it a refusal -- so the API sweep read 90/90 while three of
# those cases were really knowledge-base gaps. Both harnesses now agree.
GAP_REPORT = re.compile(
    # The DOCUMENTATION must be the subject of the negation. A bare "not stated"
    # also matches a genuine answer that notes a sub-detail in passing ("P-Cube
    # covers X [source]. The exact cadence is not stated."), which is an answer.
    r"(documentation|document|source|knowledge\s+base|records?|profile|charter)"
    r"\s+(does\s+not|do\s+not|does ?n.t|do ?n.t)\s+"
    r"(record|specify|state|name|identify|mention|list|provide|contain|cover)"
    r"|^\s*(no|there is no)\s+(specific\s+)?(name|information|record|detail)"
    r"|there\s+(is\s+no|is\s?n.t\s+any|is\s+not\s+any)\s+(specific\s+)?"
    r"(information|record|detail|data|name)"
    r"|could ?n.t find (any )?information",
    re.I)

# Contentless conversational lead-ins. The warmer voice prepends these -- "It looks
# like I couldn't find any information on X" -- which pushed the gap phrase past the
# position anchor below and made two plain refusals read as answers. Stripping them
# before measuring position keeps the anchor meaningful: what it is really testing
# is whether any SUBSTANCE precedes the gap, and these are not substance.
_LEAD_IN = re.compile(
    r"^\s*(?:it\s+(?:looks|seems|appears)\s+(?:like|that|as\s+though)?|"
    r"unfortunately|i'?m\s+afraid|regrettably|sadly|"
    r"from\s+what\s+i\s+can\s+see|as\s+far\s+as\s+i\s+can\s+tell)\b[\s,:-]*",
    re.I)

# How far into the answer the gap statement may start and still mean the answer
# OPENS with it. A few characters of slack for a leading quote or dash, nothing
# more -- this is "does it lead with the gap", not "does it mention one".
_GAP_LEAD_SLACK = 8


def is_gap_report(answer: str) -> bool:
    """True when the answer is ESSENTIALLY "the source does not contain this".

    The test is whether the answer OPENS with the gap, which is what "essentially"
    means here and is the one signal that separates the two shapes cleanly:

      "The documentation does not record how to request SME support. However, it
       does mention the SME Request Tracker..."        -> gap: it leads with it.
      "Domain Consulting Group is part of X, but the documentation does not
       specify who leads it. Its key activities are 1..2..3.."  -> an ANSWER to a
       two-part question that notes a gap in passing.

    An earlier version measured how much text followed the gap sentence instead.
    That needed a length threshold, and the two shapes above have similar lengths,
    so it separated them only by luck. Where the gap sits does separate them.
    """
    text = _LEAD_IN.sub("", (answer or "").strip(), count=1)
    m = GAP_REPORT.search(text[:140])
    return bool(m) and m.start() <= _GAP_LEAD_SLACK

PDF = b"%PDF"
ZIP = bytes([0x50, 0x4B, 0x03, 0x04])


def post(base: str, body: dict, timeout: int = 300) -> dict:
    req = urllib.request.Request(
        base + "/api/chat", data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())


def cited(answer: str) -> set[str]:
    out = set()
    for raw in CITE.findall(answer):
        for part in raw.split(","):
            part = part.strip()
            if part and ":" not in part:
                out.add(part)
    return out


def judge_question(case, d) -> tuple[bool, str]:
    ans = d.get("answer", "") or ""
    srcs = {s["head_dept"] for s in (d.get("sources") or [])}
    refused = d.get("grounded") is False and not srcs
    clarified = bool(d.get("needs_clarification"))

    if case.expect == "no_record":
        # The department is right, the knowledge base simply does not record the
        # answer. Must say so plainly and must not invent a name.
        if clarified:
            return False, "asked for clarification instead of reporting the gap"
        if srcs and srcs != {case.dept}:
            return False, f"wrong department: {sorted(srcs)}"
        if not is_gap_report(ans):
            return False, f"did not report the gap: {ans[:110]!r}"
        return True, ""

    if case.expect == "refused":
        if clarified:
            return True, "asked which department (acceptable: no data to route to)"
        if not refused:
            return False, f"MIS-ROUTED to {sorted(srcs)} instead of refusing"
        return True, ""

    if clarified:
        return False, "asked for clarification instead of inferring scope"
    if refused:
        return False, "refused - no answer produced"
    if not srcs:
        return False, "no sources"
    if srcs != {case.dept}:
        return False, f"wrong department: {sorted(srcs)}"
    if d.get("inferred_hd") != case.dept:
        return False, f"inferred_hd={d.get('inferred_hd')!r}"
    if is_gap_report(ans):
        return False, f"reported a documentation gap, not an answer: {ans[:100]!r}"
    if not cited(ans):
        return False, "answer carries no [source: ...] citation"
    return True, ""


def judge_doc(case, d) -> tuple[bool, str]:
    if d.get("needs_clarification"):
        return False, "asked for clarification"
    if d.get("lane") != "docgen":
        return False, f"lane={d.get('lane')!r}"
    doc = d.get("document")
    if not doc or not doc.get("base64"):
        return False, "no document returned (false not-found)"
    raw = base64.b64decode(doc["base64"])
    if raw[:4] not in (PDF, ZIP) or len(raw) < 800:
        return False, f"not a real file ({len(raw)}b, {raw[:4]!r})"
    srcs = {s["head_dept"] for s in (d.get("sources") or [])}
    if not srcs:
        return False, "document has no grounding sources"
    if srcs != {case.dept}:
        return False, f"grounded in wrong department: {sorted(srcs)}"
    return True, ""


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8001")
    ap.add_argument("--only", choices=["questions", "docs", "all"], default="all")
    ap.add_argument("--out", default="matrix_results.json")
    ap.add_argument("--dept", default=None, help="limit to one department")
    args = ap.parse_args()

    results = {"questions": [], "docs": []}

    if args.only in ("questions", "all"):
        cases = [c for c in Q if not args.dept or c.dept == args.dept]
        print(f"### QUESTIONS ({len(cases)})")
        for c in cases:
            t0 = time.perf_counter()
            try:
                d = post(args.base, {"query": c.query, "head_dept": None,
                                     "session_id": "m18"})
                ok, why = judge_question(c, d)
            except Exception as exc:
                d, ok, why = {}, False, f"{type(exc).__name__}: {exc}"
            secs = round(time.perf_counter() - t0, 2)
            results["questions"].append({
                "dept": c.dept, "shape": c.shape, "query": c.query,
                "expect": c.expect, "pass": ok, "detail": why, "secs": secs,
                "inferred": d.get("inferred_hd"), "lane": d.get("lane"),
                "grounded": d.get("grounded"),
                "clarified": bool(d.get("needs_clarification")),
                "srcs": sorted({s["head_dept"] for s in (d.get("sources") or [])}),
                "answer": (d.get("answer") or "")[:300]})
            print(f"  {'PASS' if ok else 'FAIL'} {c.dept:<36}{c.shape:<11}{secs:>6}s  {why}")

    if args.only in ("docs", "all"):
        cases = [d for d in DOCS if not args.dept or d.dept == args.dept]
        print(f"\n### DOCGEN ({len(cases)})")
        for c in cases:
            t0 = time.perf_counter()
            try:
                d = post(args.base, {"query": c.query, "head_dept": c.head_dept,
                                     "session_id": "m18d"})
                ok, why = judge_doc(c, d)
            except Exception as exc:
                d, ok, why = {}, False, f"{type(exc).__name__}: {exc}"
            secs = round(time.perf_counter() - t0, 2)
            doc = d.get("document") or {}
            results["docs"].append({
                "dept": c.dept, "mode": c.mode, "query": c.query, "pass": ok,
                "detail": why, "secs": secs, "lane": d.get("lane"),
                "filename": doc.get("filename"),
                "bytes": len(base64.b64decode(doc["base64"])) if doc.get("base64") else 0,
                "srcs": sorted({s["head_dept"] for s in (d.get("sources") or [])}),
                "answer": (d.get("answer") or "")[:200]})
            print(f"  {'PASS' if ok else 'FAIL'} {c.dept:<36}{c.mode:<10}{secs:>6}s  {why}")

    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=1)
    print(f"\nwrote {args.out}")

    qp = sum(1 for r in results["questions"] if r["pass"])
    dp = sum(1 for r in results["docs"] if r["pass"])
    print(f"questions {qp}/{len(results['questions'])}   docs {dp}/{len(results['docs'])}")
    return 0 if qp == len(results["questions"]) and dp == len(results["docs"]) else 1


if __name__ == "__main__":
    sys.exit(main())
