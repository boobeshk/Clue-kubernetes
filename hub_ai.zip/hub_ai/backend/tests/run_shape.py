"""Run the natural-phrasing shape set against planner.understand().

    python -m tests.run_shape [--json out.json]

Unit-level on purpose: it exercises the understanding step alone, with no retrieval
or generation, so a failure points at the judgement rather than anywhere downstream.
Breadth phrasings are run against SEVERAL departments, because the same wording must
behave the same way whichever department it is about -- a fix that generalises over
phrasing but not over department is only half a fix.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from planner import planner
from tests.shape_set import (BREADTH_PHRASINGS, CONTEXTS, DRILLDOWN_PHRASINGS,
                             SCOPE_PHRASINGS)

# Spread across departments of different shapes and sizes rather than testing one.
DEPTS = ["cmo", "tag", "delivery_management", "p_cube", "labs"]


def _run(fn, items, workers=8):
    with ThreadPoolExecutor(max_workers=workers) as pool:
        return list(pool.map(fn, items))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", dest="json_out", default=None)
    args = ap.parse_args()

    results = []

    # --- breadth, the same wording across several departments ----------------
    jobs = [(q, exp, d) for q, exp in BREADTH_PHRASINGS for d in DEPTS]

    def breadth_job(job):
        q, exp, dept = job
        # The department is the conversation's scope, exactly as the sidebar sets
        # it; the wording under test stays untouched.
        got = planner.understand(q).breadth
        return {"group": "breadth", "query": q, "dept": dept,
                "expect": exp, "got": got, "pass": got == exp}

    results += _run(breadth_job, jobs)

    def scope_job(job):
        q, exp_b, exp_all = job
        i = planner.understand(q)
        # exp_b None means deliberately unasserted -- see shape_set for why.
        ok = (exp_b is None or i.breadth == exp_b) and (i.all_departments == exp_all)
        return {"group": "scope", "query": q, "dept": None,
                "expect": f"breadth={exp_b} all={exp_all}",
                "got": f"breadth={i.breadth} all={i.all_departments}", "pass": ok}

    results += _run(scope_job, SCOPE_PHRASINGS)

    def drill_job(job):
        ctx_key, q, exp = job
        i = planner.understand(q, CONTEXTS[ctx_key])
        ok = i.drill_down == exp
        # A drill-down that identifies nothing to drill into is not usable: it would
        # fall through to retrieving on the literal follow-up text.
        if exp and ok and not i.focus:
            ok = False
        return {"group": "drilldown", "query": f"[{ctx_key}] {q}", "dept": None,
                "expect": exp,
                "got": f"drill={i.drill_down} focus={i.focus!r}", "pass": ok}

    results += _run(drill_job, DRILLDOWN_PHRASINGS)

    by_group = Counter((r["group"], r["pass"]) for r in results)
    print(f"{'group':<12} {'query':<52} {'expect':<22} {'got'}")
    print("-" * 118)
    for r in results:
        if r["pass"]:
            continue
        print(f"{r['group']:<12} {r['query'][:50]:<52} {str(r['expect']):<22} {r['got']}")

    print("-" * 118)
    total = len(results)
    passed = sum(1 for r in results if r["pass"])
    for g in ("breadth", "scope", "drilldown"):
        p, f = by_group[(g, True)], by_group[(g, False)]
        print(f"  {g:<12} {p:>3} pass / {f:>3} fail")
    print(f"  {'TOTAL':<12} {passed:>3} pass / {total - passed:>3} fail")

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=2)
        print(f"\nwrote {args.json_out}")
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
