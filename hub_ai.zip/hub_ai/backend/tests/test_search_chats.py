"""Permanent tests for the sidebar "Search chats" feature.

    python -m tests.test_search_chats

Search must find a user's REAL conversation history, by title and by message
content, and must never reach another user's history. Conversations are seeded
directly through the store (rather than by asking the model) so the test is fast
and deterministic -- what is under test is search, not generation. One live
end-to-end case goes through the HTTP route the UI actually calls.

Test hygiene (section 8.0): everything created here is removed in a finally block,
under throwaway anon_user_ids carrying a test prefix.
"""
from __future__ import annotations

import sys
import uuid

from fastapi.testclient import TestClient

import main
from clients import supabase
from memory import store

c = TestClient(main.app)
USER = f"e2e-search-{uuid.uuid4()}"
OTHER = f"e2e-search-other-{uuid.uuid4()}"

failures: list[str] = []
created: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f"  -- {detail}" if not ok else ""))
    if not ok:
        failures.append(f"{name}: {detail}")


def seed(user: str, title: str, turns: list[tuple[str, str]],
         head_dept: str | None = None) -> str:
    cid = store.create_conversation(user, head_dept)["id"]
    created.append(cid)
    store.set_title(cid, title)
    for role, content in turns:
        store.record_turn(cid, role, content)
    return cid


def search(term: str, user: str = USER):
    r = c.get("/api/conversations/search",
              params={"anon_user_id": user, "q": term})
    return r.status_code, (r.json() if r.status_code == 200 else r.text)


def ids(rows) -> set[str]:
    return {row["conversation_id"] for row in rows}


def main_run() -> int:
    print("=" * 92)
    print("### seeding real conversation history")

    # Title contains "escalation"; body does not.
    a = seed(USER, "Escalation path for Delivery Management", [
        ("user", "Who do I contact first?"),
        ("assistant", "The first point of contact is the account lead."),
    ], head_dept="delivery_management")

    # Body contains "quarterly forecast"; title does not.
    b = seed(USER, "CMO overview", [
        ("user", "Tell me about the capability lifecycle"),
        ("assistant", "The quarterly forecast is reviewed by the Pitch Lab team."),
    ], head_dept="cmo")

    # Neither title nor body mentions the search terms above.
    seed(USER, "P-Cube leadership", [
        ("user", "Who runs operations?"),
        ("assistant", "The role is titled Head - P-Cube Operations."),
    ], head_dept="p_cube")

    # Belongs to a DIFFERENT user; must never appear in USER's results.
    other = seed(OTHER, "Escalation path secrets", [
        ("user", "quarterly forecast for another user"),
        ("assistant", "not yours"),
    ])
    print(f"  seeded 4 conversations ({len(created)} tracked)")

    print("\n### title search")
    code, rows = search("escalation")
    check("HTTP 200", code == 200, str(rows)[:120])
    check("title match found", a in ids(rows), f"got {ids(rows)}")
    check("title match labelled 'title'",
          any(r["conversation_id"] == a and r["match"] == "title" for r in rows),
          str(rows)[:200])

    print("\n### message-content search (title does NOT contain the term)")
    code, rows = search("quarterly forecast")
    check("content match found", b in ids(rows), f"got {ids(rows)}")
    row_b = next((r for r in rows if r["conversation_id"] == b), None)
    check("content match labelled 'content'",
          bool(row_b) and row_b["match"] == "content", str(row_b)[:200])
    check("content match carries an excerpt",
          bool(row_b) and bool(row_b.get("excerpt"))
          and "quarterly forecast" in (row_b.get("excerpt") or "").lower(),
          f"excerpt={row_b.get('excerpt') if row_b else None!r}")

    print("\n### results are openable (the id resolves to a real conversation)")
    got = c.get(f"/api/conversations/{a}")
    check("GET /api/conversations/{id} returns the thread",
          got.status_code == 200 and got.json().get("turns"),
          f"status={got.status_code}")

    print("\n### cross-user isolation")
    code, rows = search("escalation")
    check("another user's conversation is NOT returned", other not in ids(rows),
          f"leaked: {other} in {ids(rows)}")
    code, rows = search("quarterly forecast", user=OTHER)
    check("the other user sees only their own", ids(rows) == {other},
          f"got {ids(rows)}")

    print("\n### no-match and empty query")
    code, rows = search("zzzznotarealtermzzzz")
    check("no match returns empty list", rows == [], str(rows)[:120])
    code, rows = search("   ")
    check("blank query returns empty list, not all history", rows == [],
          f"got {len(rows) if isinstance(rows, list) else rows} rows")

    print("\n### wildcards are literal, not operators")
    code, rows = search("%")
    check("a bare % does not match everything", rows == [],
          f"got {len(rows) if isinstance(rows, list) else rows} rows")

    print()
    print("=" * 92)
    if failures:
        print(f"FAILED ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
    else:
        print("ALL PASS")
    return 1 if failures else 0


if __name__ == "__main__":
    try:
        code = main_run()
    finally:
        sb = supabase()
        for cid in created:
            try:
                sb.table("chat_turns").delete().eq("conversation_id", cid).execute()
                sb.table("conversations").delete().eq("id", cid).execute()
            except Exception as exc:      # noqa: BLE001
                print(f"  cleanup warning: {cid} -> {exc}")
        print(f"  cleaned up {len(created)} test conversations")
    sys.exit(code)
