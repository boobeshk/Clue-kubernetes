"""Natural-phrasing test set for request-shape understanding (CLAUDE.md 8.3).

The point of this file is GENERALISATION, so it is built as many different ways of
asking the same few things, not as one example per behaviour. Every fix to scope
inference, breadth detection or drill-down has to hold across all of them; a fix
that works on the phrasing in the bug report and fails on a rewording of the same
intent is not a fix, and this set is what makes that visible.

It deliberately carries as many NEGATIVES as positives. Recall alone is trivially
satisfied by treating everything as breadth, which would send every specific
question through structural retrieval and lose the answer -- so each positive group
is paired with near-miss phrasings that must NOT trigger.
"""
from __future__ import annotations

# (query, expect_breadth) -- department scope is supplied separately by the runner,
# because the same wording must behave the same way whichever department it is about.
BREADTH_PHRASINGS: list[tuple[str, bool]] = [
    # --- the whole of a department: the request under test -------------------
    ("summarize this department", True),
    ("give me an overview of this department", True),
    ("explain about the department details understandable", True),
    ("what detail you have based on the department", True),
    ("what does this department do", True),
    ("what kind of stuff does this department handle", True),
    ("i want to understand this department properly", True),
    ("explain the department to me like I'm new here", True),
    ("tell me what this team actually does day to day", True),
    ("can you describe what happens in this department", True),
    ("brief me on this department", True),
    ("what's this department all about", True),
    ("give me the full picture here", True),
    ("walk me through this department", True),
    ("i'm new, what should i know about this team", True),
    ("everything you know about this department please", True),
    ("what info do you have on this dept", True),
    ("run me through what they do", True),
    ("pls explain this department", True),
    ("what is the work of this department", True),
    ("details about department", True),
    ("tell me about this department in detail", True),

    # --- NEAR MISSES: a specific subject, however broadly phrased ------------
    # Each of these contains breadth-flavoured wording but asks about ONE thing.
    # Treating them as breadth loses the actual answer, so they matter as much as
    # the positives above.
    ("give me an overview of the escalation process", False),
    ("summarize the escalation matrix for me", False),
    ("explain the onboarding process in detail", False),
    ("tell me about the KPIs", False),
    ("walk me through how a demand gets fulfilled", False),
    ("what does the weekly report cover", False),
    ("who leads this department", False),
    ("what systems does this team use", False),
    ("how do i escalate an issue", False),
    ("what is the target for timely fulfillment", False),
    ("describe the review cadence", False),
    ("give me a summary of the hiring process", False),
    # Glossary terms are specific things too. Caught by pre-flight, not by this set:
    # an earlier version of the breadth rule enumerated "process, report, role,
    # metric, team, system, policy" and a TERM matched none of them, so "what is the
    # difference between an OQL and an SQL" was classified breadth, retrieved
    # structurally, and reported that no comparison was documented -- 5 times out of
    # 5. Enumerating categories is the same trap as enumerating words.
    ("what is the difference between an OQL and an SQL", False),
    ("what does FDX stand for", False),
    ("what is an SQL", False),
    ("define OQL for me", False),
    ("explain what a Strategic Hire is", False),
]

# (query, expect_breadth, expect_all_departments)
SCOPE_PHRASINGS: list[tuple[str, bool, bool]] = [
    ("summarize all departments", True, True),
    ("give me a full overview of the company", True, True),
    ("what does the whole organisation do", True, True),
    ("tell me everything across every department", True, True),
    ("company-wide summary please", True, True),
    ("i want the big picture across the business", True, True),
    # Bare "everything" with no department named. Caught by the standing eval, not
    # here: the judgement alone reads these as scopeless because no department is
    # mentioned, and both stopped fanning out. In this product an unscoped
    # "everything" IS the company -- contrast the two CMO cases below.
    ("summarise everything", True, True),
    ("summarize everything and make it a document", True, True),
    ("tell me everything", True, True),
    # all-department QUESTION, not an all-department summary: pooled top-N, not
    # per-department coverage (section 4.6 -- these are different shapes)
    ("what are the escalation contacts across departments", False, True),
    # breadth is left UNASSERTED here (None). Measured 3-of-5 true, 2-of-5 false --
    # not a defect but a genuinely ambiguous request: it names a thing (hiring KPIs)
    # AND surveys departments, and either retrieval shape answers it reasonably.
    # Pinning a coin-flip would make this suite flap for no signal; the scope half
    # is what matters and it is stable, so that is what is asserted.
    ("which departments track hiring KPIs", None, True),
    # single department, breadth wording -- must NOT fan out
    ("tell me everything about CMO", True, False),
    ("give me a complete overview of TAG", True, False),
    ("summarize the FDE department and make it a document", True, False),
]

# Multi-turn drill-down: (context_key, followup, expect_drill_down).
# The follow-ups are phrased every way people actually phrase them -- named item,
# positional reference, bare pronoun, imperative -- and each is paired with a prior
# answer that actually contains what it refers to. Using one shared context for all
# of them would be testing something else: a follow-up about a team, asked after an
# answer that never mentioned teams, is genuinely not a drill-down.
CONTEXTS: dict[str, str] = {
    "kpis": (
        "user: What are the KPIs for TAG?\n"
        "assistant: The KPIs for the Talent Acquisition Group (TAG) include:\n"
        "1. WIG-1: Timely Fulfillment - percentage of demands fulfilled within 10 "
        "business days. Target 90%.\n"
        "2. WIG-2: Quality of Hire - percentage of hires passing probation.\n"
        "3. Strategic Hires - number of strategic hires in Data Engineering and "
        "GenAI.\n[source: tag-master-charter-profile.json]"),
    "teams": (
        "user: What teams sit under CMO?\n"
        "assistant: The five teams within the CMO are Pitch Lab, Capability "
        "Marketing, Capability Collateral, Capability Research, and CMD (Capability "
        "Management and Development) [source: cmo-profile.json]."),
    "report": (
        "user: What does the OQL report cover?\n"
        "assistant: The OQL report covers new OQLs created, OQL progress, and OQLs "
        "converted to SQLs. It is produced weekly and owned by the PMO for the "
        "Capability Office [source: tcg-profile.json]."),
}

DRILLDOWN_PHRASINGS: list[tuple[str, str, bool]] = [
    ("report", "tell me more about that", True),
    ("report", "explain more about the OQL report", True),
    ("report", "can you expand on that", True),
    ("kpis", "go deeper on the first one", True),
    ("kpis", "what about the second item specifically", True),
    ("kpis", "elaborate please", True),
    ("kpis", "more detail on that last point", True),
    ("kpis", "i'd like to know more", True),
    ("teams", "dig into the first team a bit", True),
    ("teams", "give me more on Pitch Lab", True),
    ("teams", "anything else on that topic", True),
    ("teams", "explain that further", True),

    # --- NEAR MISSES: not a request to go deeper -----------------------------
    # These are the dangerous direction. A fresh question misread as a drill-down
    # gets answered about the PREVIOUS turn's subject instead of its own.
    ("kpis", "make that a PDF", False),          # reformat, not expand
    ("kpis", "thanks, that's helpful", False),   # social
    ("kpis", "what systems does TAG use", False),  # fresh question, same department
    ("kpis", "who leads Labs", False),           # fresh question, other department
    ("kpis", "how do i raise a hiring request", False),  # fresh, procedural
    # Deliberately NOT tested: re-asking the previous question word for word.
    # Treating that as "tell me more" is defensible behaviour rather than a defect
    # -- the user has already read that answer -- so asserting either way would be
    # asserting a preference, not a contract.
]
