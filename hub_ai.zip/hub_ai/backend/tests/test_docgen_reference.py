"""Permanent regression suite: docgen reference resolution (CLAUDE.md 4.6, 4.8, 8.3).

    python -m tests.test_docgen_reference          # standard matrix
    python -m tests.test_docgen_reference --full    # every phrasing, 3 runs each

WHY THIS EXISTS
---------------
"<question about a department>" then "make it a document" asked for clarification
instead of resolving the pronoun. It was reported and fixed three times -- P-Cube,
Delivery Management, then Labs -- because every fix was verified against the one
phrasing that had been reported.

The department was never the variable. resolve_reference decided the whole outcome
on one non-deterministic `confident` flag from a single un-retried LLM call, and
that flag was phrasing-sensitive. Measured against a real Labs answer:

    "make it a document"    confident 3/3
    "make this a document"  confident 2/3   <- intermittent, passes then fails
    "make it document"      confident 0/3

So this suite fixes the matrix, not the anecdote: several departments crossed with
several phrasings, each phrasing repeated, so an intermittent 2/3 reports as a
failure instead of passing on luck.

The negative case matters just as much: with NO prior turn there is genuinely
nothing to resolve against, and the request must still ask for clarification
rather than resolve or claim the knowledge base lacks the answer.

Test hygiene (section 8.0): every conversation this creates is deleted in a
finally block, under a throwaway anon_user_id that carries a test prefix.
"""
from __future__ import annotations

import sys
import uuid

from fastapi.testclient import TestClient

import main
from clients import supabase

c = TestClient(main.app)
USER = f"e2e-docgen-ref-{uuid.uuid4()}"
FULL = "--full" in sys.argv

failures: list[str] = []
created: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f"  -- {detail}" if not ok else ""))
    if not ok:
        failures.append(f"{name}: {detail}")


# Turn 1 per department: a real question that answers from that department.
OPENERS = {
    "labs": "What is Labs' role, and who leads it?",
    "cmo": "What does the CMO department do?",
    "p_cube": "Who leads P-Cube?",
    "office_of_ceo": "How does the goal setting process work?",
}

# Turn 2: the pronoun-only docgen follow-up, in the shapes people actually type.
PHRASINGS_QUICK = ["make it document", "make this a document"]
PHRASINGS_FULL = PHRASINGS_QUICK + [
    "make it a document",
    "make that a document",
    "turn it into a document",
    "export it as a pdf",
    "put this in a spreadsheet",
]


def new_conversation() -> str:
    cid = c.post("/api/conversations",
                 json={"anon_user_id": USER}).json()["conversation_id"]
    created.append(cid)
    return cid


def ask(query: str, conversation_id: str, head_dept: str | None = None) -> dict:
    return c.post("/api/chat", json={
        "query": query, "head_dept": head_dept, "session_id": "docgen-ref-test",
        "anon_user_id": USER, "conversation_id": conversation_id}).json()


def run_pair(dept: str, opener: str, phrasing: str) -> None:
    """Turn 1 answers, then the pronoun follow-up must NOT ask for clarification."""
    cid = new_conversation()
    first = ask(opener, cid)
    if first.get("needs_clarification"):
        check(f"{dept} / opener answers", False,
              "turn 1 itself asked for clarification, so turn 2 proves nothing")
        return

    second = ask(phrasing, cid)
    unresolved = bool(second.get("unresolved_reference"))
    clarified = bool(second.get("needs_clarification"))
    lane = second.get("lane")

    check(f"{dept} / {phrasing!r} resolves the pronoun",
          not unresolved and not clarified,
          f"unresolved_reference={unresolved} needs_clarification={clarified} "
          f"answer={(second.get('answer') or '')[:90]!r}")
    check(f"{dept} / {phrasing!r} stays in the docgen lane",
          lane == "docgen", f"lane={lane}")


def main_run() -> int:
    phrasings = PHRASINGS_FULL if FULL else PHRASINGS_QUICK
    runs = 3 if FULL else 1

    print("=" * 92)
    print(f"### docgen reference resolution: {len(OPENERS)} departments x "
          f"{len(phrasings)} phrasings x {runs} run(s)")
    for dept, opener in OPENERS.items():
        for phrasing in phrasings:
            for _ in range(runs):
                run_pair(dept, opener, phrasing)

    print()
    print("### negative case: a pronoun with NO prior turn must still ask")
    for phrasing in ("make this a document", "make it document"):
        cid = new_conversation()
        r = ask(phrasing, cid)
        asked = bool(r.get("needs_clarification"))
        answer = (r.get("answer") or "").lower()
        check(f"no-context {phrasing!r} asks for clarification", asked,
              f"needs_clarification={asked} answer={answer[:90]!r}")
        # It must ask, and must not blame the knowledge base for a reference gap.
        check(f"no-context {phrasing!r} does not claim a knowledge-base gap",
              "not in the knowledge base" not in answer
              and "nothing in the knowledge base" not in answer,
              f"answer={answer[:110]!r}")

    print()
    print("=" * 92)
    if failures:
        print(f"FAILED ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
    else:
        print("ALL PASS")
    return 1 if failures else 0


if __name__ == "__main__":
    try:
        code = main_run()
    finally:
        # Section 8.0: guaranteed cleanup, not best-effort on the happy path.
        sb = supabase()
        for cid in created:
            try:
                sb.table("chat_turns").delete().eq("conversation_id", cid).execute()
                sb.table("conversations").delete().eq("id", cid).execute()
            except Exception as exc:      # noqa: BLE001
                print(f"  cleanup warning: {cid} -> {exc}")
        try:
            sb.table("user_memory").delete().eq("anon_user_id", USER).execute()
        except Exception:
            pass
        print(f"  cleaned up {len(created)} test conversations")
    sys.exit(code)
