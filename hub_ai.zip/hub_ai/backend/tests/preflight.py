"""Fast pre-flight over the shapes that keep breaking, before the long suites.

    python -m tests.preflight --base http://127.0.0.1:8040

Every case here exists because a change broke it and the break was only found
~40 minutes into a full run, against code that had since been edited again. Each
one runs in parallel, so the whole thing lands in about a minute and the long
suites are only started once these hold. This is a filter, not a replacement:
run_eval and run_matrix_18 remain the actual measurement.
"""
from __future__ import annotations

import argparse
import json
import sys
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tests.run_eval import BOILERPLATE, opening_words  # noqa: E402
from tests.run_matrix_18 import is_gap_report          # noqa: E402

# kind, query, head_dept, note
CASES = [
    # -- the gap / framing boundary, both directions (has oscillated twice) -----
    ("answer", "What is the difference between an OQL and an SQL?", "cmo",
     "both defined; a missing direct comparison is not a missing fact"),
    ("answer", "How does an OQL become an SQL?", "cmo",
     "transition described, just not in the question's words"),
    ("gap", "Who owns onboarding effectiveness?", "delivery_management",
     "owner genuinely not named"),
    ("gap", "How do I request SME support?", "fde_dcg",
     "request method recorded as unavailable"),
    # -- multi-part question where only ONE part is unrecorded ------------------
    ("answer", "Who leads Domain Consulting and what are its key activities?",
     "fde_dcg", "answer the recorded half; note the gap alongside, not first"),
    # -- answerable only INDIRECTLY: a reporting line, an owning team, a roster
    #    role. Every one of these regressed at some point by being reported as a
    #    gap because no sentence carried the exact title the question used.
    ("answer", "Who leads Pitch Lab?", "cmo",
     "'Reports to: CMO Lead' is recorded; a missing title is not a missing fact"),
    ("answer", "Who leads Capability Marketing and what does it do?", "cmo",
     "roster + description present"),
    ("answer", "Who owns the OQL Tracker?", "cmo",
     "owner recorded as a team rather than a person"),
    ("answer", "Who leads Solution Labs?", "labs", "reporting line recorded"),
    # -- Class 1: vague / entity-less must ask ---------------------------------
    ("clarify", "what are the requirements?", None, ""),
    ("clarify", "who do I contact?", None, ""),
    ("clarify", "can you tell me more?", None, "was swallowed by chitchat"),
    ("clarify", "who owns compliance?", None, "six departments list it"),
    # -- Class 2: breadth + one department must answer -------------------------
    ("answer", "summarize this department", "cmo", ""),
    ("answer", "brief me on this department", "support_services",
     "'brief' was missing from the breadth vocabulary"),
    ("answer", "give me an overview of TAG", None, "inferred scope"),
    # Same intent, worded the way people actually word it. These are the ones the
    # vocabulary approach could never reach: no listed breadth word appears in any
    # of them, and the first two are verbatim from a bug report. Kept as a spread
    # of wordings rather than one example, because passing on one phrasing and
    # failing the next is precisely how this class kept coming back.
    ("answer", "explain about the department details understandable", "fde_tcg",
     "reported; no breadth word present at all"),
    ("answer", "what detail you have based on the department", "tag", "reported"),
    ("answer", "what kind of stuff does this department handle",
     "delivery_management", ""),
    ("answer", "i want to understand this department properly", "p_cube", ""),
    ("answer", "details about department", "labs", "ungrammatical fragment"),
    ("answer", "tell me what this team actually does day to day",
     "customer_success_management", ""),
    # A single-property question must NOT be swept into breadth by the same logic.
    ("answer", "who leads this department", "cmo",
     "one fact, not the whole picture -- the precision side of the breadth test"),
    # -- chitchat stays chitchat ----------------------------------------------
    ("chitchat", "thanks!", None, ""),
    ("chitchat", "morning! hope you're well", None,
     "contraction folded into an orphan token and broke this"),
    # -- long fan-out answer: the shape that attracts a trailing sign-off ------
    ("answer", "Across all departments, who are the department heads?", None,
     "long list; model reaches for a closing"),
]


def post(base, q, hd, i):
    req = urllib.request.Request(
        base + "/api/chat",
        data=json.dumps({"query": q, "head_dept": hd,
                         "session_id": f"preflight-{i}"}).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    return json.loads(urllib.request.urlopen(req, timeout=300).read())


def judge(kind, d):
    ans = (d.get("answer") or "").strip()
    clarified = bool(d.get("needs_clarification"))
    lane = d.get("lane")
    if BOILERPLATE.search(ans):
        return False, "contains assistant boilerplate"
    if kind == "clarify":
        return (clarified, "" if clarified else f"did not ask: {ans[:80]!r}")
    if kind == "chitchat":
        if lane != "chitchat":
            return False, f"lane={lane!r}, expected chitchat"
        if d.get("sources"):
            return False, "chitchat cited sources"
        return True, ""
    if kind == "gap":
        if clarified:
            return False, "asked for clarification instead of reporting the gap"
        return (is_gap_report(ans), "" if is_gap_report(ans)
                else f"did not report the gap: {ans[:80]!r}")
    # kind == "answer"
    if clarified:
        return False, f"asked for clarification: {ans[:80]!r}"
    if d.get("grounded") is False:
        return False, f"returned not-grounded: {ans[:80]!r}"
    if is_gap_report(ans):
        return False, f"led with a gap instead of answering: {ans[:80]!r}"
    if not d.get("sources"):
        return False, "no sources"
    return True, ""


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8000")
    args = ap.parse_args()

    def go(item):
        i, (kind, q, hd, note) = item
        try:
            d = post(args.base, q, hd, i)
        except Exception as exc:
            return kind, q, note, False, f"{type(exc).__name__}: {exc}", ""
        ok, why = judge(kind, d)
        return kind, q, note, ok, why, (d.get("answer") or "")

    with ThreadPoolExecutor(max_workers=6) as ex:
        results = list(ex.map(go, enumerate(CASES)))

    answers = []
    passed = 0
    for kind, q, note, ok, why, ans in results:
        passed += ok
        answers.append(ans)
        print(f"  {'OK  ' if ok else 'FAIL'} [{kind:<8}] {q[:56]!r}")
        if not ok:
            print(f"         {why}")
            if note:
                print(f"         (expected because: {note})")

    openers = [o for o in (opening_words(a) for a in answers) if o]
    counts = Counter(openers)
    top, n = counts.most_common(1)[0] if counts else ("", 0)
    varied = (n / len(openers)) <= 0.35 if openers else True
    print(f"\n  opening variety: {len(set(openers))} distinct across {len(openers)}; "
          f"most common {top!r} at {n}/{len(openers)}"
          f"{'' if varied else '   <-- TOO REPETITIVE'}")

    print(f"\npre-flight {passed}/{len(results)}"
          + ("" if passed == len(results) and varied
             else "   -- fix before starting the long suites"))
    return 0 if (passed == len(results) and varied) else 1


if __name__ == "__main__":
    sys.exit(main())
