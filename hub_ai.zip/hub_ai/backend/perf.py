"""Per-stage latency instrumentation (CLAUDE.md section 8.2).

A Stopwatch is threaded through one request so every pipeline stage records its own
wall time. Nothing here guesses at cost -- the numbers come from real calls.

Persisting to latency_log is best-effort: if the table does not exist yet the timing
is still returned to the caller and merely not stored.
"""
from __future__ import annotations

import time
from contextlib import contextmanager
from typing import Any, Callable


class Stopwatch:
    def __init__(self, on_stage: "Callable[[str], None] | None" = None) -> None:
        self.stages: dict[str, float] = {}
        self._start = time.perf_counter()
        # Section 4.13: live status rides on the SAME hook as latency measurement,
        # so a status message cannot describe a stage that did not actually run,
        # and a newly added stage cannot silently go unreported. Never allowed to
        # break the request -- status is cosmetic, the answer is not.
        self._on_stage = on_stage

    @contextmanager
    def stage(self, name: str):
        if self._on_stage is not None:
            try:
                self._on_stage(name)
            except Exception:
                pass
        t0 = time.perf_counter()
        try:
            yield
        finally:
            ms = (time.perf_counter() - t0) * 1000.0
            self.stages[name] = self.stages.get(name, 0.0) + ms

    def add(self, name: str, ms: float) -> None:
        self.stages[name] = self.stages.get(name, 0.0) + ms

    @property
    def total_ms(self) -> float:
        return (time.perf_counter() - self._start) * 1000.0

    def summary(self) -> dict[str, Any]:
        total = self.total_ms
        measured = sum(self.stages.values())
        out = {k: round(v, 1) for k, v in self.stages.items()}
        out["_total"] = round(total, 1)
        out["_unattributed"] = round(total - measured, 1)
        return out


def persist(sw: Stopwatch, query: str, lane: str | None,
            head_dept_count: int, searched_all: bool) -> None:
    """Write one row to latency_log. Never raises."""
    try:
        from clients import supabase
        supabase().table("latency_log").insert({
            "query": query[:2000],
            "lane": lane,
            "head_dept_count": head_dept_count,
            "searched_all": searched_all,
            "total_ms": round(sw.total_ms, 1),
            "stages": {k: round(v, 1) for k, v in sw.stages.items()},
        }).execute()
    except Exception:
        pass
