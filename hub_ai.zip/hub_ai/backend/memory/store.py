"""Conversation memory & long-term memory (CLAUDE.md sections 4.11, 4.12).

Identity is `anon_user_id` -- a UUID the client mints and stores locally. It is not
authentication, and nothing here should ever be treated as if it were.

Conversation scope mirrors the UI's split: a conversation carries the head_dept it
was started under, or NULL when it was started from the home view. The sidebar's
per-department Recents and the global Recents are the same query with and without
that filter.
"""
from __future__ import annotations

import re
from typing import Any

from clients import openai_client, supabase
from config import MEMORY_MAX_LONG_TERM, MEMORY_TURN_WINDOW, OPENAI_CHAT_MODEL


# ----------------------------------------------------------------- conversations

def create_conversation(anon_user_id: str, head_dept: str | None = None) -> dict[str, Any]:
    row = {"anon_user_id": anon_user_id, "head_dept": head_dept}
    data = supabase().table("conversations").insert(row).execute().data or []
    return data[0] if data else row


def get_conversation(conversation_id: str) -> dict[str, Any] | None:
    rows = (supabase().table("conversations").select("*")
            .eq("id", conversation_id).execute().data or [])
    return rows[0] if rows else None


def list_conversations(anon_user_id: str, head_dept: str | None = None,
                       scope: str = "auto", limit: int = 30) -> list[dict[str, Any]]:
    """Conversations for the sidebar, newest first.

    scope="department" -> only that department's conversations
    scope="global"     -> only home-view conversations (head_dept is null)
    scope="all"        -> everything for this user
    scope="auto"       -> department when head_dept given, else global
    """
    q = (supabase().table("conversations")
         .select("id,head_dept,title,updated_at,created_at")
         .eq("anon_user_id", anon_user_id)
         .order("updated_at", desc=True).limit(limit))
    if scope == "auto":
        scope = "department" if head_dept else "global"
    if scope == "department":
        if not head_dept:
            return []
        q = q.eq("head_dept", head_dept)
    elif scope == "global":
        q = q.is_("head_dept", "null")
    return q.execute().data or []


def _escape_like(term: str) -> str:
    """Neutralise PostgREST/SQL LIKE wildcards so a literal % or _ stays literal."""
    return term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def search_conversations(anon_user_id: str, query: str,
                         limit: int = 25) -> list[dict[str, Any]]:
    """Search this user's own conversations by title AND by message content.

    Two passes against the same user's rows, merged newest-first:
      1. conversations.title  -- what the sidebar shows, so it is what people
         recall and type
      2. chat_turns.content   -- what was actually said, which is how someone
         finds a thread whose title does not mention the term they remember

    Scoped to anon_user_id on both passes, so one person's search can never reach
    another's history. Content matches carry the matching excerpt so a result can
    show WHY it matched rather than just a title.
    """
    term = (query or "").strip()
    if not term:
        return []
    pattern = f"%{_escape_like(term)}%"
    sb = supabase()

    mine = (sb.table("conversations")
            .select("id,head_dept,title,updated_at")
            .eq("anon_user_id", anon_user_id)
            .order("updated_at", desc=True).limit(400).execute().data or [])
    if not mine:
        return []
    by_id = {r["id"]: r for r in mine}

    hits: dict[str, dict[str, Any]] = {}

    # 1. title matches
    for row in mine:
        if term.lower() in (row.get("title") or "").lower():
            hits[row["id"]] = {**row, "match": "title", "excerpt": None}

    # 2. content matches, restricted to this user's conversation ids
    try:
        turns = (sb.table("chat_turns")
                 .select("conversation_id,role,content,created_at")
                 .in_("conversation_id", list(by_id))
                 .ilike("content", pattern)
                 .order("created_at", desc=True)
                 .limit(200).execute().data or [])
    except Exception:
        turns = []
    for t in turns:
        cid = t["conversation_id"]
        if cid in hits or cid not in by_id:
            continue                      # a title match is the stronger signal
        hits[cid] = {**by_id[cid], "match": "content",
                     "excerpt": _excerpt(t.get("content") or "", term),
                     "excerpt_role": t.get("role")}

    ordered = sorted(hits.values(),
                     key=lambda r: (r.get("updated_at") or ""), reverse=True)
    return ordered[:limit]


def _excerpt(content: str, term: str, width: int = 160) -> str:
    """A window of `content` around the first case-insensitive hit on `term`."""
    text = " ".join((content or "").split())
    at = text.lower().find(term.lower())
    if at < 0:
        return text[:width]
    start = max(0, at - width // 3)
    end = min(len(text), start + width)
    return ("..." if start else "") + text[start:end] + ("..." if end < len(text) else "")


def delete_conversation(conversation_id: str) -> None:
    # chat_turns cascade via the FK.
    supabase().table("conversations").delete().eq("id", conversation_id).execute()


def set_title(conversation_id: str, title: str) -> None:
    supabase().table("conversations").update(
        {"title": title[:200], "updated_at": "now()"}).eq("id", conversation_id).execute()


# -------------------------------------------------------------------- chat turns

def get_turns(conversation_id: str, limit: int | None = None) -> list[dict[str, Any]]:
    q = (supabase().table("chat_turns")
         .select("role,content,head_dept,sources,created_at")
         .eq("conversation_id", conversation_id)
         .order("created_at", desc=False))
    rows = q.execute().data or []
    return rows[-limit:] if limit else rows


def record_turn(conversation_id: str, role: str, content: str,
                head_dept: str | None = None,
                sources: list[dict] | None = None) -> None:
    supabase().table("chat_turns").insert({
        "conversation_id": conversation_id,
        "role": role,
        "content": content,
        "head_dept": head_dept,
        "sources": sources,
    }).execute()
    supabase().table("conversations").update(
        {"updated_at": "now()"}).eq("id", conversation_id).execute()


def recent_context(conversation_id: str | None) -> str:
    """The last MEMORY_TURN_WINDOW turns, rendered for a prompt.

    This is interpretation context only. It lets "what about last quarter?" resolve
    against the previous turn. It must never be used to widen head_dept scope or to
    satisfy the groundedness gate -- only retrieved passages can do that.
    """
    if not conversation_id:
        return ""
    try:
        turns = get_turns(conversation_id, limit=MEMORY_TURN_WINDOW)
    except Exception:
        return ""
    if not turns:
        return ""
    lines = [f"{t['role']}: {(t.get('content') or '').strip()[:600]}" for t in turns]
    return "\n".join(lines)


def last_assistant_answer(conversation_id: str | None, cap: int = 4000) -> str:
    """The most recent assistant answer, in full.

    Separate from recent_context() on purpose. That renders every turn clipped to
    600 characters, which is the right budget for interpreting a follow-up but the
    wrong one for a drill-down: the item being drilled into ("the fourth KPI") is
    frequently past the clip, and an answer the model cannot see the end of cannot
    be expanded on without repeating it.
    """
    if not conversation_id:
        return ""
    try:
        turns = get_turns(conversation_id)
    except Exception:
        return ""
    for turn in reversed(turns or []):
        if turn.get("role") == "assistant":
            return (turn.get("content") or "").strip()[:cap]
    return ""


def generate_title(first_user_turn: str) -> str:
    """Short conversation title from the opening question."""
    text = (first_user_turn or "").strip()
    if not text:
        return "New chat"
    try:
        resp = openai_client().chat.completions.create(
            model=OPENAI_CHAT_MODEL, temperature=0,
            messages=[
                {"role": "system", "content":
                    "Title this conversation in at most 6 words. No quotes, no trailing "
                    "punctuation, no preamble. Reuse the question's own wording."},
                {"role": "user", "content": text[:500]},
            ],
        )
        title = (resp.choices[0].message.content or "").strip().strip('"').strip()
        if title:
            return title[:80]
    except Exception:
        pass
    return (text[:50] + ("..." if len(text) > 50 else ""))


# --------------------------------------------------------------- long-term memory

# Section 4.12 / section 9: never persist sensitive personal detail or anything
# sourced from a do_not_disclose-protected fact. This is a hard filter applied to
# every candidate regardless of what produced it, including a later instruction
# that appears to ask for it.
_BLOCK_PATTERNS = re.compile(
    # pay
    r"\b(salary|salaries|compensation|payroll|ctc|bonus|increment|hike|"
    # employment standing -- "performance improvement plan" spelled out was slipping
    # through a pattern that only had `pip` and `performance review`
    r"appraisal|performance\s+(review|improvement|rating|score)|improvement\s+plan|"
    r"pip\b|disciplinary|misconduct|grievance|warning\s+letter|probation|"
    r"termination|terminated|resignation|notice\s+period|layoff|redundan|"
    # health & protected characteristics
    r"health|medical|diagnosis|illness|disability|pregnan|mental\s+health|"
    r"religion|caste|ethnicity|sexual\s+orientation|"
    # security / identifiers
    r"vulnerability|incident\s+specifics|risk\s+register|credential|password|"
    r"bank\s+account|ssn|aadhaar|passport|visa\s+status|"
    # explicit classification markers
    r"confidential|do\s+not\s+disclose|restricted|internal\s+only|"
    # figures that suggest knowledge-base content rather than a preference
    r"inr\s*\d|crore|lakh|\$\s*\d{3,})", re.I)


def is_safe_memory(text: str) -> tuple[bool, str]:
    """Gate for anything about to be written to user_memory."""
    t = (text or "").strip()
    if not t:
        return False, "empty"
    if len(t) > 300:
        return False, "too long to be an interaction preference"
    m = _BLOCK_PATTERNS.search(t)
    if m:
        return False, f"matched blocked pattern {m.group(0)!r}"
    return True, ""


def list_memories(anon_user_id: str) -> list[dict[str, Any]]:
    return (supabase().table("user_memory")
            .select("id,memory_text,category,created_at")
            .eq("anon_user_id", anon_user_id)
            .order("created_at", desc=True).execute().data or [])


def add_memory(anon_user_id: str, memory_text: str, category: str | None = None,
               source_conversation_id: str | None = None) -> dict[str, Any] | None:
    ok, why = is_safe_memory(memory_text)
    if not ok:
        return None
    rows = supabase().table("user_memory").insert({
        "anon_user_id": anon_user_id,
        "memory_text": memory_text.strip(),
        "category": category,
        "source_conversation_id": source_conversation_id,
    }).execute().data or []
    return rows[0] if rows else None


def delete_memory(memory_id: str) -> None:
    supabase().table("user_memory").delete().eq("id", memory_id).execute()


def delete_all_memories(anon_user_id: str) -> None:
    supabase().table("user_memory").delete().eq("anon_user_id", anon_user_id).execute()


def memory_context(anon_user_id: str | None) -> str:
    """Long-term memory rendered for a prompt. Interpretation context only."""
    if not anon_user_id:
        return ""
    try:
        rows = list_memories(anon_user_id)[:MEMORY_MAX_LONG_TERM]
    except Exception:
        return ""
    return "\n".join(f"- {r['memory_text']}" for r in rows) if rows else ""


_EXTRACT_SYSTEM = """Propose durable interaction preferences worth remembering about
this user across future conversations.

Return JSON only: {"memories": [{"memory_text": "...", "category": "..."}]}
category is one of: preference, default_scope, fact.

Only propose things that are:
- about how the user likes to interact, or which departments they habitually ask about
- still true next month
- stated or clearly demonstrated by the user, not inferred from a single question

NEVER propose:
- anything about compensation, payroll, performance, health, or discipline
- any figure, name or detail drawn from the knowledge base content itself
- anything marked confidential or restricted
- personal details about the user or any third party

An empty list is the correct and expected answer most of the time. When in doubt,
return nothing."""


def propose_memories(anon_user_id: str, conversation_id: str) -> list[dict[str, Any]]:
    """Conservative end-of-conversation extraction. Every candidate still passes
    is_safe_memory() before being written."""
    turns = get_turns(conversation_id)
    if len(turns) < 2:
        return []
    transcript = "\n".join(f"{t['role']}: {(t.get('content') or '')[:400]}" for t in turns)
    try:
        resp = openai_client().chat.completions.create(
            model=OPENAI_CHAT_MODEL, temperature=0,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": _EXTRACT_SYSTEM},
                      {"role": "user", "content": transcript[:6000]}],
        )
        import json
        candidates = json.loads(resp.choices[0].message.content or "{}").get("memories", [])
    except Exception:
        return []

    written = []
    for cand in candidates[:5]:
        text = (cand or {}).get("memory_text", "")
        row = add_memory(anon_user_id, text, (cand or {}).get("category"), conversation_id)
        if row:
            written.append(row)
    return written
