-- HUB AI — 002_hybrid_search.sql
-- Track B, build-order step 2: hybrid retrieval RPC (CLAUDE.md section 4.4, RRF revision).
-- Apply AFTER 001_schema.sql.
--
-- Reciprocal Rank Fusion: each arm contributes 1/(60 + rank_position), so the two arms
-- are combined on rank, not on raw score. This replaces the earlier draft that ordered
-- cosine similarity (~0.3-0.8) against ts_rank (~0.01-0.1) head to head and therefore
-- discarded almost every keyword hit. The full outer join on id also means a chunk that
-- matches both arms is one fused row scoring the sum of both contributions, rather than
-- two rows competing for the same match_count slots.
--
-- A chunk found by only one arm gets coalesce(rank, 1000) for the missing arm, i.e. a
-- near-zero 1/1060 contribution from that side rather than being dropped.
--
-- Scoping note: filter_head_dept has no default and is compared with "=", so a NULL
-- argument returns zero rows rather than searching everything. Fail-closed by design,
-- per section 4.4. The "search all departments" path (build-order step 8) calls this
-- once per HD and merges client-side; it never passes NULL.

create or replace function hybrid_search(
  query_embedding vector(1536),
  query_text text,
  filter_head_dept text,
  match_count int default 8
)
returns table (id uuid, content text, head_dept text, source_file text, score float)
language sql as $$
  with vector_matches as (
    select id, content, head_dept, source_file,
           row_number() over (order by embedding <=> query_embedding) as rank
    from documents
    where head_dept = filter_head_dept
    order by embedding <=> query_embedding
    limit match_count * 2
  ),
  text_matches as (
    select id, content, head_dept, source_file,
           row_number() over (order by ts_rank(content_tsv, plainto_tsquery('english', query_text)) desc) as rank
    from documents
    where head_dept = filter_head_dept
      and content_tsv @@ plainto_tsquery('english', query_text)
    order by ts_rank(content_tsv, plainto_tsquery('english', query_text)) desc
    limit match_count * 2
  ),
  fused as (
    select
      coalesce(v.id, t.id) as id,
      coalesce(v.content, t.content) as content,
      coalesce(v.head_dept, t.head_dept) as head_dept,
      coalesce(v.source_file, t.source_file) as source_file,
      (1.0 / (60 + coalesce(v.rank, 1000))) + (1.0 / (60 + coalesce(t.rank, 1000))) as score
    from vector_matches v
    full outer join text_matches t on v.id = t.id
  )
  select id, content, head_dept, source_file, score
  from fused
  order by score desc
  limit match_count;
$$;
