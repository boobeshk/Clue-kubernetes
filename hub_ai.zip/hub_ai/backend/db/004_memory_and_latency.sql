-- HUB AI — 004_memory_and_latency.sql
-- Build-order step 9: conversation memory + long-term memory (CLAUDE.md 4.11/4.12),
-- plus the latency_log table required by section 8.2.
--
-- Apply AFTER 001/002. Re-runnable.

-- ---------------------------------------------------------------------------
-- conversations — section 4.11
-- head_dept is nullable on purpose: NULL means the conversation was started from
-- the home view and belongs in the global Recents list; a set value scopes it to
-- that department's own chat view, matching the original UI's split.
-- ---------------------------------------------------------------------------
create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  anon_user_id text not null,
  head_dept text,
  title text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists conversations_anon_user_idx
  on conversations (anon_user_id, updated_at desc);
create index if not exists conversations_head_dept_idx
  on conversations (anon_user_id, head_dept, updated_at desc);

-- ---------------------------------------------------------------------------
-- chat_turns — section 4.11
-- ---------------------------------------------------------------------------
create table if not exists chat_turns (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  role text not null,
  content text not null,
  head_dept text,
  sources jsonb,
  created_at timestamptz default now()
);
create index if not exists chat_turns_conversation_idx
  on chat_turns (conversation_id, created_at);

-- ---------------------------------------------------------------------------
-- user_memory — section 4.12
-- Durable, low-sensitivity interaction context only. Never a second copy of
-- knowledge-base content, never anything do_not_disclose-protected, never
-- personal/sensitive detail about the user or a third party (section 9).
-- ---------------------------------------------------------------------------
create table if not exists user_memory (
  id uuid primary key default gen_random_uuid(),
  anon_user_id text not null,
  memory_text text not null,
  category text,
  source_conversation_id uuid references conversations(id),
  created_at timestamptz default now()
);
create index if not exists user_memory_anon_user_idx on user_memory (anon_user_id);

-- ---------------------------------------------------------------------------
-- latency_log — section 8.2
-- Per-request per-stage timings, so the bottleneck is read off real data rather
-- than guessed at. stages is {stage_name: milliseconds}.
-- ---------------------------------------------------------------------------
create table if not exists latency_log (
  id uuid primary key default gen_random_uuid(),
  query text,
  lane text,
  head_dept_count int,
  searched_all boolean,
  total_ms float,
  stages jsonb,
  created_at timestamptz default now()
);
create index if not exists latency_log_created_idx on latency_log (created_at desc);
create index if not exists latency_log_lane_idx on latency_log (lane, created_at desc);

-- ---------------------------------------------------------------------------
-- RLS — section 4.4.1. No policies: anon/authenticated read nothing, the
-- backend's service role key bypasses RLS and is unaffected.
-- chat_turns and user_memory hold user-entered text, so this matters more here
-- than on the knowledge-base tables.
-- ---------------------------------------------------------------------------
alter table conversations enable row level security;
alter table chat_turns    enable row level security;
alter table user_memory   enable row level security;
alter table latency_log   enable row level security;
