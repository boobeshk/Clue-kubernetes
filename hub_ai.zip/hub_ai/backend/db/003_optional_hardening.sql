-- HUB AI — 003_optional_hardening.sql
--
-- ***  OPTIONAL. Not required by CLAUDE.md. 001 + 002 are sufficient for build step 2.  ***
--
-- RLS moved OUT of this file: section 4.4.1 made it mandatory, so it now lives in
-- 001_schema.sql. What remains are two suggestions the spec does not cover.
-- Each block is independent — run either, both, or neither.


-- ---------------------------------------------------------------------------
-- BLOCK 1 — Index on documents.source_file (recommended)
--
-- Section 4.5 requires an orphan check in BOTH run modes, and full re-embed deletes a
-- scope's rows before reprocessing. Both delete by storage path:
--     delete from documents where source_file = '<storage_path>';
-- Section 4.3 defines no index on source_file, so each of those is a sequential scan
-- over every chunk in the table. Cheap at 90+ files, steadily worse as the KB grows.
-- ---------------------------------------------------------------------------
create index if not exists documents_source_file_idx
  on documents (source_file);


-- ---------------------------------------------------------------------------
-- BLOCK 2 — hybrid_search hardening (recommended)
--
-- Re-declares the RRF function from 002_hybrid_search.sql with an IDENTICAL body, plus:
--   stable           — it only reads; lets the planner reuse the result within a statement
--   security invoker — explicit (already the default; stated so it cannot drift later)
--   set search_path  — pins name resolution and silences Supabase's
--                      "function_search_path_mutable" security lint
--
-- Run only AFTER 002_hybrid_search.sql. If you edit the RRF query in 002, mirror the
-- change here — these two bodies must not drift apart.
-- ---------------------------------------------------------------------------
create or replace function hybrid_search(
  query_embedding vector(1536),
  query_text text,
  filter_head_dept text,
  match_count int default 8
)
returns table (id uuid, content text, head_dept text, source_file text, score float)
language sql
stable
security invoker
set search_path = public, extensions
as $$
  with vector_matches as (
    select id, content, head_dept, source_file,
           row_number() over (order by embedding <=> query_embedding) as rank
    from documents
    where head_dept = filter_head_dept
    order by embedding <=> query_embedding
    limit match_count * 2
  ),
  text_matches as (
    select id, content, head_dept, source_file,
           row_number() over (order by ts_rank(content_tsv, plainto_tsquery('english', query_text)) desc) as rank
    from documents
    where head_dept = filter_head_dept
      and content_tsv @@ plainto_tsquery('english', query_text)
    order by ts_rank(content_tsv, plainto_tsquery('english', query_text)) desc
    limit match_count * 2
  ),
  fused as (
    select
      coalesce(v.id, t.id) as id,
      coalesce(v.content, t.content) as content,
      coalesce(v.head_dept, t.head_dept) as head_dept,
      coalesce(v.source_file, t.source_file) as source_file,
      (1.0 / (60 + coalesce(v.rank, 1000))) + (1.0 / (60 + coalesce(t.rank, 1000))) as score
    from vector_matches v
    full outer join text_matches t on v.id = t.id
  )
  select id, content, head_dept, source_file, score
  from fused
  order by score desc
  limit match_count;
$$;
