"""Groundedness gate (CLAUDE.md section 4.7).

Three stages:

  1. pre-gate      if nothing retrieved clears the relevance threshold, return
                   "not found in the knowledge base" and never call the generator.
  2. generation    answer strictly from the supplied chunks, with citations, under
                   the department's do_not_disclose constraints.
  3. post-gate     re-check every claim in the draft against the chunks; drop or
                   flag anything unsupported before the answer is returned.

On the threshold: section 4.7 says "if the top retrieval score is below a configured
threshold". Since section 4.4 became RRF, hybrid_search's score is a pure function of
rank position -- the top hit scores ~0.0164-0.0328 regardless of whether it is
relevant -- so thresholding on it would gate on nothing. The gate therefore
thresholds on the reranker's 0-10 relevance score, which is the first number in the
pipeline that actually measures relevance. GROUNDEDNESS_MIN_RELEVANCE is the knob.
"""
from __future__ import annotations

import json
import re
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

import responder
from clients import db_call, openai_client, supabase
from config import (DRILLDOWN_MIN_RELEVANCE, GROUNDEDNESS_MIN_RELEVANCE,
                    OPENAI_CHAT_MODEL)
from retriever.retriever import Hit, is_blank_content

def not_found_message(scope_label: str) -> str:
    """Composed, not canned (section 4.6)."""
    return responder.compose("not_found", {"scope": scope_label})


def blank_section_message(scope_label: str, sources: list[str], section: str | None) -> str:
    return responder.compose("blank_section", {
        "scope": scope_label,
        "section": section,
        "source_files": sources,
        "detail": "every field in that section reads 'Information not available in "
                  "the documentation'",
    })


@dataclass
class Answer:
    text: str
    sources: list[dict[str, str]] = field(default_factory=list)
    grounded: bool = True
    dropped_claims: list[str] = field(default_factory=list)
    top_relevance: float | None = None
    # True when the section exists but every field is unfilled. A structured
    # flag, because the message itself is composed per request and cannot be
    # matched on wording.
    blank_section: bool = False
    # Departments in scope whose data could not be retrieved (section 4.6).
    unavailable_departments: list[str] = field(default_factory=list)


def do_not_disclose_for(head_depts: list[str]) -> list[str]:
    """Confidentiality constraints declared in the source profiles.

    Stored in documents.metadata->file_meta->do_not_disclose on each profile_text
    chunk rather than embedded as retrievable text: the restriction strings name the
    very figures they protect, so indexing them would make those retrievable.
    """
    if not head_depts:
        return []
    rows = (db_call(lambda: supabase().table("documents")
                    .select("metadata")
                    .in_("head_dept", head_depts)
                    .eq("metadata->>section", "profile_text")
                    .execute()).data or [])
    rules: list[str] = []
    for r in rows:
        for rule in ((r.get("metadata") or {}).get("file_meta") or {}).get("do_not_disclose") or []:
            if isinstance(rule, str) and rule.strip() and rule not in rules:
                rules.append(rule.strip())
    return rules


_ANSWER_SYSTEM = """You answer questions about an internal company knowledge base.

Absolute rules:
- Use ONLY the numbered context passages. You have no other knowledge.
- If the passages do not contain the answer, say so plainly. Never fill a gap.
- A passage reading "Information not available in the documentation" is not an
  answer - report that the documentation does not record it.
- Cite the source file for every fact, inline, as [source: <the source file value shown
  on that passage>]. Use the file name exactly as given. NEVER cite a passage number.
- Exactly ONE file per bracket. Two sources means two brackets:
  "[source: a.json] [source: b.json]", never "[source: a.json, b.json]".
- Be accurate and specific.

Voice: write like a knowledgeable colleague answering a question, not like a form
letter. Warmth is welcome, and it comes from HOW you write -- phrasing that fits
this particular question, an aside that genuinely helps, saying openly when the
records are thin or the picture is messier than the question assumes. It does not
come from a greeting bolted onto the front. A fixed opener reused on every answer
("Sure!", "Great question!", "Happy to help!") is a template wearing a friendly
face: it carries no information and reads worse each time someone sees it.

So vary your openings naturally and let the substance arrive early. Never use
these -- they are assistant boilerplate rather than warmth: "As an AI", "Based on
the provided passages", "Here's what I found", "I hope this helps", "Let me know
if you have any questions", "Feel free to ask", "Certainly!", "Of course!".

Answering is the default; reporting a gap is the exception. Work through it in
this order, every time:

1. Does anything in the passages answer the question, directly OR indirectly?
   Indirectly counts. A reporting line, an owning team, a parent function, a
   role listed on a roster, two terms defined separately -- these ANSWER
   questions about leadership, ownership and differences even when no sentence
   is phrased the way the question is. Use them.

   Two things are NOT indirect answers, and treating them as such is fabrication:
     * a field that says "Information not available in the documentation" -- that
       is the documentation stating it does not know, so neither do you;
     * something merely adjacent to what was asked. A tracker that RECORDS
       requests is not a method for MAKING one; a report about a process is not
       the process. Never present the adjacent thing as the answer, and never
       bridge the gap with "typically", "generally" or "you would usually" --
       those words mean the passages did not say it.

2. Only if NOTHING in the passages bears on the question, say so plainly, in the
   first sentence: "The documentation does not name an owner for X." Do not
   soften that into a partial answer about something adjacent.

3. If the question has several parts and the passages cover some, START WITH
   WHAT IS RECORDED -- even if the unrecorded part was asked first -- and note
   the missing piece afterwards.

A missing TITLE, WORDING or FRAMING is never a missing fact. Concretely:

  "Who leads Pitch Lab?" with "Reports to: CMO Lead" in the passages
    -> "Pitch Lab reports to the CMO Lead [source: f.json]", plus, if true,
       that no separate Pitch Lab lead is named.
    NOT "The documentation does not name a leader for Pitch Lab."

  "What is the difference between an OQL and an SQL?" with both defined
    -> give both definitions; that IS the difference.
    NOT "The documentation does not provide a direct comparison."

  "Who leads Domain Consulting and what are its key activities?" with the
  activities described but no leader named
    -> "Domain Consulting runs X and Y [source: f.json]. The documentation does
       not name who leads it [source: f.json]."
    NOT "The documentation does not name a leader. However, it does describe..."

Each wrong version states only true things, and each is still a bad answer: it
withholds what the sources do say and reads as a refusal of a question that was
answerable.
"""

_VERIFY_SYSTEM = """You audit a draft answer against the context passages it was
built from.

Split the draft into individual factual claims. For each, decide whether the context
passages support it.

Return JSON only:
{"claims": [{"claim": "<text>", "supported": true|false, "why": "<short>"}]}

Supported means a passage states it, even in different words or split across two
passages. Paraphrase is fine; exact wording is not required.

Unsupported means the claim introduces specifics -- a number, name, date, target or
causal link -- that no passage states. Generic connective phrasing and restatements of
the question are not claims; omit them entirely.

Be conservative about calling something unsupported: only do so when you cannot point
to the passage text that carries it."""

_REWRITE_SYSTEM = """Rewrite the answer with the listed unsupported statements removed.

Keep everything else exactly as it was, including the [source: filename] citations.
Do not add new information, do not soften into vagueness, and do not mention that
anything was removed. If removing them leaves nothing at all, return an empty string
-- do not invent a closing remark and do not write a refusal; the caller handles that
case."""


def _stripped_completely(verified: str, dropped: list[str]) -> bool:
    """True when claim verification removed the entire answer."""
    import re as _re
    if not verified.strip():
        return True
    return bool(dropped) and not _re.search(r"\[source:", verified, _re.I)


def _context(hits: list[Hit], max_chars: int | None = None) -> str:
    # Passages are labelled by source file rather than by number, so the model cannot
    # fall back to citing "[source: 1]".
    # max_chars caps each passage: a broad all-department summary carries ~27 profile
    # chunks (~89k chars), and the per-department paragraph it produces does not need
    # every one of them in full.
    parts = []
    for i, h in enumerate(hits):
        body = h.content if max_chars is None else h.content[:max_chars]
        parts.append(
            f"--- passage {i+1} | source file: {h.source_name} | "
            f"department: {h.head_dept}\n{body}")
    return "\n\n".join(parts)


def is_blank_section(hit: Hit) -> bool:
    """True when a passage is a real section whose fields were never filled in.

    Shared with the reranker (which scales such passages down) so both agree on what
    "blank" means.
    """
    return is_blank_content(hit.content)


# The source data marks an individually unknown field with this exact sentinel,
# e.g. "Request method: Information not available in the documentation". A whole
# section of these is already handled by is_blank_section; this catches a SINGLE
# unfilled field inside an otherwise well-populated section, which is different and
# more dangerous: the surrounding text gives the model plenty of related material to
# build a plausible procedure out of. Twice the prompt alone failed to stop it --
# "How do I request SME support?" came back as "you can use the SME Request
# Tracker", which tracks requests rather than being how one is made. So the
# constraint is derived from the data instead of asked for.
_UNAVAILABLE_FIELD = re.compile(
    r"^\s*([A-Z][A-Za-z /&-]{2,40}?)\s*:\s*Information not available in the documentation\s*$",
    re.M)

_FIELD_STOPWORDS = {"the", "a", "an", "of", "for", "and", "or", "to", "in", "on",
                    "is", "are", "how", "do", "i", "what", "who", "which", "with",
                    "information", "details", "detail", "data", "name", "names"}


def _stem(word: str) -> str:
    """Crude suffix trim, enough to make a field LABEL and a QUESTION match.

    Exact-token matching missed the very case this check exists for: the field is
    "Process owner" while the question asks who "owns" it, so nothing matched, and
    the model went on to name the sub-department the process happens to sit in as
    its owner -- while the source says the owner is not documented.
    """
    w = word
    # len > 3, not > 4: "owns" is four letters, and it is the exact word this
    # check was written for.
    if not w.endswith("ss") and w.endswith("s") and len(w) > 3:
        w = w[:-1]
    for suf in ("ership", "ship", "ing", "er", "ed"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            return w[: -len(suf)]
    return w


# A field with a real value on it. Used to tell "the documentation says it does not
# know" apart from "some rows of this field were left blank while others were not".
_FILLED_FIELD = re.compile(
    r"^\s*([A-Z][A-Za-z /&-]{2,40}?)\s*:\s*(?!Information not available)(\S.+)$",
    re.M)


def unavailable_fields(hits: list[Hit], query: str) -> list[str]:
    """Field labels the sources record as undocumented EVERYWHERE, and that this
    question is asking about.

    "Everywhere" is the important part. TAG carries "Owner: Information not
    available" on 27 unfilled KPI rows and "Owner: TAG Head" on six others; keying
    off the blanks alone made "who owns TAG?" answer that ownership is not
    recorded, immediately followed by the TAG Head -- contradicting itself and
    denying a fact the source states. If any passage fills the label, the blanks
    are unfilled rows, not a documented absence.
    """
    q_words = {_stem(w) for w in re.findall(r"[a-z]+", (query or "").lower())
               if w not in _FIELD_STOPWORDS and len(w) > 3}
    filled: set[str] = set()
    blank: list[str] = []
    for h in hits:
        content = h.content or ""
        for label, _value in _FILLED_FIELD.findall(content):
            filled.add(label.strip().lower())
        for label in _UNAVAILABLE_FIELD.findall(content):
            if label.strip() not in blank:
                blank.append(label.strip())

    found: list[str] = []
    for label in blank:
        if label.lower() in filled:
            continue                      # recorded elsewhere: not a gap
        words = {_stem(w) for w in re.findall(r"[a-z]+", label.lower())
                 if w not in _FIELD_STOPWORDS and len(w) > 3}
        if words & q_words:
            found.append(label)
    return found


def _section_of(hit: Hit) -> str | None:
    """Section name of a passage, e.g. "Escalation matrix"."""
    for line in hit.content.splitlines():
        if line.startswith("Section:"):
            return line.split(":", 1)[1].strip()
    return None


_SECTION_STOPWORDS = {"department", "matrix", "directory", "structure", "knowledge",
                      "specific", "channels", "profile", "offered", "team", "teams"}


def section_matches_query(hit: Hit, query: str) -> bool:
    """True when the passage's section name is lexically present in the question.

    The reranker's covers_topic flag alone is not enough to claim "this section
    exists but is blank": asked about the capital of France it happily marked CMO's
    empty Communication channels chunks as on-topic, which would have the assistant
    assert the knowledge base covers French geography. Requiring the user to have
    actually named the section keeps that answer honest, at the cost of falling back
    to plain "not found" when they phrase it very differently.
    """
    section = next((l.split(":", 1)[1].strip().lower()
                    for l in hit.content.split("\n") if l.startswith("Section:")), "")
    if not section:
        return False
    q = query.lower()
    for word in section.split():
        w = word.strip("&()-,")
        if len(w) < 5 or w in _SECTION_STOPWORDS:
            continue
        if w[:6] in q:            # crude stem match: "escalation" ~ "escalate"
            return True
    return False


def pre_gate(hits: list[Hit]) -> tuple[bool, float | None]:
    """True when at least one hit clears the relevance threshold."""
    scored = [h.relevance for h in hits if h.relevance is not None]
    if not scored:
        # Reranker never ran. Fail closed rather than let the generator improvise.
        return (False, None)
    top = max(scored)
    return (top >= GROUNDEDNESS_MIN_RELEVANCE, top)


@contextmanager
def _timed(sw, name: str):
    if sw is None:
        yield
    else:
        with sw.stage(name):
            yield


def coverage_gap_note(unavailable: list[str]) -> str:
    """Disclose departments whose data could not be retrieved (section 4.6).

    Appended deterministically rather than left to the generator: a summary that
    quietly omits departments misrepresents its own completeness, and that is an
    accuracy failure even when every fact it does contain is correctly grounded.
    Composed, not templated, like every other user-facing message.
    """
    from ingestion.hd_map import display_name
    return responder.compose("coverage_gap", {
        "unavailable_departments": [display_name(h) for h in unavailable],
        "why": "their data could not be retrieved, even after a retry",
        "instruction": "state plainly that these departments are NOT covered by the "
                       "summary above, naming each one",
    })


def generate(query: str, hits: list[Hit], head_depts: list[str],
             scope_label: str, multi_department: bool = False, sw=None,
             convo_ctx: str = "", memory_ctx: str = "",
             broad_coverage: bool = False,
             unavailable: list[str] | None = None,
             prior_answer: str = "", focus: str = "") -> Answer:
    """convo_ctx / memory_ctx (sections 4.11, 4.12) help interpret the question and
    pitch the reply. They are NOT sources: the gate below still runs on retrieved
    passages alone, and a claim supported only by conversation history is unsupported."""
    # Broad all-department summaries skip the RELEVANCE pre-gate, not the grounding.
    # Those chunks are each department's own profile, selected structurally rather
    # than by similarity to the request, so they carry no relevance score -- the
    # pre-gate would reject every one of them. Everything downstream is unchanged:
    # the answer is still built only from these passages, still cited, and still
    # claim-verified.
    if broad_coverage and hits:
        passed, top = True, None
    else:
        passed, top = pre_gate(hits)
    if not passed:
        # Right section, no values recorded -- say that, rather than implying the
        # knowledge base holds nothing on the subject.
        # Both tests are deterministic, so this behaves identically whichever
        # reranker backend is active. The old version also required the LLM
        # reranker's covers_topic flag, which a cross-encoder cannot produce --
        # and which added nothing these two checks don't already establish.
        blank = [h for h in hits
                 if is_blank_section(h) and section_matches_query(h, query)]
        if blank:
            srcs, seen = [], set()
            for h in blank:
                if h.source_file not in seen:
                    seen.add(h.source_file)
                    srcs.append({"head_dept": h.head_dept, "source_file": h.source_file})
            return Answer(
                text=blank_section_message(
                    scope_label, sorted({h.source_name for h in blank}),
                    _section_of(blank[0])),
                sources=srcs, grounded=True, top_relevance=top,
                blank_section=True)
        return Answer(text=not_found_message(scope_label), sources=[],
                      grounded=False, top_relevance=top)

    # A drill-down keeps a wider set. The passages that answered the first question
    # score near the ceiling and are exactly the ones already summarised on screen;
    # the additional detail the user is now asking for sits in the ADJACENT passages
    # -- the function that uses the metric, the sibling records -- which score lower
    # precisely because they are not the direct hit. Measured on "explain more about
    # Strategic Hires": two passages cleared 4.0 and both had already been used,
    # while the two carrying extra detail scored 3.46 and 3.01 and were discarded, so
    # the model correctly reported it had nothing to add.
    #
    # This relaxes how much context generation SEES, not what may be asserted. The
    # relevance pre-gate above is untouched (it still ran on the top score, so a
    # drill-down into nothing still refuses), and every claim produced from these
    # passages still goes through claim verification below.
    floor = (DRILLDOWN_MIN_RELEVANCE if prior_answer else GROUNDEDNESS_MIN_RELEVANCE)
    kept = (list(hits) if broad_coverage
            else [h for h in hits if (h.relevance or 0) >= floor]
                 or hits[:1])

    # The section exists but every field is unfilled. This has to be checked on the
    # KEPT set, not only on a gate failure: a cross-encoder scores a blank escalation
    # matrix ~9.98 for "what is the escalation matrix?" because it judges topical
    # match, not answerability, so the passage sails through the gate. Saying "the
    # documentation leaves it blank" is both truer and more useful than letting the
    # generator paraphrase four "Information not available" lines.
    #
    # SINGLE department only. This message asserts something about the whole scope,
    # and across a fan-out the kept set is ~5 chunks out of 120 -- if those happen to
    # be blank it would claim the section is unfilled company-wide while other
    # departments document it perfectly well. With several departments in scope, fall
    # through to normal generation, which reports only what its passages actually say.
    single_department = not multi_department and len(head_depts) <= 1
    if single_department and kept and all(is_blank_section(h) for h in kept) \
            and any(section_matches_query(h, query) for h in kept):
        srcs, seen = [], set()
        for h in kept:
            if h.source_file not in seen:
                seen.add(h.source_file)
                srcs.append({"head_dept": h.head_dept, "source_file": h.source_file})
        return Answer(
            text=blank_section_message(
                scope_label, sorted({h.source_name for h in kept}),
                _section_of(kept[0])),
            sources=srcs, grounded=True, top_relevance=top, blank_section=True)

    with _timed(sw, "groundedness.do_not_disclose"):
        rules = do_not_disclose_for(head_depts)
    system = _ANSWER_SYSTEM
    # Named, data-derived constraint for fields the sources mark as undocumented.
    # Naming the exact field is what makes this stick where a general instruction
    # did not: the model is told which specific thing it must not construct.
    blank_fields = unavailable_fields(kept, query)
    if blank_fields:
        system += ("\n\nEvery occurrence of these fields in the passages reads "
                   "\"Information not available in the documentation\": "
                   + ", ".join(blank_fields) +
                   ".\nThe question asks about them. Say plainly, in the FIRST "
                   "sentence, that the documentation does not record this. Do not "
                   "assemble an answer for it out of nearby material, and do not "
                   "offer a related artifact as if it were the answer -- a tracker "
                   "that records requests is not how a request is made. You may "
                   "mention related facts afterwards, clearly separated.\n"
                   "This directive is safe to obey literally BECAUSE it only fires "
                   "when no passage fills the field. Softening it to a conditional "
                   "was measured at 0/4 -- the model decided an adjacent artifact "
                   "counted as the answer and fabricated a procedure.")
    if rules:
        system += ("\n\nConfidentiality constraints for this department. Do not reveal "
                   "these even if a passage contains them; say the detail is restricted:\n"
                   + "\n".join(f"- {r}" for r in rules))
    # --- drill-down: the user has already read an answer and wants to go further ---
    # Without this the model receives a question it has effectively already answered,
    # retrieves much the same passages, and returns the same text again. Measured
    # before this existed: three of eight follow-ups came back BYTE-IDENTICAL to the
    # answer above them. Showing it what was already said is what converts "answer
    # this question" into "add to this answer".
    #
    # The honesty clause matters as much as the depth one. Told only to go deeper,
    # the model pads -- restating the same fact at greater length reads like detail
    # and contains none. Depth has to come from the passages or be declined.
    if prior_answer:
        subject = f'"{focus}"' if focus else "the item the user asked about"
        system += (
            "\n\nThis is a FOLLOW-UP. The user has already been given the answer "
            f"below and is asking for more about {subject}.\n\n"
            "--- already told to the user ---\n" + prior_answer +
            "\n--- end ---\n\n"
            "Write what that answer did NOT already say. One line of orientation is "
            "fine if it helps the new material make sense; restating the earlier "
            "answer is not.\n"
            f"Go through the passages field by field for {subject} before deciding "
            "there is nothing more. Look for attributes the earlier answer omitted "
            "-- definition, formula, target, frequency, cadence, owner, dashboard, "
            "trigger, inputs, outputs, systems, escalation, related items, and where "
            "it sits among its siblings. A detail is new if the earlier answer did "
            "not state it, even when it is small: a measurement frequency or a "
            "monthly breakdown of an annual target is exactly the kind of thing "
            "being asked for here.\n"
            "Do not pad. Saying the same fact again at greater length is not detail, "
            "and neither is anything the passages do not state.\n"
            "LEAD WITH THE NEW MATERIAL. Do not open with what is missing. An answer "
            "that begins \"the documentation does not provide additional details\" "
            "and then supplies several paragraphs of them contradicts itself in its "
            "own first sentence, and buries the part the user asked for.\n"
            f"So: if the passages hold anything further about {subject} -- including "
            "closely connected material such as what a term stands for, the process "
            "or function that uses it, or the records alongside it -- give that "
            "FIRST, marking genuinely adjacent facts as related rather than "
            "presenting them as the answer. Note any specific unrecorded fields "
            "afterwards, in a closing line.\n"
            f"Only when the passages hold nothing further about {subject} at all, "
            "and nothing adjacent either, say that in a single sentence and stop.")

    if broad_coverage:
        system += ("\n\nThis is a broad summary request covering every department in "
                   "scope. Give each department its own short paragraph or bullet, "
                   "named explicitly, in the order the passages appear. Do not merge "
                   "departments together and do not silently omit one -- if a "
                   "department's passages say little, say that briefly rather than "
                   "dropping it.")
    if multi_department:
        system += ("\n\nPassages come from more than one head department. Name the "
                   "department in your PROSE, then cite the file: "
                   "'Office of CEO handles X [source: bpe-profile.json]'. The bracket "
                   "contains the file name and nothing else -- never "
                   "'[source: bpe-profile.json, department: office_of_ceo]'.")
    if convo_ctx or memory_ctx:
        system += ("\n\nThe context below is conversation history and remembered user "
                   "preferences. Use it ONLY to understand what the question refers to. "
                   "It is NOT a source: never state a fact that appears only there, and "
                   "never cite it. Every fact you assert must come from a numbered "
                   "passage.")
        if convo_ctx:
            system += f"\n\nEarlier turns:\n{convo_ctx}"
        if memory_ctx:
            system += f"\n\nRemembered about this user:\n{memory_ctx}"

    with _timed(sw, "generation"):
        resp = openai_client().chat.completions.create(
            model=OPENAI_CHAT_MODEL, temperature=0,
            messages=[{"role": "system", "content": system},
                      {"role": "user",
                       "content": f"Question: {query}\n\nContext passages:\n{_context(kept)}"}],
        )
        draft = (resp.choices[0].message.content or "").strip()

    with _timed(sw, "verification"):
        verified, dropped = verify(draft, kept, blank_fields)
        # A TOTAL strip is far more likely a verifier misfire than a wholly
        # unsupported answer -- the generator only ever saw these passages. Measured
        # at roughly 1 run in 5 on an otherwise-correct answer, which surfaced to the
        # user as an intermittent "not found". Re-verify once before concluding the
        # answer was ungrounded; a second independent strip is treated as real.
        if _stripped_completely(verified, dropped):
            verified, dropped = verify(draft, kept, blank_fields)

    # Verification stripped everything. That is the verifier disagreeing with the
    # generator, not an answer -- and it used to surface as a canned "the knowledge
    # base does not cover the question" baked into the rewrite prompt. Report it
    # honestly as not-found, composed like every other message.
    if _stripped_completely(verified, dropped):
        return Answer(text=not_found_message(scope_label), sources=[], grounded=False,
                      dropped_claims=dropped, top_relevance=top)
    sources, seen = [], set()
    for h in kept:
        key = (h.head_dept, h.source_file)
        if key not in seen:
            seen.add(key)
            sources.append({"head_dept": h.head_dept, "source_file": h.source_file})

    verified = snap_citations(strip_preamble(strip_sign_off(verified)), kept)

    # Section 4.6: name any department the summary could not cover. Appended after
    # claim verification so the verifier cannot strip it as "unsupported" -- it is a
    # statement about retrieval, not a claim drawn from the passages.
    if unavailable:
        verified = verified.rstrip() + "\n\n" + coverage_gap_note(unavailable)

    return Answer(text=verified, sources=sources, grounded=True,
                  dropped_claims=dropped, top_relevance=top,
                  unavailable_departments=list(unavailable or []))


_CITE_BRACKET = re.compile(r"\[source:\s*([^\]]*?)\s*\]", re.I)


def snap_citations(text: str, kept: list[Hit]) -> str:
    """Correct each citation to the exact filename of a passage actually retrieved.

    Filenames containing a bracketed suffix -- "dem-profile (1).json",
    "partnerships-profile (1).json" -- come back with the parentheses mis-balanced:
    "[source: dem-profile (1).json)]", with a stray ")" before the closing bracket.
    That is not a paraphrase to be tolerated; it breaks citation parsing, which
    section 4.7 makes a hard format rule.

    Deterministic and conservative. The real filenames are known here, so a citation
    is only rewritten when it matches exactly one of them once surrounding
    punctuation is discarded. Anything that matches nothing, or matches more than
    one, is left exactly as the model wrote it -- this repairs formatting and never
    invents or reassigns attribution.
    """
    names = {h.source_file.split("/")[-1] for h in kept if h.source_file}
    if not names:
        return text

    def norm(s: str) -> str:
        return re.sub(r"[^a-z0-9.]+", "", (s or "").lower())

    by_norm: dict[str, set[str]] = {}
    for n in names:
        by_norm.setdefault(norm(n), set()).add(n)

    def fix(m: re.Match) -> str:
        raw = m.group(1)
        if raw in names:
            return m.group(0)
        candidates = by_norm.get(norm(raw))
        if candidates and len(candidates) == 1:
            return f"[source: {next(iter(candidates))}]"
        return m.group(0)

    return _CITE_BRACKET.sub(fix, text)


# A trailing "Let me know if you have any questions!" carries no information and
# is the one piece of assistant furniture the prompt does not reliably suppress --
# it reappears mainly on long answers, where the model seems to reach for a
# closing. Removing it is safe by construction: a sign-off states no fact, so
# nothing grounded can be lost. This REMOVES canned text rather than adding any,
# which is the opposite of the pattern CLAUDE.md prohibits.
# Matched with SEARCH, not match: the offer routinely arrives mid-sentence --
# "If you need more specific details about the roles, feel free to ask." -- and an
# anchored pattern missed every one of those. Safe because the candidate is only
# ever the FINAL sentence or paragraph and is required to carry no citation, so a
# grounded statement can never be what gets removed.
_SIGN_OFF = re.compile(
    r"(?:please\s+)?(?:do\s+)?let\s+me\s+know\b"
    r"|feel\s+free\s+to\s+(?:ask|reach|let)"
    r"|(?:i\s+)?hope\s+(?:this|that)\s+(?:helps|answers|is\s+helpful)"
    r"|(?:is\s+there\s+)?anything\s+else\s+(?:you|i)\b"
    r"|happy\s+to\s+(?:help|dig|elaborate|clarify|provide)"
    r"|(?:reach\s+out|get\s+in\s+touch)\s+if\s+you"
    r"|if\s+you\s+(?:have|need|want|would\s+like)\b[^.]*"
    r"\b(?:ask|questions?|clarification|assist|help|further\s+details?)\b",
    re.I)


_PREAMBLE = re.compile(
    r"^\s*(?:here(?:'|\u2019)?s|here\s+is|below\s+is|the\s+following\s+is|"
    r"this\s+is)\b[^.:\n]{0,120}?"
    r"(?:based\s+on\s+the\s+(?:provided|given|above)\s+"
    r"(?:context|passages|documents|information)|summary|overview|breakdown|"
    r"rundown|details?)\b[^.:\n]{0,60}[:.]\s*",
    re.I)


def strip_preamble(text: str) -> str:
    """Drop a leading "Here's a summary of X based on the provided context:" style
    framing sentence. Never removes anything carrying a citation or a number, and
    never leaves the answer empty."""
    t = (text or "").lstrip()
    m = _PREAMBLE.match(t)
    if not m:
        return text
    head = t[:m.end()]
    if "[source:" in head or re.search(r"\d", head):
        return text
    rest = t[m.end():].lstrip()
    # Only strip when real content follows; a bare "Here is a summary." with
    # nothing after it is the whole answer, not a preamble to one.
    return rest if len(rest) > 25 else text


def strip_sign_off(text: str) -> str:
    """Drop a trailing sign-off paragraph or sentence. Never touches a line that
    carries a citation, so no grounded content can be removed by accident."""
    out = (text or "").rstrip()
    for _ in range(2):                       # at most a sentence and a paragraph
        blocks = out.rsplit("\n\n", 1)
        if len(blocks) == 2 and "[source:" not in blocks[1] and _SIGN_OFF.search(blocks[1]):
            out = blocks[0].rstrip()
            continue
        # Same test on a trailing sentence of the final line. The citation guard
        # applies to the SENTENCE being removed, not the whole line: a sign-off
        # routinely follows a cited sentence on the same line ("TAG tracks three
        # KPIs [source: t.json]. Feel free to ask..."), and guarding the line kept
        # every one of those.
        head, sep, tail = out.rpartition("\n")
        line = tail if sep else out
        parts = re.split(r"(?<=[.!?])\s+", line.strip())
        if len(parts) > 1 and "[source:" not in parts[-1] and _SIGN_OFF.search(parts[-1]):
            rebuilt = " ".join(parts[:-1]).rstrip()
            out = (head + sep + rebuilt) if sep else rebuilt
            continue
        break
    return out.rstrip()


def verify(draft: str, hits: list[Hit],
           blank_fields: list[str] | None = None) -> tuple[str, list[str]]:
    """Post-hoc claim check. Returns (answer, unsupported claims).

    blank_fields names fields every passage records as "Information not available".
    Four attempts at instructing the GENERATOR not to answer them failed the same
    way each time -- asked how to request SME support, it kept offering the SME
    Request Tracker, which merely records requests. Routing the constraint through
    the verifier works because stripping an unsupported claim is a mechanism that
    already exists and already runs on every answer: the generator has to be talked
    out of writing it, whereas the verifier just removes it.
    """
    if not draft.strip():
        return draft, []
    system = _VERIFY_SYSTEM
    try:
        resp = openai_client().chat.completions.create(
            model=OPENAI_CHAT_MODEL, temperature=0,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": system},
                      {"role": "user",
                       "content": f"Draft answer:\n{draft}\n\nContext passages:\n{_context(hits)}"}],
        )
        claims = json.loads(resp.choices[0].message.content or "{}").get("claims", [])
    except Exception:
        return draft, []

    unsupported = [c.get("claim", "").strip() for c in claims if c.get("supported") is False]
    unsupported = [c for c in unsupported if c]
    if not unsupported:
        return draft, []

    # Drop them rather than appending a note -- stating a fact and then declaring it
    # withheld in the same answer is worse than not stating it.
    try:
        resp = openai_client().chat.completions.create(
            model=OPENAI_CHAT_MODEL, temperature=0,
            messages=[{"role": "system", "content": _REWRITE_SYSTEM},
                      {"role": "user",
                       "content": "Answer:\n" + draft + "\n\nRemove these unsupported "
                                  "statements:\n" + "\n".join(f"- {u}" for u in unsupported)}],
        )
        cleaned = (resp.choices[0].message.content or "").strip()
        return (cleaned or draft), unsupported
    except Exception:
        return draft, unsupported
