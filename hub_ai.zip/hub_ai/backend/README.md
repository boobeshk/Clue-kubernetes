# HUB AI — backend

## Environment setup

Update `backend/.env` with your API values:

```env
OPENAI_API_KEY = #your openAi api key
OPENAI_CHAT_MODEL = #your openAi chat model
OPENAI_EMBEDDING_MODEL=text-embedding-3-small
SUPABASE_URL = #your supabase url
SUPABASE_KEY = #your supabase key
SUPABASE_KB_BUCKET = #your supabase knowledge base bucket
SUPABASE_KB_ROOT_PREFIX = #your supabase knowledge base root prefix
SUPABASE_ACCESS_TOKEN = #your supabase access token
KB_ADMIN_USERNAME=admin
KB_ADMIN_PASSWORD=admin@2026
HF_TOKEN = #your Hugging Face token 
```

`backend/.env` is gitignored — never commit real keys.

## Setup

```bash
cd backend
python -m venv .venv
.venv/Scripts/python -m pip install -r requirements.txt   # Windows
```

`backend/.env` holds the section 5 variables. It is gitignored.

## Run

```bash
cd backend
.venv/Scripts/python -m uvicorn main:app --reload
```

## Ingestion CLI

```bash
python -m ingestion.run --dry-run --head-dept cmo   # chunk only, no embed/insert
python -m ingestion.run --head-dept cmo --mode full # rebuild one department
python -m ingestion.run --mode incremental          # everyday path, all departments
```

## Layout

| Path | Role |
|---|---|
| `config.py` | env loading; all tunables |
| `clients.py` | Supabase + OpenAI singletons |
| `ingestion/hd_map.py` | folder display name → department slug (normalised match) |
| `ingestion/storage.py` | bucket listing + download |
| `ingestion/chunker.py` | JSON → chunks, one logical unit each |
| `ingestion/embedder.py` | batched embeddings |
| `ingestion/summarizer.py` | `hd_index.summary_md` from `ai_specific_knowledge` |
| `ingestion/pipeline.py` | incremental/full modes, orphan check, job state |
| `retriever/retriever.py` | `hybrid_search` fan-out + LLM rerank |
| `groundedness/gate.py` | pre-gate, generation, claim verification |
| `planner/planner.py` | HD scope resolution, lane classification, `routing_log` |
| `docgen/generator.py` | docx / pdf / xlsx / png |
| `skills/registry.py` | skill CRUD + execution |
| `db/` | SQL migrations (applied) |

## Chunking

31 uniform top-level keys across all 29 profiles. One chunk per list item for the 15
list fields; one per section for the 7 nested dicts; `profile_text` its own chunk.
Metadata-only (carried in `documents.metadata`, never embedded): `department_id`,
`department_name`, `content_owner`, `data_classification`, `last_updated`,
`last_reviewed_date`, `source_documents`, `needs_review`.

`ai_specific_knowledge.do_not_disclose` is stripped from chunk text and stored in
`metadata.file_meta`. It names the figures it protects, so embedding it would make
them retrievable. `groundedness/gate.do_not_disclose_for()` loads it per department
and injects it into the generation prompt as a constraint.

## Design decisions

**The groundedness threshold is on rerank relevance, not retrieval score.** §4.7 says
"if the top retrieval score is below a configured threshold". Since §4.4 became RRF,
`hybrid_search`'s score is a pure function of rank position — a rank-1 chunk scores
~0.0164–0.0328 whether or not it is relevant — so thresholding on it gates on nothing.
The gate uses the reranker's 0–10 relevance instead (`GROUNDEDNESS_MIN_RELEVANCE`).

**Docgen retrieves on the subject, not the instruction.** "Export the TAG KPIs as an
excel spreadsheet" scored every passage near zero, because the reranker judges how
well a passage answers a *question*. `docgen.generator.content_query()` strips the
wrapper before retrieval.

**Skill scripts are stored but not executed.** Running uploaded code from an HTTP
endpoint needs a sandbox that is out of scope; `skills/registry.execute()` applies
`instructions_md` against grounded context and says so if a script is attached.

## Cross-department retrieval (step 8)

`retrieve()` splits on scope size. One department: single rerank. Several:
`rerank_fanout()` runs a **two-stage** rerank — each department's passages are ranked
on their own, the top `FANOUT_PER_DEPT_KEEP` survive, then the survivors are ranked
against each other.

The reason is that RRF scores are not comparable across departments. They are a pure
function of rank position, so every department's rank-1 passage scores an identical
~0.01734 — measured on the real corpus, 120 pooled passages carried only 10 distinct
scores, 17 of them tied at that one value. Sorting the pooled set therefore ranks by
nothing, and any truncation of it silently favours whichever departments iterate
first. Stage 1 also keeps the single-shot rerank small: pooling all 18 departments
was ~17k tokens, a length at which LLM ranking degrades badly.

`search_by_dept()` returns results grouped for this reason; `search()` only sorts
when a single department is in scope.

## Adversarial results (step 8)

Passing as of the last run: fan-out triggers only on genuine cross-department
phrasing; every citation names a real, retrieved file; no department is attributed a
file it does not own; departments with different escalation contacts are listed
separately rather than merged; and all 5 `do_not_disclose` rules load and hold under
the 18-department scope, including a direct probe for the FDX figure.

Two bugs this pass found and fixed:
- `_ALL_PATTERNS` matched a bare "across all", so *"What does the CMO do across all
  its teams?"* fanned out to all 15 departments instead of staying on CMO.
- The answer prompt allowed `[source: a.json, b.json]`, which breaks citation
  parsing. One file per bracket is now required.

## Testing

```bash
python -m tests.run_eval            # section 8.3 quality eval (31 cases)
python -m tests.e2e.test_ui         # section 8.1 browser regression (9 tests)
python -m tests.e2e.test_ui --headed --filter mention
```

`tests/e2e/` needs `playwright` plus `python -m playwright install chromium`. This is
test tooling, not frontend build tooling — the frontend is still one static HTML file
with no build step. Failures write a screenshot and the browser console log to
`tests/e2e/artifacts/`.

The e2e suite selects on `data-testid` attributes in `frontend/index.html`
(`bot-answer`, `sources`, `badge-inferred`, `badge-lane`, `doc-download`). They are
inert at runtime; don't strip them.

Both suites are **regression** suites: re-run after any change to the planner,
retriever, reranker, groundedness logic, or the API contract.

## Reranking backend

`RERANK_BACKEND=cross_encoder` (default) uses a local
`cross-encoder/ms-marco-MiniLM-L-6-v2` — no API round-trip. `RERANK_BACKEND=llm`
restores the gpt-4o-mini pass; the code falls back to it automatically if the model
can't load.

Cross-encoder logits are mapped through a sigmoid onto the same 0–10 scale the LLM
reranker used, so `GROUNDEDNESS_MIN_RELEVANCE` keeps its meaning across backends.

Two consequences worth knowing:
- The cross-encoder judges *topical* match, not answerability, so a blank section
  scores ~9.9 for a question about that section. The blank-section check therefore
  runs on the kept set regardless of score, not only on a gate failure.
- Its scores are comparable across departments (RRF's are not), so the
  cross-department path scores the whole pool in one batched pass instead of the
  two-stage per-department rerank the LLM backend needs.

## Thresholds needing calibration

Both are guesses that should be tuned against `routing_log`, not treated as tuned:

| Setting | Default | Effect |
|---|---|---|
| `HD_ROUTING_MIN_CONFIDENCE` | 0.55 | below this the planner asks instead of guessing |
| `HD_ROUTING_DUAL_MARGIN` | 0.15 | how close 2nd place must be to also be searched |
| `GROUNDEDNESS_MIN_RELEVANCE` | 4.0 | below this, "not found in the knowledge base" |
| `RERANK_KEEP` | 5 | passages passed to generation |
