# HUB AI — Frontend (Track A)

Scope: this file loads only when working with files under `frontend/`.
Moved out of the root CLAUDE.md so it stops costing context in backend-only
sessions. The cross-cutting rule that the frontend must never gain Node, React,
or a JS build step lives in section 9 of the root CLAUDE.md, which is always
loaded — it is deliberately not duplicated here.

## 3. TRACK A — Frontend (minimal, surgical changes only)

The uploaded file is a single-page HTML/CSS/vanilla-JS chat UI (ChatGPT-style: sidebar with a "New chat", "Search chats", "Library", "Apps" nav, an `APPS` array driving both the sidebar app list and the per-app chat views, `@mention` autocomplete, and a Prompt Library overlay).

### 3.1 First step — analyze, don't assume
Open the uploaded HTML file and map out exactly how `APPS`, `GENERAL_KB`, `LIBRARY_CARDS`, `findKBAnswer()`, `sendMessage()`, `sendHomeMessage()`, and the mention-parsing functions (`parseMention`, `handleMentionInput`, `selectMention`) connect to each other before changing anything.

### 3.2 What TO change
- **Replace the `APPS` array's 5 mock entries** (People Hub, Marketing Hub, RMG Pulse Hub, TLF Hub, Talent Transformation Hub) **with the 18 head departments** from the table in section 2. For each HD, keep the existing object shape (`id`, `name`, `alias`, `color`, `icon`, `tagline`, `source`, `prompts`, `recents`) — populate `id` with the slug, `name` with the display name, `alias` with a short lowercase token suitable for `@mention` matching (e.g. `cmo`, `finance`, `ocpe`), and choose a reasonable icon/color/tagline per department. Leave `prompts` as a small set of generic, plausible starter questions per HD (e.g. "What's the latest update from Finance?") — not invented factual answers.
- **Remove the `kb` array from every APPS entry and remove `GENERAL_KB` entirely.** These contained fabricated mock answers for the old demo hubs. Do not replace them with new fabricated answers for the real departments — that data doesn't exist yet and must come from the real backend later.
- **Update `LIBRARY_CARDS`** so its `appId` values match the new 18 HD slugs, with the `title`/`desc`/`prompt` fields replaced by generic, department-appropriate placeholders (not invented facts).
- Leave `findKBAnswer()`'s *fallback* behavior (the "I don't have a matching answer yet... once the live connector is wired..." message) in place structurally — this is the correct placeholder behavior until backend wiring happens in a later session. Do not delete this fallback path.
- **The sidebar lists EVERY department, in `APPS` order, in a scrollable pane.**
  This reverses an earlier instruction here, which capped the sidebar at 5 entries
  (most-recently-used, padded from the top of `APPS`) and left the rest to the Apps
  overlay grid. In use that was worse, not tidier: twelve of the seventeen were
  reachable only through a second surface, and the five on show reordered themselves
  as you worked, so an entry was rarely where you last saw it. The cap and the
  "Apps" nav button that opened the grid were both removed on the user's explicit
  instruction. Sidebar order is now: New chat → Search chats → Library → Knowledge
  Base → Departments (all, scrollable) → Recents. Do not reintroduce a featured
  subset. `renderAppsGrid()`/`appsOverlay` remain in the file but are no longer
  reachable from the sidebar.

### 3.3 What NOT to change
- Do not touch the CSS, layout, sidebar structure, overlay markup, typing-indicator animation, or any function signatures — except where a later instruction in this file supersedes it (the sidebar department list and the branding/dictation work below both changed markup and CSS deliberately).

### 3.6 Branding, dictation and the composer (added later, all still current)
- **The Agilisium mark is `frontend/src/agilisium.png`**, served at `src/agilisium.png`. It appears in the sidebar header, as the favicon, on the home hero, and as the general assistant's reply avatar (department replies keep their own department icon). Note the file is named `.png` but its bytes are **WebP** — browsers sniff and render it fine, so do not add `type="image/png"` to the `<link rel="icon">`, and do not "fix" it by renaming without re-encoding.
- **The mic button is real dictation** (`toggleDictation`), built on the browser's own `SpeechRecognition`. It **must never auto-send**: it writes into the composer and stops there, because recognition mishears names and figures constantly and an auto-sent mishearing cannot be caught. Click starts, a second click stops, six seconds of silence stops it too. Unsupported browsers get the button disabled rather than a control that fails on use.
- **Composers must never be autofilled.** Every `input.center-input` carries `autocomplete="off"`, a non-credential `name`, and the password-manager opt-outs; the KB login fields carry explicit `autocomplete="username"` / `"current-password"` so the manager binds there instead of guessing. Without that binding Chrome put the saved `admin` username into the chat box. `clearComposers()` on load and on `pageshow` covers browser-restored values, which no attribute suppresses.
- Do not add fetch calls, async/await, or any backend wiring yet, **except** the two Embed buttons from section 3.4 — those must call the real `/api/documents/ingest` endpoint and poll its job-status endpoint, since they're non-functional otherwise. Everything else (chat, `@mention` answers) stays on the placeholder fallback until the deferred wiring session.
- Do not introduce React, Node, or a build step. Keep it a single static HTML file.
- Do not change `@mention` parsing logic — it already works generically off the `APPS` array (via `parseMention`, `escapeRegex`), so once `APPS` is updated to the 18 HDs, `@Finance`, `@CMO`, `@TAG`, etc. should already resolve correctly. Just verify it against names containing special characters, e.g. `Organizational Culture & People Experience (OCPE)` and `Holding Co & Family Office Management` — confirm the regex escaping handles `&` and parentheses correctly (it should, via `escapeRegex`), and test the alias fallback path too.

### 3.4 New addition — Embed controls (admin action, not a data-only change)
Unlike the rest of Track A, this is a genuine new UI addition, not a data edit — add it deliberately, in one clearly separated admin area (e.g. a small "Admin" or "Knowledge Base" panel/modal, not cluttering the main chat view). It needs **two distinct, clearly labeled buttons**, calling the two modes defined in section 4.5/4.10:
- **"Update Knowledge Base"** (incremental) — the default, everyday action. Processes only new/changed files since the last run.
- **"Full Re-embed"** — the rare, deliberate action for when the embedding model or chunking logic changes, or the data is suspected stale/corrupted. Should require a confirmation step (e.g. a confirm dialog) since it reprocesses everything and costs more.

Both buttons call `POST /api/documents/ingest` (section 4.10) with the appropriate `mode`, then poll the returned job for status and show progress (processed/total file count) rather than blocking silently — this can take a while across 90+ files, especially in full mode.

### 3.5 Deliverable for Track A
One updated HTML file: the data changes from 3.2 plus the new Embed controls from 3.4, functionally identical to the original everywhere else. Produce a short diff summary of exactly what changed.

---

