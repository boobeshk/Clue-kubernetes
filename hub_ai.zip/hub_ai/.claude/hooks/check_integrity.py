"""PostToolUse check: catch a corrupted source file the moment it is written.

The guard hook prevents the known cause; this catches any other route to the same
damage. Two checks, both cheap:

  1. every .py file parses;
  2. no source file contains a raw control byte.

Check 2 is the one that matters most. A 0x08 that was meant to be `\\b` leaves the
file perfectly parseable and quietly disables whatever regex it landed in -- the
failure is invisible to the interpreter, to the test suite, and to a reading of the
diff. It went unnoticed twice here.

Scoped to the project's own sources; .venv and caches are skipped so this stays
fast enough to run after every edit.
"""
import ast
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
SKIP = {".venv", "__pycache__", ".git", "node_modules", "artifacts"}
SOURCE_SUFFIXES = {".py", ".html", ".js", ".css", ".sql"}

# Tab, LF, CR are legitimate. Everything below 0x20 otherwise is not.
def _control_bytes(data: bytes) -> list[tuple[int, str]]:
    return [(i, hex(c)) for i, c in enumerate(data)
            if c < 9 or (13 < c < 32)]


def iter_sources():
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix not in SOURCE_SUFFIXES:
            continue
        if any(part in SKIP for part in path.parts):
            continue
        yield path


def main() -> int:
    try:
        json.load(sys.stdin)
    except Exception:
        pass                            # run regardless of payload shape

    problems: list[str] = []
    for path in iter_sources():
        rel = path.relative_to(ROOT)
        try:
            data = path.read_bytes()
        except OSError:
            continue
        ctrl = _control_bytes(data)
        if ctrl:
            offset = ctrl[0][0]
            line = data[:offset].count(b"\n") + 1
            problems.append(
                f"{rel}:{line} contains raw control byte {ctrl[0][1]} "
                f"({len(ctrl)} total). A 0x8 here is almost always a backslash-b "
                f"that got interpreted -- the file will still parse and the regex "
                f"it sits in will silently never match.")
        if path.suffix == ".py":
            try:
                ast.parse(data.decode("utf-8", errors="replace"))
            except SyntaxError as exc:
                problems.append(f"{rel}:{exc.lineno} SyntaxError: {exc.msg}")

    if problems:
        sys.stderr.write("SOURCE INTEGRITY CHECK FAILED\n")
        for p in problems:
            sys.stderr.write(f"  {p}\n")
        sys.stderr.write("\nFix before continuing -- do not run tests against this.\n")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
