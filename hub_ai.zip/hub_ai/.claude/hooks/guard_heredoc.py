"""PreToolUse guard: refuse to write source code containing backslash escapes
through a bash heredoc.

Why this exists. Writing a regex or an escaped string into a .py file through a
heredoc has silently corrupted this codebase three times:

  * `\\b` collapsed to a literal 0x08 backspace byte, disabling a regex while the
    file still parsed and the tests still ran -- the worst possible failure shape,
    because nothing announced it;
  * `\\n` inside a string literal became a real newline, producing an
    unterminated-string SyntaxError in groundedness/gate.py;
  * the same 0x08 collapse again, in tests/run_eval.py comments.

The third happened immediately after a written rule was added saying not to do it,
which is the evidence that a rule is not the right mechanism. The Write/Edit tools
pass content through verbatim and have never corrupted anything, so the fix is to
make the dangerous path unavailable rather than discouraged.

Deliberately narrow: it blocks only a heredoc that WRITES source. Heredocs that
read, grep, print or test are untouched, because those cannot corrupt a file.
"""
import json
import re
import sys

# A heredoc at all.
HEREDOC = re.compile(r"<<-?\s*'?\"?[A-Za-z_][A-Za-z0-9_]*'?\"?")

# Something inside it that WRITES a file. Reading and printing are harmless.
WRITES = re.compile(
    r"\.write_text\s*\(|\.write_bytes\s*\(|\.write\s*\(|"
    r"open\s*\([^)]*['\"][wa]b?['\"]|"
    r"\bshutil\.(copy|move)|"
    r">\s*\S+\.(py|html|js|css|json|sql|md)\b")

# Backslash escapes that get re-interpreted somewhere in the pipeline.
ESCAPES = re.compile(r"\\[bnrtfvsdwWSDA0-7xuU]|\\\\")

# Files worth protecting. A heredoc writing a scratch .txt is not the problem.
SOURCE = re.compile(r"\.(py|html|js|css|json|sql)\b")


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0                       # never break the session on a parse issue
    if payload.get("tool_name") != "Bash":
        return 0
    command = (payload.get("tool_input") or {}).get("command") or ""

    if not HEREDOC.search(command):
        return 0
    if not WRITES.search(command):
        return 0                       # read-only heredoc: fine
    if not ESCAPES.search(command):
        return 0                       # no escapes to mangle: fine
    if not SOURCE.search(command):
        return 0

    sys.stderr.write(
        "BLOCKED: this heredoc writes source code and contains backslash escapes "
        "(\\b, \\n, \\\\ ...).\n"
        "That exact combination has silently corrupted this repo three times -- "
        "once producing a literal 0x08 byte that disabled a regex while the file "
        "still parsed and every test still passed.\n\n"
        "Use the Write or Edit tool instead: they pass content through verbatim.\n"
        "If the heredoc only READS or PRINTS, it is not blocked -- move the write "
        "out of it.\n")
    return 2                           # 2 = block, and show stderr to the model


if __name__ == "__main__":
    sys.exit(main())
