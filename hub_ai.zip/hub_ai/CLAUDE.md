# HUB AI — Build Specification for Claude Code

Use this as your first message to Claude Code (or save as `CLAUDE.md` in the project root so it persists across the whole session). Run Claude Code with Opus:

```bash
claude update
claude --model opus
```

---

## 0. How to work on this project

- Read this entire spec before writing any code.
- Work in two clearly separated tracks: **(A) Frontend — minimal, surgical edits only** and **(B) Backend — build from scratch**. Do not blend them. Do not wire the frontend to the backend yet — that integration happens in a later session once both sides are reviewed.
- If anything here is ambiguous, stop and ask rather than guessing.
- Do not add Node.js, npm, React, Vite, webpack, or any JS build tooling anywhere in this project. The frontend is a single static HTML file (vanilla JS/CSS). The backend is Python only.
- Do not invent fake department content, mock Q&A pairs, or placeholder "answers" for real head departments. The old file had hardcoded mock knowledge (People Hub, Marketing Hub, etc. with fake canned answers) — that pattern must be removed, not relabeled.

**Repository layout:**
```
hub-ai/
  frontend/
    index.html      <- the uploaded chat UI, edited per Track A (section 3)
  backend/
    ...              <- per section 4.2
  CLAUDE.md
```
Save the uploaded frontend file as `frontend/index.html` before starting. All Track A edits happen in that file.

---

## 1. Project overview

**Project name:** HUB AI

HUB AI is an internal chatbot that answers questions strictly from a company knowledge base of 90+ JSON files. Each JSON file represents one sub-department's data. Sub-departments are grouped under **18 head departments (HDs)**. The system must never answer from outside the knowledge base and must never blend data across head departments unless explicitly asked to.

**Core capabilities:**
1. Retrieval Q&A grounded strictly in the knowledge base (no hallucination)
2. Document creation (pdf, docx, xlsx, image) built from retrieved, grounded data
3. User-uploaded skills (Claude-style: instructions + optional code), invoked when relevant

---

## 2. The 18 head departments (deduplicated, canonical list)

The user supplied a raw list with duplicates. These are the 18 distinct head departments — use exactly this list and these slugs everywhere (folder names, `head_dept` DB values, frontend `id` fields):

The canonical 18 display-name → slug rows are `HEAD_DEPARTMENTS` in `backend/ingestion/hd_map.py`; use those slugs everywhere (folder names, `head_dept` values, frontend `id` fields).

Each HD groups one or more sub-department JSON files (90+ total across all 18 HDs). The user uploads these raw JSON files themselves into a **Supabase Storage bucket**, organized as one top-level folder per HD using the exact slugs above (e.g. `finance/`, `cmo/`, `ocpe/`), with that HD's sub-department JSON files inside each folder. The backend never reads from local disk or an on-machine folder structure — see section 4.5 for how ingestion pulls from the bucket. Confirm the real JSON schema per department with the user before writing the ingestion parser — do not assume a schema.

---

## 3. TRACK A — Frontend

Frontend-specific guidance now lives in `frontend/CLAUDE.md`, which loads only
when working under `frontend/`. The cross-cutting prohibition (no Node/React/JS
build tooling) stays in section 9, where it is always loaded.

---

## 4. TRACK B — Backend (build from scratch, Python only)

### 4.1 Stack
- **Framework:** FastAPI (async)
- **Data layer:** Supabase — Postgres + `pgvector` (HNSW index) for vector search, native `tsvector` for full-text/keyword search. One database, no separate vector DB or search engine.
- **Embeddings + generation:** OpenAI API — use exactly `gpt-4o-mini` for all generation (planner, answer generation, groundedness checks, reranking) and exactly `text-embedding-3-small` for all embeddings. Do not substitute other models. Read both as env vars (section 5), never hardcode the model name in code.
- **Client libraries:** `supabase-py`, `openai` Python SDK

### 4.2 Repository layout
Run `ls backend/` for the current layout.

### 4.3 Supabase schema
DDL lives in `backend/db/001_schema.sql` and `backend/db/004_memory_and_latency.sql`.

### 4.4 Hybrid retrieval RPC
**Revised from the original draft** — the first version ranked vector scores (~0.3–0.8) and `ts_rank` scores (~0.01–0.1) head-to-head, which meant keyword matches almost never surfaced (effectively vector-only search). This version uses Reciprocal Rank Fusion (rank position, not raw score) and deduplicates chunks that match both arms:
The function body lives in `backend/db/002_hybrid_search.sql`.
`filter_head_dept` has no default and is compared with `=`, so a `NULL` argument returns zero rows rather than searching everything — this is fail-closed by design and matches the no-cross-department-leakage requirement in section 12. The "search all departments" path (build order step 8) calls this once per HD and merges client-side, never by passing a NULL filter.

Add a reranking step in Python after this call, before anything reaches the groundedness gate. **Default to a local cross-encoder, not an LLM-based rerank pass** — measured on this project's real workload, the cross-encoder cut single-department p50 latency ~20% and cross-department p50 ~34%, gave a cleaner 0.00 refusal signal for out-of-KB queries than the LLM reranker did, and — critically for cross-department queries — produces scores that are comparable across departments (RRF scores are not), which lets a pooled cross-department set be reranked in a single batched pass instead of the more complex two-stage per-department approach. Keep the LLM-based reranker available behind `RERANK_BACKEND=llm` as a fallback, and fall back to it automatically if the cross-encoder model fails to load.

**A reranker judges topical relevance, not answerability — this is not the same thing.** A blank or empty section (e.g. an unfilled escalation matrix) can score highly on topical match while containing no actual answer. After reranking keeps its top candidates, run a deterministic blank-content check on the kept set regardless of score, and exclude anything that's empty or near-empty before it reaches the groundedness gate — a high relevance score must never substitute for this check.

### 4.4.1 Schema hardening (apply alongside 4.3/4.4, not optional)
- **Enable Row Level Security on all four tables** (`documents`, `ingestion_log`, `hd_index`, `skills`). The backend authenticates with the service role key (section 5) and is unaffected by RLS; this closes the exposure path if an anon/public key is ever used against this project.
- **Add `.gitignore` for `backend/.env`** before the first commit — it holds live secrets.
- **Add a `routing_log` table now**, since section 4.6 (Planner) requires logging every routing decision but no table was defined for it in section 4.3:
DDL lives in `backend/db/003_optional_hardening.sql`.

### 4.5 Ingestion pipeline (`ingestion/`)

**Important — source of the raw JSON:** the user uploads the original JSON files themselves into a **Supabase Storage bucket**. The actual bucket layout is:
```
<bucket>/
  Organization Details/           <- fixed root prefix, see SUPABASE_KB_ROOT_PREFIX below
    Business Growth Management/   <- folder name is the HD DISPLAY NAME, not the slug
      *.json
    CMO/
      cmo-profile.json
      partnerships-profile (1).json
      prmg-profile.json
    Holding Co & family office management/
      *.json
    ... (18 HD folders total, 90+ files total)
```

Two important real-world details that differ from a naive "folder name = slug" assumption:
- **Root prefix:** all 18 HD folders live one level deep, inside a fixed wrapping folder (currently `Organization Details`). Read this as an env var (`SUPABASE_KB_ROOT_PREFIX`, default `Organization Details`) rather than hardcoding it, in case it changes.
- **Folder names are display names, not slugs:** the folders are named `CMO`, `Business Growth Management`, `Holding Co & family office management`, etc. — matching the "Head department (display name)" column in section 2, not the slug column. The ingestion pipeline must map each real folder name → its canonical slug using the table in section 2 (trim whitespace, match case-insensitively, since Storage folder names may not exactly match casing). Do not assume folder name and slug are the same string. Store the resolved **slug** as `head_dept` in the `documents` table (so retrieval filtering and the frontend's `head_dept` values stay consistent) — the raw folder name only matters for locating the file in Storage.

The ingestion pipeline's job is entirely on the *processing* side, reading from Storage rather than a database table or local disk:
1. **List** the folders under `SUPABASE_KB_ROOT_PREFIX` via `supabase.storage.from_(bucket).list(root_prefix)` — each folder name is an HD display name; resolve it to a slug via the section 2 mapping. Flag and skip (with a warning, not a silent drop) any folder name that doesn't match one of the 18 known display names — that likely means a typo or a new department that needs adding to section 2 first.
2. For each HD folder, list its files.
3. **Compare against `ingestion_log`** — for each file, check its Storage `updated_at` metadata against the logged `file_updated_at` for that `storage_path`. Skip files unchanged since the last run; process only new or updated files. If a filename collision like `partnerships-profile (1).json` shows up, log it explicitly as a possible duplicate upload rather than silently ingesting it as a distinct document — flag for the user to confirm.
4. **Download + parse** each new/updated file's bytes as JSON. Confirm the real JSON schema per department with the user before writing the parser — do not assume field names.
5. **Chunk** by logical unit (one record / one field-group / one entity), not fixed-length splitting. Attach `head_dept` (the resolved **slug**, not the raw folder name), `sub_dept` (derived from the filename), and `source_file` (the full storage path) metadata to every chunk.
6. **Embed** each chunk via the OpenAI embeddings API.
7. **Store** the chunk + embedding into the `documents` table, then upsert a row into `ingestion_log` recording that `storage_path` as processed with its current `file_updated_at`.
8. Regenerate that HD's `hd_index.summary_md` — **this must be a structured index, not free-text prose.** List every team, sub-department, function, and abbreviation the department actually *owns*, under clearly separated labels from anything about *related* departments — these must never blend together in the same text. A summary that mentions another department's name or abbreviation (e.g. "related departments: CMD, CSM") in the same unstructured block as its own owned terms will cause a text/semantic matcher to mis-route questions to the wrong department. Do not copy `common_user_questions` or similar example-question text verbatim into the summary — an example question about one department's terms can accidentally pattern-match a genuinely different department's real question about similar-sounding terms. **The structured index must cover every substantive field a department profile has — teams, functions, business processes, KPIs, systems, and key terms/abbreviations, not just teams and functions.** A summary that omits an entire category (e.g. no KPIs, no processes) means every question about that category has nothing to match against, and will misroute or fail to route regardless of how good the matching logic is — verify field-by-field coverage against real data (e.g. count of processes/KPIs/systems actually present in each department's digest), not just that the summarizer ran without error.

Also build a **deterministic entity index** from these structured summaries — every owned team/function/abbreviation mapped to its owning department. When a question names an entity that exactly one department owns, route to it deterministically; fall back to semantic matching against summaries only when no owned entity is named. This two-tier approach (deterministic-first, semantic-fallback) is more reliable than semantic matching alone, and was arrived at after finding real cross-department mis-routing caused by unstructured summaries. **Do not index single ordinary/generic words as uniquely-owned entities** (acronyms are the exception) — a common word appearing in one department's text is not evidence that word uniquely belongs to that department, and indexing it as such will hijack unrelated questions from other departments that legitimately use the same ordinary word. When a longer, more specific match and a shorter, more generic match both apply, the longer match must win, not silently fall through to the shorter one. Normalize text variants before matching (e.g. "&" vs "and", partial/truncated phrases against their full canonical form) — these are common, expected variation, not edge cases to skip.

#### Two run modes — both required
The pipeline supports two modes, triggered by the two Embed buttons in section 3.4:

- **Incremental (default):** exactly steps 1–8 above — only files that are new or changed since the last run (per `ingestion_log`) are processed. Fast, cheap, the everyday path for "I added one new department's files."
- **Full re-embed (explicit, deliberate):** ignores `ingestion_log`'s `file_updated_at` check and reprocesses every file in the given scope (one HD, or all 18 if none specified) — delete the existing `documents` rows for that scope first, then run steps 1, 2, 4–8 for every file regardless of whether it changed, and rewrite the corresponding `ingestion_log` rows from scratch. Use this only for embedding-model changes, chunking-logic changes, or suspected data corruption — not as the everyday action.

**Orphan check (run in both modes):** compare the file list currently in the bucket against what's recorded in `ingestion_log` for that scope. Any `ingestion_log`/`documents` entries whose `storage_path` no longer exists in the bucket means that file was deleted or moved — remove their stale chunks from `documents` and their row from `ingestion_log` rather than leaving orphaned data behind. Neither run mode handles deletions on its own; this check is what does.

Because full re-embed and large incremental runs can take a while across 90+ files, run ingestion as an async job (not a request the frontend blocks on) — see the job-status endpoint in section 4.10.

### 4.6 Planner (`planner/`)
Given a user query, optional explicit HD mention (from `@mention` or a sidebar HD selection), and the loaded conversation context (section 4.11):
1. **Explicit HD given** → hard-scope retrieval to that `head_dept` only. No exceptions.
2. **No HD mentioned** → check the query against all 18 `hd_index.summary_md` entries (cheap semantic match, not a full vector search of `documents`). If the query is a follow-up (e.g. "what about last quarter", "who approves that") the recent conversation turns may resolve the reference — but the resolved HD still goes through the same confidence check below; conversation context informs *interpretation*, it never bypasses scoping or lets a prior turn's HD silently carry forward without being re-confirmed by the same logic as a fresh query.
   - High-confidence single/dual match → auto-scope to those HD(s), and the response must state which HD(s) it inferred.
   - Low-confidence / ambiguous → do not guess. Return a clarifying response asking the user to pick an HD or confirm searching all departments.
   - User explicitly says "search all departments" / "across everything" → run retrieval across all 18 HDs **in parallel — concurrent, not sequential, RPC calls; a sequential loop of 15+ single-department calls has been measured adding several seconds of pure round-trip latency and is a bug, not an acceptable implementation.**
     - **This path has two distinct shapes — do not treat them as the same thing.** A cross-department *question* ("what are the escalation contacts across departments") is correctly served by pooling all departments' results and reranking to the globally top-scoring chunks — you want the most relevant facts, regardless of which department they came from. A **broad/all-department summarization request** ("summarize all departments," "give me a full overview," "full picture across the company") is a different shape, and it is not solvable by adjusting *how many* chunks are kept per department — the deeper problem is that "summarize all departments" is a poor semantic query in the first place, since it names no topic to score against, and similarity-based retrieval scores everything near zero for it. **Retrieval for this shape must be structural, not semantic:** pull a defined slice per department directly by section (e.g. identity, functions, KPIs) rather than via similarity search. Structurally-pulled chunks carry no similarity score, so the pre-retrieval relevance gate is skipped for this shape specifically — but grounding, citation, and post-generation claim verification (section 4.7) still apply exactly as normal; skipping the relevance pre-check is not license to skip the safety checks that actually prevent hallucination.
     - **Per-department fan-out queries must not silently swallow failures.** A concurrent per-department query that fails (timeout, transient error) must be retried, not caught-and-ignored — a bare `except: continue` around a per-department call will silently produce a partial result (e.g. only the first few departments alphabetically) that looks complete but isn't. If a department's data still can't be retrieved after retry, the final answer must disclose that explicitly (e.g. "no data could be retrieved for X, Y") rather than presenting a partial summary as if it were exhaustive — an omission that misrepresents completeness is a real accuracy failure even if every included fact is individually grounded.
     - Detect which shape applies from the request itself: "summarize," "overview," "full picture," "everything" combined with an all-department scope signals broad coverage; a specific factual question phrased across departments signals the pooled/top-N shape.
     - Whichever shape is used, cite which HD each fact came from in the final answer.
3. Classify the task lane: **retrieval/Q&A**, **document creation**, **skill execution**, or **chitchat**. Route accordingly.

#### Chitchat lane — narrow, and never a hallucination loophole
Pure social pleasantries ("hi", "thanks", "how are you", "good morning") must not be forced through retrieval and the groundedness gate — that produces either a false refusal or a pointless knowledge-base search for a message with no informational content. Add a chitchat lane that responds naturally and briefly, without querying `documents` and without citing anything, since there is nothing to ground.
- Triggering must be narrow and conservative: only messages with **no informational request at all**. "Hi, what's the FDX figure" or "thanks — now what's the escalation path" are NOT chitchat; the informational part still goes through full retrieval and grounding. When in doubt, classify as retrieval, not chitchat — a wrongly-narrow chitchat classification just costs an extra "not found," a wrongly-broad one is a hallucination surface.
- A chitchat response must never assert a fact about any department, policy, or person. It's limited to acknowledgment and tone, nothing else.

#### Reference resolution ("this", "that", "it") — resolve or ask, never guess-and-refuse
A request like "summarize **this**" or "make **this** a document" contains a pronoun that must be resolved before retrieval runs — either against the current conversation's recent turns (section 4.11) if one exists, or, if there's no prior turn to resolve it against, treated as unresolvable. **An unresolved pronoun must trigger a clarifying question ("Summarize what, exactly?"), never a literal retrieval on the pronoun text and never a false "nothing found in the knowledge base."** Reporting "not found" for a reference-resolution failure is misleading — the knowledge base may have exactly what's needed, the query just never named it. This applies to the document-creation subject-extraction step (section 4.8) as much as to plain Q&A.
4. Log every routing decision (query, chosen HD(s), confidence score, lane) to `routing_log` for later threshold tuning — do not skip this, it's how the confidence threshold gets calibrated post-launch.

### 4.7 Groundedness gate (`groundedness/`)
- **Confidence signal — use rerank relevance, not raw `hybrid_search` score.** Since section 4.4's RRF rewrite, `hybrid_search`'s `score` encodes rank position only, not relevance magnitude — a rank-1 result scores in the same narrow band (~0.016–0.033) whether it's a perfect match or barely related. A threshold on that raw score checks nothing. The confidence check must run on the **reranker's** relevance score (section 4.4's reranking step, e.g. a 0–10 or 0–1 relevance judgment), not on anything coming directly out of `hybrid_search`.
- Before generating: if the top reranked relevance score is below a configured threshold, return "not found in knowledge base" rather than letting the LLM answer from general knowledge.
- After generating: verify each claim in the drafted answer against the retrieved chunks (claim-vs-chunk check, via a second LLM call or an NLI-style check). Drop or flag unsupported claims before returning the answer — if a claim fails verification, remove it from the answer outright, don't state it and separately caveat it as unverified in the same response. Every answer must cite its source file(s). **If verification strips the entire answer (zero claims survive), re-verify once before accepting that as final** — a total strip on a genuinely well-grounded answer is far more often a verifier misfire than a wholly-unsupported response, and this measurably fixed an intermittent ~1-in-5 false-refusal rate on correct answers.
- **Citation format — one file per bracket, always.** `[source: a.json, b.json]` or `[source: a.json, department: x]` breaks citation parsing and must never be produced, including under multi-department fan-out where the model is more likely to try to cram extra attribution into the bracket. Department attribution belongs in the surrounding prose, not inside the citation bracket — one file per bracket is a hard format rule, not a style preference.

#### `do_not_disclose` enforcement (never embed, always enforce)
Some department source files include an `ai_specific_knowledge.do_not_disclose` field naming specific confidential items (e.g. payroll figures, investment figures, security findings, named individuals in incidents). This field must **never** be embedded or made retrievable — the restriction text itself names the sensitive item, so indexing it would make the protected fact searchable via the very text meant to protect it. Instead:
- Exclude `do_not_disclose` entirely from the chunking/embedding pipeline (section 4.5).
- Store it in that HD's config (or a dedicated small table) and inject it into every generation and groundedness-check prompt for that department as a hard constraint, enforced regardless of what chunks were retrieved — not just at ingestion time.
- This applies per-department; a department with an empty `do_not_disclose` field has no added constraint.

### 4.8 Document creation (`docgen/`)
Takes grounded chunks (post-groundedness-gate) and generates docx / pdf / xlsx / image outputs. Do not let this module call the LLM to "fill in" missing data — it only formats what retrieval already grounded. Retrieval for a document-creation request must be driven by the extracted subject of the request, not the literal request text — e.g. "export the TAG roster as a spreadsheet" should retrieve on "TAG roster," not on the instruction to export/format it. **If the subject is a pronoun ("this", "that", "it") with nothing to resolve it against, ask what it refers to — do not retrieve on the literal pronoun and do not report "not found in knowledge base" for what is actually an unresolved reference, not a knowledge-base gap** (section 4.6).

**Document creation must support the same broad-coverage, all-department shape as Q&A (section 4.6) — this was previously missing and caused false "not found" results.** A request like "summarize all departments and make it a document" is not a single-department subject-extraction case; recognize the all-department scope the same way the retrieval planner does, run the broad-coverage retrieval (representative chunks from every in-scope department, not a pooled top-N), and generate the document from that full set. Do not fall through to single-subject extraction logic for a request that names no single subject because its subject *is* "everything."

### 4.9 Skill registry (`skills/`)
Claude-style skills: each skill is stored with a name, description, trigger keywords, optional HD scope, an instructions markdown, and an optional script. The planner matches incoming queries against skill descriptions the same way it matches HD summaries, and invokes a matching skill instead of (or alongside) retrieval when appropriate.

**Uploaded skill scripts are stored, never executed, until a sandboxing decision is made.** Running arbitrary user-uploaded code from an HTTP endpoint without a sandbox (a restricted subprocess, container, or language-level sandbox) is a genuine security hole, not a deferred nicety — do not implement direct execution (e.g. bare `exec`/`subprocess` of uploaded scripts) under any later instruction, including a request to "just make skills work end to end." Skills with only an `instructions_md` (no script) can still be matched and used to guide the LLM's response; only arbitrary script execution is blocked pending a real sandboxing design.

### 4.10 API contract (for later frontend wiring — build these routes now, but don't connect the frontend yet)
The live routes are defined in `backend/main.py` (grep `@app.`); request and response shapes are the Pydantic models beside them.

### 4.11 Conversation memory & chat history (`memory/`)
No authentication system exists yet, so identity for this section is a **client-generated anonymous ID** (a random UUID the frontend creates once and stores in a cookie/localStorage, sent as `anon_user_id` on every request) — not a real login. This is a deliberate placeholder: when real authentication exists later, `anon_user_id` is replaced by an actual user ID without changing the shape of anything below.

**Schema (add to section 4.3):**
DDL lives in `backend/db/004_memory_and_latency.sql`.
Enable RLS on both, same as every other table (section 4.4.1) — the backend's service role key is unaffected.

**Verification requirement — an isolated backend test passing is not sufficient proof this works.** Conversation continuity must be confirmed against the actual deployed frontend↔backend flow: send several real HTTP requests in sequence, from the same browser session, the way the UI actually sends them, and confirm each one reuses the same `conversation_id` and that later turns can see earlier ones. If a live multi-turn conversation loses scope (e.g. an `@mention`-established department is forgotten by the third message, or a follow-up like "make this a document" fails to resolve "this"), the likely cause is that the frontend is not persisting and resending the same `conversation_id` on every message in a thread — check this first before assuming the memory-loading logic itself is at fault.

**This exact failure has now been reported twice against a live deployment (P-Cube, then a broad-summary follow-up) despite being reported fixed in between — treat the previous fix as unverified, not done.** Before reporting this fixed again: attach the actual raw request/response sequence (or server log) proving three or more sequential turns in one real browser session share one `conversation_id` and that a later turn's answer changes based on an earlier turn's content. A description of the fix is not sufficient evidence; the transcript is.

**Behavior:**
- Every turn (user query + assistant answer) is written to `chat_turns` under its `conversation_id`. The frontend's sidebar "Recents" list (currently the demo's hardcoded strings) becomes real once wired (section 8) — populated from `GET /api/conversations`, not invented.
- The **planner and generation prompts** load the last `MEMORY_TURN_WINDOW` turns (env var, default 6) from the current conversation and include them as context — this is what lets a follow-up like "what about last quarter?" resolve correctly. This context informs interpretation only; it never relaxes HD scoping or the groundedness gate (section 4.6), and it must never be cited as a source — mark it clearly in the prompt as context, not evidence.
- A conversation's `title` is generated from the first user turn (a short LLM summarization call, or simply the first ~50 characters) once the first exchange completes.

### 4.12 Long-term memory (`memory/`)
Distinct from conversation memory — this persists facts *across* separate conversations for the same `anon_user_id` (e.g. "this user usually asks about CMO," a stated preference), not the running context of one session.

**Schema:**
DDL lives in `backend/db/004_memory_and_latency.sql`.

**Behavior and boundaries — read carefully, this is the part that needs care:**
- Write to `user_memory` only for durable, low-sensitivity context: stated preferences, a default department, recurring topics. A short LLM pass at the end of a conversation can propose candidate memories; keep the extraction conservative — when in doubt, don't write it.
- **Never write anything sourced from a `do_not_disclose`-protected fact, or anything that looks like a personal/sensitive detail about the user or a third party.** This must cover, at minimum: compensation figures, health, performance reviews and employment-standing matters (performance improvement plans — spelled out, not just "PIP" — warning letters, notice periods, probation, misconduct, grievances, layoffs), protected characteristics, and visa/immigration status. This list was arrived at by testing, not by guessing — a pattern-matching filter that catches "PIP" as an abbreviation but not "performance improvement plan" spelled out is a real gap, not a hypothetical one; verify coverage with explicit blocked/allowed test cases for each category, not just a spot check. Long-term memory is for interaction preferences, not a second copy of sensitive knowledge-base content or personal data about people.
- The person must be able to see and clear what's remembered about them — `GET /api/memory` and the two `DELETE` routes above are not optional extras, they ship with this feature, not after it.
- At the start of a new conversation, relevant `user_memory` rows for that `anon_user_id` are loaded and injected into the planner/generation context the same way conversation turns are — same rule applies: this informs interpretation, it never bypasses HD scoping or the groundedness gate.

### 4.13 Live status while waiting, and a safe answer reveal (`streaming/`)
The person should see real progress while a query is being processed, and the final answer should render as a natural typing-style reveal rather than popping in all at once. This must be built as **two separate things**, not one — conflating them creates a real safety problem.

**1. Progress messages — safe to stream live, must reflect real pipeline stages, never invented filler.**
Add a streaming status channel (Server-Sent Events, via the browser's native `EventSource` or a `fetch` + `ReadableStream` reader — no framework needed, consistent with the no-build-step frontend) that pushes a short message as each real pipeline stage starts: resolving department scope, searching the knowledge base, reranking results, verifying the answer. These must describe what is actually happening at that moment — not dramatized or invented text, the same principle as writing honest, boring status copy rather than something that sounds impressive but isn't accurate.

**2. The final answer is never streamed raw — only the fully verified result gets revealed, and only after section 4.7's claim verification has already run.** Streaming raw generation token-by-token (the way a typical chat UI does) is explicitly **not allowed** here: the whole reason section 4.7's post-generation verification step exists is so an unsupported claim can be removed before the person ever sees it. If the raw text is streamed live as it's generated, a person could read a claim that gets redacted a moment later — which defeats that safeguard entirely. Instead:
- Run the full pipeline (planner → retrieval → rerank → generation → claim verification) exactly as today, with no change to what gets shown.
- Only once the final, verified answer text is ready, send it to the frontend and reveal it with a cosmetic typing/reveal animation (e.g. a fast word-by-word or character reveal) — this is a client-side rendering effect over already-safe, already-verified text, not a live stream of the model's raw output.
- Cap the reveal speed so a long answer doesn't feel slower than the old instant-display behavior — e.g. reveal at a fixed fast rate, or fall back to an instant fade-in past some length threshold, rather than a reveal duration that scales with answer length.

---

## 5. Environment variables
The full set of variables the code reads is defined in `backend/config.py`.
Do not hardcode these anywhere — load via `config.py` from environment/`.env`, and add `.env` to `.gitignore`. Every OpenAI call in the codebase (`ingestion/`, `planner/`, `groundedness/`, the reranker) must read the model name from `OPENAI_CHAT_MODEL` or `OPENAI_EMBEDDING_MODEL` rather than hardcoding a model string, so the model can be changed in one place later if needed.

---

## 6. Build order (execute in this sequence)

1. Track A frontend edits (section 3) — small, fast, do this first and show the diff.
2. Supabase schema + `hybrid_search` RPC (section 4.3–4.4).
3. Ingestion pipeline for **one** HD's bucket folder end-to-end (list → diff against `ingestion_log` → download → chunk → embed → store in `documents` → log) — confirm real JSON schema with the user before writing the parser.
4. Once verified, run it across all 18 HD folders in the bucket.
5. FastAPI skeleton + Planner + hybrid retriever + groundedness gate — get plain Q&A accurate and hallucination-free before building anything else.
6. Document creation module.
7. Skill registry + skill agent.
8. Cross-department ("search all") retrieval path last — highest risk for leakage, build it once everything else is proven solid.
9. Conversation memory + chat history (section 4.11), then long-term memory (section 4.12) — build after core Q&A (step 5) is proven accurate, since both inject additional context into the same planner/generation prompts step 5 already hardened; adding them earlier would make it harder to isolate whether a bug came from retrieval or from memory context.

---

## 7. Acceptance criteria
- Frontend: `@mention` correctly resolves all 18 HD names/aliases including ones with `&` and parentheses; no fabricated per-HD answers remain in the file; visual/structural diff from the original is limited to data content.
- Backend: a query scoped to one HD never returns chunks from another HD (verify with a direct test querying two HDs with overlapping generic terms). A query below the confidence threshold returns "not found" rather than a guess. Every returned answer includes a source citation.
- Ingestion: chunk counts and `head_dept` tagging match the real folder structure across all 18 HDs and 90+ files.
- Memory: a follow-up question referencing a prior turn (e.g. "what about last quarter?") resolves correctly using conversation context, without that context ever relaxing HD scoping or the groundedness gate. A user can list and delete their own long-term memory via the API, and nothing in `user_memory` originates from a `do_not_disclose`-protected fact.

## 8. Verification & performance testing (ongoing, not a one-time pass)

### 8.0 Test hygiene — a test that pollutes production invalidates everything it "proves"
A test run that writes rows into the live `documents`, `skills`, `conversations`, or any other production table — and doesn't guarantee cleanup — can silently produce real, user-visible symptoms that get misdiagnosed as application bugs (this happened: three leftover test skills with generic trigger words caused ordinary user questions to be served by a stray skill and mislabeled in the lane badge, and it took real investigation to trace the mislabeling back to test pollution rather than a routing defect). Going forward:
- Any test that creates rows in a production table must remove them in a `finally` block (or equivalent guaranteed-cleanup mechanism), not rely on the happy path completing — a crash before the cleanup line still leaves contamination behind, which is exactly how this happened even with cleanup code already written.
- **Tag test-generated rows explicitly at write time** (a dedicated column or marker, not after-the-fact content matching) in any table a test writes to, especially `routing_log` and `latency_log` — these are the tables later calibration work depends on being genuine, and reconstructing "which rows were real" after the fact from query text alone is slow and only approximately correct. A write-time tag makes this exact, not inferred.
- Prefer a distinguishable naming/prefix convention for anything a test creates, so stray rows are easy to find and sweep even if cleanup is ever missed.
- Do a one-time audit now for pre-existing test-created contamination in any production table (the same pattern that caused the skill mislabeling could exist elsewhere, silently affecting behavior in ways not yet traced to a cause).
- **`--reload` is not proof of freshness — it has been confirmed to silently fail.** A real incident: server started at 13:51, code edited at 16:09, and a full 90-question sweep ran entirely against the stale 13:51 code without any error or warning, understating the true result. Do not treat "the server has `--reload`" as sufficient; explicitly restart before any measurement that matters, and confirm freshness with an actual behavioral check (e.g. a change you know should alter a specific response) before trusting the result. Also confirm no orphaned/zombie process is already bound to the expected port before trusting a "server is running" claim — a dead process can leave a listening socket behind that keeps serving stale code indefinitely, which looks identical to a healthy server from the outside. Log server output to a file so a crash is visible directly, not inferred from a batch of otherwise-unexplained test failures.
- **All test harnesses (API-level, browser-level, and the standing eval judge) must agree on one consistent definition of "answered" vs. "refused/no-record."** A confirmed incident: the API judge counted a response like "the documentation does not record X [source: ...]" as a successful answer, while the browser judge correctly called the same response a refusal — this inconsistency let 3 genuine knowledge-base gaps hide behind an inflated pass rate in one harness while another caught them correctly. Reconcile all judges onto one rule rather than trusting whichever harness reports the better number.
- **Do not write regex or any code containing `\b`, `\n`, or other backslash-escape sequences through a bash heredoc.** This has silently corrupted a regex into literal control bytes (e.g. `\b` becoming a literal backspace byte) on at least two separate occasions — the code still compiles and runs, it just silently matches nothing. Use the file-editing tool directly for anything containing backslash escapes, not a shell heredoc.

### 8.1 Browser automation testing — Playwright via Python
Use the Python `playwright` package (`pip install playwright`, then `playwright install chromium`) to drive a real headless browser against the running app. **This is a testing dependency, not frontend build tooling** — it does not violate the "no Node/React/build step" rule, since the frontend itself remains one static HTML file with no build process. Keep this distinction explicit in any test setup docs so it's never confused with a frontend framework decision.

- Write tests under `backend/tests/e2e/` that click through the real UI: select a sidebar HD, use `@mention`, submit an ambiguous query, an unambiguous unscoped query, a document-creation request, a query about an empty department (Finance/SME Advisory Group/OCPE), and — if a known `do_not_disclose` topic exists — a probe for it. Assert on rendered DOM: citation badges present and correct, inferred-HD badge shown when expected, download links actually resolve to a real file, both Embed buttons still function.
- On any failure, capture a screenshot and the browser console log — a bare pass/fail isn't enough to debug from.
- This is a **regression suite**, not a one-off script: re-run it after any frontend or API-contract change, not just once now.

### 8.2 Latency profiling — measure before optimizing
Do not guess at the cause of high latency. Instrument timing around each pipeline stage per request (planner call, `hybrid_search` DB round-trip, reranking, groundedness pre-check, generation, post-generation claim verification) and log it (e.g. alongside `routing_log`, or a dedicated latency column/table) so the real bottleneck is identified from actual data.
- Report end-to-end p50/p95 latency plus the per-stage breakdown before proposing a fix.
- **Likely culprit worth checking first:** section 4.4 left reranking as either a local cross-encoder or an LLM-based rerank pass. If the LLM-based option was implemented, that's a full API round-trip on top of the planner call, the generation call, and the groundedness verification call — potentially 4 sequential LLM calls per query. Switching reranking to a local cross-encoder removes one of those round-trips entirely and is the highest-leverage fix if profiling confirms it's the bottleneck.
- Cross-department fan-out issues one `hybrid_search` call per department — these must run concurrently (section 4.6), not sequentially, and the pooled results are reranked in a single batched pass (section 4.4). Profile this path specifically, separately from single-department queries, since it's the highest-latency case.

### 8.3 Response quality eval harness
Extend the step 8 adversarial-pass method (already used once for cross-department retrieval) into a **standing, repeatable eval set** covering the whole system, not just fan-out: a fixed list of test queries per department spanning correct-answer cases, ambiguous-scope cases, out-of-KB refusal cases, `do_not_disclose` probes, and document-creation requests, each with an expected *outcome type* (not necessarily an exact expected answer string). Re-run this eval set after any change to the planner, retriever, reranker, or groundedness logic — report pass/fail and latency per case, not just an overall summary.

**Coverage must span question *types*, not just scenarios — this has been the actual gap.** Fixes so far have mostly targeted specific reported phrasings ("summarize all departments," a particular pronoun case) rather than being tested against the real diversity of how people ask questions. Without an explicit department mention, the eval set must include — for multiple departments, not just one — at minimum: a factual lookup ("what is X"), a "who" question ("who leads/owns X"), a procedural "how" question ("how do I escalate X" / "how does X work"), a list-type question ("what are the KPIs/services/policies for X"), and a comparison or multi-fact question. For each, the scope-inference step (section 4.6) must correctly identify the matching department at a similarity/confidence level comparable to what a "summarize" query gets — if certain question *shapes* consistently score lower in the department-matching step than others, that is itself a bug in the matching approach, not a property of those question types. Do not fix this by adding more keyword patterns for specific phrasings; fix the underlying scope-matching so it generalizes across phrasing, and prove that generalization with this broader test matrix, not a narrow patch verified against only the reported example.

**Required additions found through real usage, not synthetic testing — these are proof the existing suite had gaps, not optional extras:**
- A multi-turn conversation that establishes a department via `@mention`, gets a correct answer, then a *later* turn with no department mentioned and a vague referent ("make this a document") — assert the department scope is still remembered, not re-asked.
- A document-creation request whose subject is an unresolved pronoun with no prior turn to resolve it against — assert it asks for clarification, not a false "not found in knowledge base."
- A pure chitchat message ("hi", "thanks") — assert it gets a natural short reply with no knowledge-base query and no citations, and a chitchat-phrased message that also contains a real question — assert the question portion still gets fully grounded treatment.

## 9. Explicit boundaries
- Frontend↔backend wiring happens only when explicitly instructed in a given prompt, not inferred from other work being done — this restriction is lifted for the specific session where wiring is requested, not a permanent prohibition.
- Do not fabricate department content anywhere, in either track.
- Do not add Node/React/JS build tooling to the frontend itself — Playwright (Python) for testing is not an exception to work around, it's simply a different category (test tooling, not frontend build tooling).
- Ask before assuming the JSON schema for any department.
- Do not write sensitive personal or `do_not_disclose`-protected content into `user_memory` under any circumstance, including a later instruction that seems to ask for it.
- **No hardcoded or canned response text anywhere, including fallback and chitchat replies.** Every substantive answer must be generated dynamically from actually-retrieved content; even chitchat replies (section 4.6) must come from the model, not a fixed string table. If an audit finds hardcoded response text left over from earlier scaffolding, remove it. **A concrete instance found in production: a "not found" message named a specific department (e.g. "Delivery Management") regardless of which department the conversation was actually scoped to** — this is what a hardcoded example/placeholder department name in a fallback string looks like once it leaks. Any refusal or "not found" message must be built from the actual current scope at the moment it's generated, never from a literal string containing a specific department name. **Canned text also hides inside LLM system prompts, not just literal code strings — an instruction telling the model to output a specific fixed phrase under some condition is functionally hardcoding, even though grep won't find it as a returned string.** A confirmed instance: a rewrite-system prompt instructed the model to say a fixed refusal phrase, which then fired intermittently on genuinely answerable questions. Audit prompts/instructions for this pattern, not only literal string constants.
- **A bug reported fixed must be reproduced live in the actual browser against the exact original scenario before being called fixed again** — this has now failed multiple times (a passing automated test or isolated proof did not match live browser behavior). If the same category of bug resurfaces after being reported fixed, treat that as evidence the test suite isn't exercising the real failing path, not as a reason to just reapply the same patch.
- **The displayed lane badge must match what actually happened.** If a response was served by retrieval, it must be labeled retrieval, not skill or anything else — a mismatched lane label is itself a bug to report and fix, not a cosmetic detail.
