"""Shared Supabase and AWS Bedrock clients.

Chat and embeddings both go through Bedrock (CLAUDE.md section 4.1). Credentials come
from boto3's default credential chain -- on AWS, the attached IAM role. Nothing here
reads an AWS key.
"""
from __future__ import annotations

import json
import logging
import random
import re
import time
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, Callable, TypeVar

import boto3
import httpx
from botocore.config import Config
from botocore.exceptions import (
    ClientError,
    ConnectionClosedError,
    ConnectTimeoutError,
    EndpointConnectionError,
    ReadTimeoutError,
)
from supabase import Client, create_client

from config import (
    AWS_REGION,
    BEDROCK_CHAT_MODEL_ARN,
    BEDROCK_EMBEDDING_MODEL_ARN,
    BEDROCK_REASONING_EFFORT,
    SUPABASE_KEY,
    SUPABASE_URL,
)

T = TypeVar("T")
log = logging.getLogger(__name__)

# Transport-level failures: the connection broke, so nothing was computed and the
# call is safe to repeat. Measured on this project: five HTTP 500s across two full
# matrix runs, every one an httpx.RemoteProtocolError (StreamReset) raised out of a
# hybrid_search RPC, and a different case each time.
#
# postgrest ships a send_with_retry, but it only covers GET/HEAD returning 503/520
# (Cloudflare). An RPC is a POST, and a stream reset carries no status code at all,
# so none of these were ever retried -- one dropped HTTP/2 stream became a
# user-visible 500. The Bedrock calls below have their own retry policy (see
# _with_retry), which is why this sits on the Supabase side.
_TRANSIENT = (
    httpx.RemoteProtocolError,
    httpx.ReadError,
    httpx.WriteError,
    httpx.ConnectError,
    httpx.ConnectTimeout,
    httpx.ReadTimeout,
    httpx.PoolTimeout,
    ConnectionResetError,
)


def db_call(fn: "Callable[[], T]", attempts: int = 3, base_delay: float = 0.25) -> T:
    """Run a Supabase call, retrying transport failures with a short backoff.

    Deliberately narrow: only the exceptions above are retried. A PostgREST error
    (bad filter, missing table, RLS refusal) is a real answer from the server and
    is re-raised immediately -- retrying it would just hide the bug three times.
    """
    delay = base_delay
    for attempt in range(attempts):
        try:
            return fn()
        except _TRANSIENT:
            if attempt == attempts - 1:
                raise
            time.sleep(delay)
            delay *= 2
    raise AssertionError("unreachable")


@lru_cache(maxsize=1)
def supabase() -> Client:
    return create_client(SUPABASE_URL, SUPABASE_KEY)


# ---------------------------------------------------------------------------
# AWS Bedrock
# ---------------------------------------------------------------------------

# Cohere Embed v4 accepts at most 96 texts per invoke_model call (AWS docs,
# model-parameters-embed-v4). Callers may pass larger batches; they are split here.
COHERE_MAX_TEXTS_PER_CALL = 96

# Embedding dimension is fixed by the vector(1536) column; Cohere is asked for it
# explicitly so the schema never depends on the model default.
_COHERE_OUTPUT_DIM = 1536

_MAX_ATTEMPTS = 5
_BASE_DELAY_S = 1.0
_MAX_DELAY_S = 20.0

# Throttling and capacity errors are retried. Everything else that comes back as a
# ClientError (AccessDenied, Validation, ResourceNotFound, expired token ...) is a
# permanent answer and is raised immediately.
_RETRYABLE_CODES = frozenset({
    "ThrottlingException",
    "ServiceUnavailableException",
    "ModelTimeoutException",
})

# Transient network failures reach boto3 as these, not as ClientError.
_TRANSIENT_EXC = (
    EndpointConnectionError,
    ConnectionClosedError,
    ConnectTimeoutError,
    ReadTimeoutError,
    ConnectionError,
)

# Opening or closing code-fence markers, with an optional language tag.
_FENCE_RE = re.compile(r"^```[A-Za-z0-9_-]*\s*|\s*```$")

_JSON_INSTRUCTION = (
    "Respond with exactly one valid JSON object and nothing else. Do not wrap it in "
    "code fences and do not add any text before or after it."
)


class BedrockError(RuntimeError):
    """A Bedrock call failed for good. The message always names the error type."""

    def __init__(self, code: str, message: str):
        super().__init__(f"Bedrock {code}: {message}")
        self.code = code


def _error_code(exc: BaseException) -> str:
    if isinstance(exc, ClientError):
        return exc.response.get("Error", {}).get("Code", "ClientError")
    return type(exc).__name__


def _is_retryable(exc: BaseException) -> bool:
    if isinstance(exc, ClientError):
        return _error_code(exc) in _RETRYABLE_CODES
    return isinstance(exc, _TRANSIENT_EXC)


def _with_retry(op: str, fn: Callable[[], T], max_attempts: int = _MAX_ATTEMPTS) -> T:
    """Run one Bedrock call with exponential backoff and jitter on transient errors."""
    for attempt in range(max_attempts):
        try:
            return fn()
        except Exception as exc:
            code = _error_code(exc)
            if not _is_retryable(exc):
                raise BedrockError(code, f"{op} failed (not retried): {exc}") from exc
            if attempt == max_attempts - 1:
                raise BedrockError(
                    code, f"{op} still failing after {max_attempts} attempts: {exc}"
                ) from exc
            # Exponential backoff with jitter: half to full of the nominal delay.
            nominal = min(_MAX_DELAY_S, _BASE_DELAY_S * (2 ** attempt))
            delay = nominal * (0.5 + random.random() / 2)
            log.warning("Bedrock %s transient %s; retry %d/%d in %.1fs",
                        op, code, attempt + 1, max_attempts - 1, delay)
            time.sleep(delay)
    raise AssertionError("unreachable")


@lru_cache(maxsize=1)
def bedrock_runtime() -> Any:
    """Singleton bedrock-runtime client. Credentials come from the default chain.

    botocore's own retries are switched off (max_attempts=1) so that _with_retry is
    the single retry policy and the attempt count stays what the code says it is.
    """
    return boto3.client(
        "bedrock-runtime",
        region_name=AWS_REGION,
        config=Config(
            retries={"max_attempts": 1, "mode": "standard"},
            connect_timeout=10,
            read_timeout=120,
        ),
    )


# ----- Chat (Converse API) --------------------------------------------------

# Flips to False the first time Luna rejects `temperature`, and stays False for the
# rest of the process so later calls do not pay for the failed attempt again.
_temperature_supported = True


@dataclass
class _Message:
    content: str


@dataclass
class _Choice:
    message: _Message


@dataclass
class ChatCompletion:
    """Same read shape the call sites already use: resp.choices[0].message.content."""
    choices: list[_Choice] = field(default_factory=list)


def _is_temperature_rejection(exc: ClientError) -> bool:
    if _error_code(exc) != "ValidationException":
        return False
    message = exc.response.get("Error", {}).get("Message", "").lower()
    return "temperature" in message or "inferenceconfig" in message


def _converse_once(payload: dict[str, Any], temperature: float | None) -> dict[str, Any]:
    global _temperature_supported
    send_temperature = temperature is not None and _temperature_supported
    try:
        if send_temperature:
            return bedrock_runtime().converse(
                **payload, inferenceConfig={"temperature": temperature})
        return bedrock_runtime().converse(**payload)
    except ClientError as exc:
        if not (send_temperature and _is_temperature_rejection(exc)):
            raise
        _temperature_supported = False
        log.warning("Bedrock chat model rejected temperature (%s); retrying once without "
                    "it, and not sending temperature for the rest of this process.",
                    exc.response.get("Error", {}).get("Message", "")[:200])
        return bedrock_runtime().converse(**payload)


def _extract_json(text: str) -> str:
    """Return the first balanced JSON object or array in text, or text unchanged.

    Code fences are stripped first. Each candidate start is tried with raw_decode,
    which handles nested braces and quoted braces correctly. If nothing parses, the
    input comes back unchanged, so the caller's json.loads raises exactly as it would
    on a bad OpenAI JSON response, and the caller's existing fallback runs.
    """
    stripped = _FENCE_RE.sub("", text.strip()).strip()
    decoder = json.JSONDecoder()
    for i, ch in enumerate(stripped):
        if ch not in "{[":
            continue
        try:
            _, end = decoder.raw_decode(stripped, i)
        except ValueError:
            continue
        return stripped[i:end]
    return text


def _response_text(response: dict[str, Any]) -> str:
    """Join the text blocks only. Reasoning and other non-text blocks are skipped."""
    blocks = (response.get("output", {}).get("message", {}).get("content")) or []
    return "".join(b["text"] for b in blocks if isinstance(b, dict) and "text" in b).strip()


def chat_create(
    *,
    messages: list[dict[str, str]],
    temperature: float | None = None,
    response_format: dict[str, Any] | None = None,
) -> ChatCompletion:
    """Drop-in for the OpenAI chat.completions.create calls in this codebase.

    messages: [{"role": "system"|"user"|"assistant", "content": str}, ...]
    response_format: {"type": "json_object"} requests JSON. Converse has no JSON mode
        here, so the instruction is added to the system prompt and the reply is run
        through _extract_json.
    The model is always BEDROCK_CHAT_MODEL_ARN; no call site chooses one.
    """
    json_mode = bool(response_format) and response_format.get("type") == "json_object"

    system_parts: list[str] = []
    converse_messages: list[dict[str, Any]] = []
    for m in messages:
        if m["role"] == "system":
            system_parts.append(m["content"])
        else:
            converse_messages.append({"role": m["role"], "content": [{"text": m["content"]}]})
    if json_mode:
        system_parts.append(_JSON_INSTRUCTION)

    payload: dict[str, Any] = {
        "modelId": BEDROCK_CHAT_MODEL_ARN,
        "messages": converse_messages,
    }
    if system_parts:
        payload["system"] = [{"text": "\n\n".join(system_parts)}]
    if BEDROCK_REASONING_EFFORT:
        # Shape taken from the Luna reasoning request. AWS docs for this model were not
        # found while writing this; verify on first run (see the migration report).
        payload["additionalModelRequestFields"] = {
            "reasoning_effort": BEDROCK_REASONING_EFFORT,
        }

    response = _with_retry(
        "Converse", lambda: _converse_once(payload, temperature))
    text = _response_text(response)
    if json_mode:
        text = _extract_json(text)
    return ChatCompletion(choices=[_Choice(message=_Message(content=text))])


# ----- Embeddings (Cohere Embed v4 via InvokeModel) --------------------------

def _parse_float_embeddings(payload: dict[str, Any]) -> list[list[float]]:
    """Accept both documented response shapes.

    embeddings_floats:   {"embeddings": [[...], ...]}
    embeddings_by_type:  {"embeddings": {"float": [[...], ...]}}
    """
    emb = payload.get("embeddings")
    if isinstance(emb, dict):
        if "float" not in emb:
            raise BedrockError(
                "EmbeddingParse", f"no 'float' key in embeddings (got {sorted(emb)})")
        emb = emb["float"]
    if not isinstance(emb, list):
        raise BedrockError("EmbeddingParse", "embeddings is neither a list nor a dict")
    return [list(v) for v in emb]


def cohere_embed(
    texts: list[str],
    input_type: str,
    max_attempts: int = _MAX_ATTEMPTS,
) -> list[list[float]]:
    """Embed texts with Cohere Embed v4. Output order matches input order.

    input_type: "search_document" for corpus chunks, "search_query" for queries.
    """
    vectors: list[list[float]] = []
    for start in range(0, len(texts), COHERE_MAX_TEXTS_PER_CALL):
        chunk = texts[start:start + COHERE_MAX_TEXTS_PER_CALL]
        body = json.dumps({
            "input_type": input_type,
            "texts": chunk,
            "embedding_types": ["float"],
            "output_dimension": _COHERE_OUTPUT_DIM,
            "truncate": "RIGHT",
        })

        def _invoke() -> dict[str, Any]:
            resp = bedrock_runtime().invoke_model(
                modelId=BEDROCK_EMBEDDING_MODEL_ARN,
                body=body,
                contentType="application/json",
                accept="*/*",
            )
            return json.loads(resp["body"].read())

        payload = _with_retry("InvokeModel", _invoke, max_attempts=max_attempts)
        parsed = _parse_float_embeddings(payload)
        if len(parsed) != len(chunk):
            raise BedrockError(
                "EmbeddingCountMismatch",
                f"sent {len(chunk)} texts, received {len(parsed)} vectors")
        vectors.extend(parsed)
    return vectors
