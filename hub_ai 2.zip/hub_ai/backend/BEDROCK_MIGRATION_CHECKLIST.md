# Bedrock migration — provider call-site checklist

Built in Step 1 (investigation) from a grep of `backend/` (excluding `.venv`).
Used again in Step 4: every row must be EXECUTED and marked PASS/FAIL with evidence.

Common to every chat call: two messages (`system` + `user`), no `max_tokens`,
no streaming, no tools, reads `resp.choices[0].message.content`.

## Provider setup

| # | File:line | What | Status |
|---|---|---|---|
| P1 | `config.py:26-28` | `OPENAI_API_KEY` (required), `OPENAI_CHAT_MODEL`, `OPENAI_EMBEDDING_MODEL` | [ ] |
| P2 | `clients.py:9,12,62-64` | `openai_client()` singleton (`lru_cache`); SDK default retries (max_retries=2) | [ ] |

## Chat completions

| # | File:line | Function | temperature | JSON mode | Output used as | Status |
|---|---|---|---|---|---|---|
| C1 | `responder.py:86` | `compose` (all refusals/clarifications/chitchat) | **0.5 default** (param) | no | text; 2 attempts, raises on failure | [ ] |
| C2 | `planner/planner.py:219` | `is_pure_social` | 0 | yes | JSON | [ ] |
| C3 | `planner/planner.py:406` | `understand` (intent/shape) | 0 | yes | JSON | [ ] |
| C4 | `planner/planner.py:710` | `depends_on_context` | 0 | yes | JSON | [ ] |
| C5 | `planner/planner.py:785` | `_resolve_once` (reference resolution) | 0 | yes | JSON | [ ] |
| C6 | `planner/planner.py:887` | `classify_lane` | 0 | yes | JSON | [ ] |
| C7 | `planner/planner.py:1156` | `resolve_scope` LLM router | 0 | yes | JSON | [ ] |
| C8 | `groundedness/gate.py:549` | `generate` (answer draft) | 0 | no | text | [ ] |
| C9 | `groundedness/gate.py:725` | `verify` (claim audit) | 0 | yes | JSON | [ ] |
| C10 | `groundedness/gate.py:744` | `verify` (rewrite without unsupported claims) | 0 | no | text | [ ] |
| C11 | `retriever/retriever.py:225` | `rerank` LLM fallback | 0 | yes | JSON | [ ] |
| C12 | `ingestion/summarizer.py:159` | `generate_summary` (hd_index) | 0 | no | text | [ ] |
| C13 | `memory/store.py:213` | `generate_title` | 0 | no | text | [ ] |
| C14 | `memory/store.py:338` | `propose_memories` | 0 | yes | JSON | [ ] |
| C15 | `skills/registry.py:72` | `execute` (instruction-only skill) | 0 | no | text | [ ] |

## Embeddings

| # | File:line | Function | Notes | Status |
|---|---|---|---|---|
| E1 | `ingestion/embedder.py:30` | `embed_texts` | batches of `EMBED_BATCH_SIZE` (64), inputs truncated to 32k chars, own retry (5 tries, backoff 2s doubling), asserts dim == 1536, reorders by `d.index` | [ ] |
| E2 | `ingestion/embedder.py:49` | `embed_query` | wraps `embed_texts([text])[0]` — used by `retriever.search_by_dept` | [ ] |

## No provider calls (confirmed)

- `docgen/generator.py` — `_title` is deterministic (no LLM), despite the module docstring mentioning an optional LLM title.
- `tests/**` — no direct OpenAI use; they reach the provider only through the app code above.
- `main.py` — only indirectly (via `responder`, `planner`, `gate`, etc.).
