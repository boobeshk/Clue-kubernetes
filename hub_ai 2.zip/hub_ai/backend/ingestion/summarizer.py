"""hd_index.summary_md generation (CLAUDE.md section 4.5 step 8, 4.6).

The planner routes an un-scoped query by matching it against these summaries, so a
summary is not documentation -- it is the matching index. Three properties matter,
each learned from a measured routing failure:

1. NEVER name another department. Summaries used to end "Related departments include
   CMD, CSM, DEM, KMD", copied from ai_specific_knowledge.related_departments. To a
   text-matching router that is pure misdirection: 7 of 15 summaries named a
   department they do not own.

2. Never claim another department's questions. FDE DCG's summary said "users may
   inquire about the differences between OQL and SQL" -- so "what is the difference
   between an OQL and an SQL?" routed to FDE DCG at 0.8 confidence instead of CMO,
   confidently wrong. Example questions are only included when they are about this
   department's own entities.

3. Enumerate the ENTITIES people actually name -- every team, sub-department,
   function and abbreviation. CMO's summary omitted Pitch Lab and Capability
   Collateral, two of its five teams, so "who leads Pitch Lab?" matched nothing and
   scored 0.0. Questions name teams and systems far more often than they name a head
   department, so entity coverage is what makes matching generalise across phrasing
   rather than working only for the shapes someone happened to test.

The structured tail exists so matching keys off entities rather than narrative prose.
"""
from __future__ import annotations

import json

from clients import chat_create

_SYSTEM = """You write the routing index entry for ONE head department of an internal
knowledge base. A router compares user questions against these entries to decide which
department can answer, so precision about what this department OWNS is everything.

Write two parts.

PART 1 - two or three sentences of prose: what this department does, in its own terms.

PART 2 - these exact labelled lines, each a comma-separated list drawn ONLY from the
digest. Include every line that has content; omit a line only if its list is empty:
Teams and sub-departments: ...
Functions: ...
Processes: ...
KPIs: ...
Systems: ...
Key terms and abbreviations: ...
Typical questions: ...

Hard rules:
- NEVER name another head department, and never add a "related departments" line. If
  the digest mentions other departments, ignore them completely.
- Include EVERY team and sub-department name from the digest. These are what users
  actually name in questions; omitting one makes questions about it unroutable.
- Expand abbreviations as "ABC (Full Name)" so both forms match.
- Invent nothing. Every name and term must appear in the digest.
- No preamble, no headings beyond the labels listed above."""


def build_digest(hd_display: str, profiles: list[dict]) -> dict:
    """Entity-rich digest for one head department.

    related_departments is deliberately NOT collected -- it names other departments,
    which is exactly what must not reach the routing index.
    """
    sub_departments, questions, synonyms, abbreviations = [], [], [], []
    functions, services, systems, teams = [], [], [], []
    # Processes and KPIs are indexed because questions name them constantly --
    # "how does the RFP build process work", "what is CM% margin achievement",
    # "how is SME utilization reported". A routing index that lists only teams and
    # functions cannot route any of those: measured, 7 of 8 such entities were
    # absent from the index and their questions either asked for clarification or
    # went to the wrong department.
    processes, kpis = [], []

    for doc in profiles:
        name = (doc.get("department_name") or "").strip()
        if name:
            sub_departments.append(name)

        ident = doc.get("department_identity") or {}
        if isinstance(ident, dict):
            for key in ("business_function", "purpose"):
                v = ident.get(key)
                if isinstance(v, str) and 0 < len(v) < 200:
                    functions.append(v.strip())

        org = doc.get("organization_structure") or {}
        if isinstance(org, dict):
            for key in ("leadership_team", "managers", "team_leads", "roles"):
                v = org.get(key)
                if isinstance(v, list):
                    teams.extend(x for x in v if isinstance(x, str))
                elif isinstance(v, str) and v.strip():
                    teams.append(v.strip())

        aik = doc.get("ai_specific_knowledge") or {}
        if isinstance(aik, dict):
            questions.extend(q for q in (aik.get("common_user_questions") or [])
                             if isinstance(q, str))
            for kv in aik.get("keywords_and_synonyms") or []:
                if isinstance(kv, dict) and kv.get("term"):
                    synonyms.append(f"{kv.get('term')} ({kv.get('synonym')})")
            for kv in aik.get("common_abbreviations") or []:
                if isinstance(kv, dict) and kv.get("abbreviation"):
                    abbreviations.append(f"{kv.get('abbreviation')} ({kv.get('meaning')})")

        for fn in doc.get("functions") or []:
            if isinstance(fn, dict) and fn.get("function_name"):
                functions.append(fn["function_name"])
        for sv in doc.get("services_offered") or []:
            if isinstance(sv, dict) and sv.get("service_name"):
                services.append(sv["service_name"])
        for sy in doc.get("systems") or []:
            if isinstance(sy, dict):
                n = sy.get("name") or sy.get("system_name")
                if n:
                    systems.append(n)
        for bp in doc.get("business_processes") or []:
            if isinstance(bp, dict) and (bp.get("name") or bp.get("process_name")):
                processes.append(bp.get("name") or bp.get("process_name"))
        for sop in doc.get("sops") or []:
            if isinstance(sop, dict) and sop.get("sop_name"):
                processes.append(sop["sop_name"])
        for kp in doc.get("kpis") or []:
            if isinstance(kp, dict) and (kp.get("name") or kp.get("kpi_name")):
                kpis.append(kp.get("name") or kp.get("kpi_name"))

    def dedupe(seq, limit):
        seen, out = set(), []
        for x in seq:
            k = (x or "").strip()
            if k and k.lower() not in seen:
                seen.add(k.lower())
                out.append(k)
            if len(out) >= limit:
                break
        return out

    return {
        "head_department": hd_display,
        "sub_departments": dedupe(sub_departments, 30),
        "teams_and_roles": dedupe(teams, 40),
        "functions": dedupe(functions, 45),
        "services": dedupe(services, 30),
        "processes": dedupe(processes, 40),
        "kpis": dedupe(kpis, 40),
        "systems": dedupe(systems, 25),
        "key_terms": dedupe(synonyms, 40),
        "abbreviations": dedupe(abbreviations, 40),
        "common_user_questions": dedupe(questions, 40),
    }


def generate_summary(hd_display: str, profiles: list[dict]) -> str:
    digest = build_digest(hd_display, profiles)
    resp = chat_create(
        temperature=0,
        messages=[
            {"role": "system", "content": _SYSTEM},
            {"role": "user", "content": json.dumps(digest, ensure_ascii=False, indent=2)},
        ],
    )
    return (resp.choices[0].message.content or "").strip()
