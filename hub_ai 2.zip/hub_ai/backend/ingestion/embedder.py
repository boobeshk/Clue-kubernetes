"""Embeddings via AWS Bedrock, Cohere Embed v4 (CLAUDE.md sections 4.1, 4.5 step 6).

The model is BEDROCK_EMBEDDING_MODEL_ARN -- never hardcoded. The Bedrock call, its
retry policy and the response parsing live in clients.py.
"""
from __future__ import annotations

from clients import cohere_embed
from config import BEDROCK_EMBEDDING_MODEL_ARN, EMBED_BATCH_SIZE, EMBEDDING_DIM

# Cohere Embed v4 accepts up to ~128k tokens per input, so this cap is only a
# safety net against a pathological profile_text, not a model-limit workaround.
# ~4 chars/token is the usual rough ratio.
_MAX_CHARS = 8000 * 4


def embed_texts(
    texts: list[str],
    max_retries: int = 5,
    input_type: str = "search_document",
) -> list[list[float]]:
    """Embed a list of texts, preserving order.

    input_type is "search_document" for corpus chunks (the default, used by ingestion)
    and "search_query" for queries at search time.
    """
    if not texts:
        return []
    vectors: list[list[float]] = []

    for start in range(0, len(texts), EMBED_BATCH_SIZE):
        batch = [t[:_MAX_CHARS] for t in texts[start:start + EMBED_BATCH_SIZE]]
        for vec in cohere_embed(batch, input_type=input_type, max_attempts=max_retries):
            if len(vec) != EMBEDDING_DIM:
                raise RuntimeError(
                    f"{BEDROCK_EMBEDDING_MODEL_ARN} returned {len(vec)} dims, "
                    f"but documents.embedding is vector({EMBEDDING_DIM})."
                )
            vectors.append(vec)

    return vectors


def embed_query(text: str) -> list[float]:
    return embed_texts([text], input_type="search_query")[0]
