"""Offline unit tests for the Bedrock adapters in clients.py and ingestion/embedder.py.

Every AWS call is mocked. Nothing here needs AWS credentials, Supabase or the network.
Run with:  python -m unittest tests.test_bedrock_adapter
"""
from __future__ import annotations

import json
import os
import unittest
from unittest import mock

from botocore.exceptions import ClientError, EndpointConnectionError

# config.py refuses to import without these. Dummy ARNs are set only if the environment
# does not already define them; they are not real resources and no call is made.
os.environ.setdefault("AWS_REGION", "us-east-1")
os.environ.setdefault("BEDROCK_CHAT_MODEL_ARN", "arn:aws:bedrock:us-east-1:000000000000:application-inference-profile/test-chat")
os.environ.setdefault("BEDROCK_EMBEDDING_MODEL_ARN", "arn:aws:bedrock:us-east-1:000000000000:embedding/test-embed")

import clients  # noqa: E402
from clients import BedrockError, chat_create, cohere_embed  # noqa: E402
from ingestion import embedder  # noqa: E402


def _client_error(code: str, message: str = "boom", op: str = "Converse") -> ClientError:
    return ClientError({"Error": {"Code": code, "Message": message}}, op)


def _converse_reply(*blocks: dict) -> dict:
    return {"output": {"message": {"role": "assistant", "content": list(blocks)}}}


def _embed_body(payload: dict) -> mock.Mock:
    stream = mock.Mock()
    stream.read.return_value = json.dumps(payload).encode("utf-8")
    return {"body": stream}


class _AdapterTestCase(unittest.TestCase):
    def setUp(self) -> None:
        # Each test starts with temperature assumed supported, as at process start.
        clients._temperature_supported = True
        self.runtime = mock.Mock()
        patcher = mock.patch.object(clients, "bedrock_runtime", return_value=self.runtime)
        patcher.start()
        self.addCleanup(patcher.stop)
        sleeper = mock.patch.object(clients.time, "sleep")
        self.sleep = sleeper.start()
        self.addCleanup(sleeper.stop)


class JsonExtractionTests(unittest.TestCase):
    def test_plain_object_passes_through(self):
        self.assertEqual(clients._extract_json('{"a": 1}'), '{"a": 1}')

    def test_code_fence_is_stripped(self):
        self.assertEqual(clients._extract_json('```json\n{"a": 1}\n```'), '{"a": 1}')

    def test_single_line_fence_is_stripped(self):
        self.assertEqual(clients._extract_json('```{"a": 1}```'), '{"a": 1}')

    def test_prose_around_object_is_removed(self):
        text = 'Sure, here you go: {"claims": [{"claim": "x", "supported": true}]} Thanks.'
        self.assertEqual(json.loads(clients._extract_json(text)),
                         {"claims": [{"claim": "x", "supported": True}]})

    def test_nested_and_quoted_braces_are_balanced_correctly(self):
        text = 'Result: {"text": "a } brace and { another", "nested": {"k": [1, 2]}} done'
        self.assertEqual(json.loads(clients._extract_json(text))["nested"], {"k": [1, 2]})

    def test_array_is_extracted_when_no_object_present(self):
        self.assertEqual(clients._extract_json("values: [1, 2, 3]"), "[1, 2, 3]")

    def test_unparseable_text_is_returned_unchanged(self):
        # Unchanged means the caller's json.loads raises, and the caller's existing
        # except-branch fallback runs.
        self.assertEqual(clients._extract_json("no json here at all"), "no json here at all")
        with self.assertRaises(json.JSONDecodeError):
            json.loads(clients._extract_json("{broken"))


class ChatAdapterTests(_AdapterTestCase):
    def test_text_blocks_only_and_reasoning_is_ignored(self):
        self.runtime.converse.return_value = _converse_reply(
            {"reasoningContent": {"reasoningText": {"text": "private chain of thought"}}},
            {"text": "Hello "},
            {"text": "there"},
        )
        resp = chat_create(messages=[{"role": "user", "content": "hi"}])
        self.assertEqual(resp.choices[0].message.content, "Hello there")

    def test_system_and_user_map_to_converse_fields_with_arn_as_model_id(self):
        self.runtime.converse.return_value = _converse_reply({"text": "ok"})
        chat_create(temperature=0, messages=[
            {"role": "system", "content": "be brief"},
            {"role": "user", "content": "question"},
        ])
        kwargs = self.runtime.converse.call_args.kwargs
        self.assertEqual(kwargs["modelId"], clients.BEDROCK_CHAT_MODEL_ARN)
        self.assertEqual(kwargs["system"], [{"text": "be brief"}])
        self.assertEqual(kwargs["messages"], [{"role": "user", "content": [{"text": "question"}]}])
        self.assertEqual(kwargs["inferenceConfig"], {"temperature": 0})

    def test_temperature_omitted_when_not_given(self):
        self.runtime.converse.return_value = _converse_reply({"text": "ok"})
        chat_create(messages=[{"role": "user", "content": "q"}])
        self.assertNotIn("inferenceConfig", self.runtime.converse.call_args.kwargs)

    def test_json_mode_adds_instruction_and_extracts_object(self):
        self.runtime.converse.return_value = _converse_reply(
            {"text": '```json\n{"scores": [{"index": 0, "relevance": 7}]}\n```'})
        resp = chat_create(temperature=0, response_format={"type": "json_object"},
                           messages=[{"role": "system", "content": "score it"},
                                     {"role": "user", "content": "q"}])
        system_text = self.runtime.converse.call_args.kwargs["system"][0]["text"]
        self.assertIn("score it", system_text)
        self.assertIn("exactly one valid JSON object", system_text)
        self.assertEqual(json.loads(resp.choices[0].message.content),
                         {"scores": [{"index": 0, "relevance": 7}]})

    def test_temperature_rejection_retries_once_without_it_and_remembers(self):
        bad = _client_error("ValidationException", "The model does not support temperature.")
        self.runtime.converse.side_effect = [bad, _converse_reply({"text": "first"}),
                                             _converse_reply({"text": "second"})]
        with self.assertLogs(clients.log, level="WARNING") as logs:
            first = chat_create(temperature=0, messages=[{"role": "user", "content": "a"}])
        self.assertEqual(first.choices[0].message.content, "first")
        self.assertEqual(len(logs.output), 1)
        self.assertIn("temperature", logs.output[0])
        self.assertFalse(clients._temperature_supported)

        # Second call: temperature is never sent, so there is no failed attempt first.
        self.runtime.converse.reset_mock()
        self.runtime.converse.side_effect = None
        self.runtime.converse.return_value = _converse_reply({"text": "second"})
        chat_create(temperature=0, messages=[{"role": "user", "content": "b"}])
        self.assertEqual(self.runtime.converse.call_count, 1)
        self.assertNotIn("inferenceConfig", self.runtime.converse.call_args.kwargs)

    def test_inference_config_rejection_is_treated_as_temperature(self):
        bad = _client_error("ValidationException", "inferenceConfig.temperature not allowed")
        self.runtime.converse.side_effect = [bad, _converse_reply({"text": "ok"})]
        resp = chat_create(temperature=0.5, messages=[{"role": "user", "content": "a"}])
        self.assertEqual(resp.choices[0].message.content, "ok")
        self.assertFalse(clients._temperature_supported)

    def test_unrelated_validation_error_is_not_retried(self):
        self.runtime.converse.side_effect = _client_error(
            "ValidationException", "messages must alternate roles")
        with self.assertRaises(BedrockError) as ctx:
            chat_create(temperature=0, messages=[{"role": "user", "content": "a"}])
        self.assertIn("ValidationException", str(ctx.exception))
        self.assertEqual(self.runtime.converse.call_count, 1)
        self.assertTrue(clients._temperature_supported)

    def test_reasoning_effort_sent_only_when_configured(self):
        self.runtime.converse.return_value = _converse_reply({"text": "ok"})
        with mock.patch.object(clients, "BEDROCK_REASONING_EFFORT", None):
            chat_create(messages=[{"role": "user", "content": "a"}])
        self.assertNotIn("additionalModelRequestFields", self.runtime.converse.call_args.kwargs)

        with mock.patch.object(clients, "BEDROCK_REASONING_EFFORT", "low"):
            chat_create(messages=[{"role": "user", "content": "a"}])
        self.assertEqual(self.runtime.converse.call_args.kwargs["additionalModelRequestFields"],
                         {"reasoning_effort": "low"})


class RetryPolicyTests(_AdapterTestCase):
    def test_throttling_is_retried_then_succeeds(self):
        self.runtime.converse.side_effect = [
            _client_error("ThrottlingException"),
            _client_error("ServiceUnavailableException"),
            _converse_reply({"text": "ok"}),
        ]
        resp = chat_create(messages=[{"role": "user", "content": "a"}])
        self.assertEqual(resp.choices[0].message.content, "ok")
        self.assertEqual(self.runtime.converse.call_count, 3)
        self.assertEqual(self.sleep.call_count, 2)

    def test_model_timeout_is_retried(self):
        self.runtime.converse.side_effect = [_client_error("ModelTimeoutException"),
                                             _converse_reply({"text": "ok"})]
        chat_create(messages=[{"role": "user", "content": "a"}])
        self.assertEqual(self.runtime.converse.call_count, 2)

    def test_transient_connection_error_is_retried(self):
        self.runtime.converse.side_effect = [
            EndpointConnectionError(endpoint_url="https://bedrock-runtime.invalid"),
            _converse_reply({"text": "ok"}),
        ]
        chat_create(messages=[{"role": "user", "content": "a"}])
        self.assertEqual(self.runtime.converse.call_count, 2)

    def test_retries_stop_at_five_attempts(self):
        self.runtime.converse.side_effect = _client_error("ThrottlingException")
        with self.assertRaises(BedrockError) as ctx:
            chat_create(messages=[{"role": "user", "content": "a"}])
        self.assertEqual(self.runtime.converse.call_count, 5)
        self.assertIn("ThrottlingException", str(ctx.exception))
        self.assertIn("5 attempts", str(ctx.exception))

    def test_backoff_grows_and_is_jittered(self):
        self.runtime.converse.side_effect = _client_error("ThrottlingException")
        with self.assertRaises(BedrockError):
            chat_create(messages=[{"role": "user", "content": "a"}])
        delays = [c.args[0] for c in self.sleep.call_args_list]
        self.assertEqual(len(delays), 4)
        # Nominal 1, 2, 4, 8 seconds; jitter keeps each within half to full of nominal.
        for delay, nominal in zip(delays, [1, 2, 4, 8]):
            self.assertGreaterEqual(delay, nominal * 0.5)
            self.assertLessEqual(delay, nominal)

    def test_access_denied_fails_immediately_with_type(self):
        self.runtime.converse.side_effect = _client_error("AccessDeniedException", "no access")
        with self.assertRaises(BedrockError) as ctx:
            chat_create(messages=[{"role": "user", "content": "a"}])
        self.assertEqual(self.runtime.converse.call_count, 1)
        self.assertIn("AccessDeniedException", str(ctx.exception))
        self.sleep.assert_not_called()

    def test_resource_not_found_fails_immediately_with_type(self):
        self.runtime.converse.side_effect = _client_error("ResourceNotFoundException")
        with self.assertRaises(BedrockError) as ctx:
            chat_create(messages=[{"role": "user", "content": "a"}])
        self.assertEqual(self.runtime.converse.call_count, 1)
        self.assertIn("ResourceNotFoundException", str(ctx.exception))

    def test_expired_token_fails_immediately_with_type(self):
        self.runtime.converse.side_effect = _client_error("ExpiredTokenException", "expired")
        with self.assertRaises(BedrockError) as ctx:
            chat_create(messages=[{"role": "user", "content": "a"}])
        self.assertEqual(self.runtime.converse.call_count, 1)
        self.assertIn("ExpiredTokenException", str(ctx.exception))

    def test_embedding_invoke_follows_the_same_rules(self):
        self.runtime.invoke_model.side_effect = _client_error(
            "AccessDeniedException", "no access", op="InvokeModel")
        with self.assertRaises(BedrockError) as ctx:
            cohere_embed(["x"], input_type="search_document")
        self.assertEqual(self.runtime.invoke_model.call_count, 1)
        self.assertIn("AccessDeniedException", str(ctx.exception))


class CohereEmbedTests(_AdapterTestCase):
    @staticmethod
    def _echo_vectors(body: str) -> dict:
        """Fake Cohere: vector n has 1536 dims with first element n, for text 'tN'."""
        texts = json.loads(body)["texts"]
        vectors = []
        for t in texts:
            n = int(t[1:])
            vectors.append([float(n)] + [0.0] * 1535)
        return {"id": "x", "response_type": "embeddings_floats", "embeddings": vectors}

    def _install_echo(self) -> None:
        def invoke(**kwargs):
            return _embed_body(self._echo_vectors(kwargs["body"]))
        self.runtime.invoke_model.side_effect = invoke

    def test_request_body_has_input_type_dimensions_and_float(self):
        self._install_echo()
        cohere_embed(["t1"], input_type="search_query")
        kwargs = self.runtime.invoke_model.call_args.kwargs
        self.assertEqual(kwargs["modelId"], clients.BEDROCK_EMBEDDING_MODEL_ARN)
        body = json.loads(kwargs["body"])
        self.assertEqual(body["input_type"], "search_query")
        self.assertEqual(body["output_dimension"], 1536)
        self.assertEqual(body["embedding_types"], ["float"])
        self.assertEqual(body["texts"], ["t1"])

    def test_search_document_input_type_is_sent(self):
        self._install_echo()
        cohere_embed(["t1"], input_type="search_document")
        body = json.loads(self.runtime.invoke_model.call_args.kwargs["body"])
        self.assertEqual(body["input_type"], "search_document")

    def test_plain_list_response_shape_is_parsed(self):
        self.runtime.invoke_model.return_value = _embed_body(
            {"embeddings": [[1.0, 2.0], [3.0, 4.0]], "response_type": "embeddings_floats"})
        self.assertEqual(cohere_embed(["t1", "t2"], input_type="search_document"),
                         [[1.0, 2.0], [3.0, 4.0]])

    def test_dict_keyed_by_type_response_shape_is_parsed(self):
        self.runtime.invoke_model.return_value = _embed_body(
            {"embeddings": {"float": [[1.0, 2.0]]}, "response_type": "embeddings_by_type"})
        self.assertEqual(cohere_embed(["t1"], input_type="search_document"), [[1.0, 2.0]])

    def test_dict_without_float_key_is_an_error(self):
        self.runtime.invoke_model.return_value = _embed_body(
            {"embeddings": {"int8": [[1, 2]]}})
        with self.assertRaises(BedrockError) as ctx:
            cohere_embed(["t1"], input_type="search_document")
        self.assertIn("EmbeddingParse", str(ctx.exception))

    def test_splits_at_96_texts_and_preserves_order(self):
        self._install_echo()
        texts = [f"t{n}" for n in range(200)]
        vectors = cohere_embed(texts, input_type="search_document")

        self.assertEqual(self.runtime.invoke_model.call_count, 3)
        batch_sizes = [len(json.loads(c.kwargs["body"])["texts"])
                       for c in self.runtime.invoke_model.call_args_list]
        self.assertEqual(batch_sizes, [96, 96, 8])
        self.assertEqual([v[0] for v in vectors], [float(n) for n in range(200)])

    def test_count_mismatch_is_an_error(self):
        self.runtime.invoke_model.return_value = _embed_body(
            {"embeddings": [[1.0]]})
        with self.assertRaises(BedrockError) as ctx:
            cohere_embed(["t1", "t2"], input_type="search_document")
        self.assertIn("EmbeddingCountMismatch", str(ctx.exception))


class EmbedderTests(_AdapterTestCase):
    def test_embed_texts_keeps_order_across_outer_batches(self):
        def invoke(**kwargs):
            return _embed_body(CohereEmbedTests._echo_vectors(kwargs["body"]))
        self.runtime.invoke_model.side_effect = invoke
        with mock.patch.object(embedder, "EMBED_BATCH_SIZE", 64):
            vectors = embedder.embed_texts([f"t{n}" for n in range(150)])
        self.assertEqual([v[0] for v in vectors], [float(n) for n in range(150)])
        self.assertTrue(all(len(v) == 1536 for v in vectors))

    def test_wrong_dimension_fails_closed(self):
        self.runtime.invoke_model.return_value = _embed_body({"embeddings": [[1.0, 2.0]]})
        with self.assertRaises(RuntimeError) as ctx:
            embedder.embed_texts(["t1"])
        self.assertIn("vector(1536)", str(ctx.exception))

    def test_embed_query_uses_search_query(self):
        def invoke(**kwargs):
            return _embed_body(CohereEmbedTests._echo_vectors(kwargs["body"]))
        self.runtime.invoke_model.side_effect = invoke
        with mock.patch.object(embedder, "cohere_embed", wraps=clients.cohere_embed) as spy:
            vec = embedder.embed_query("t7")
        self.assertEqual(spy.call_args.kwargs["input_type"], "search_query")
        self.assertEqual(vec[0], 7.0)


if __name__ == "__main__":
    unittest.main()
