"""Environment configuration (CLAUDE.md section 5).

Every value is read from the environment / backend/.env. No model name, URL, key,
bucket or prefix is hardcoded anywhere else in the codebase.
"""
import os
from pathlib import Path

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent
load_dotenv(BACKEND_DIR / ".env")


def _require(name: str, default: str | None = None) -> str:
    value = os.getenv(name, default)
    if value is None or not str(value).strip():
        raise RuntimeError(
            f"Missing required environment variable {name!r}. "
            f"Set it in {BACKEND_DIR / '.env'} (see CLAUDE.md section 5)."
        )
    return str(value).strip()


# --- AWS Bedrock (section 4.1) ----------------------------------------------
# Chat runs on a Luna application inference profile ARN; embeddings run on a Cohere
# Embed v4 ARN. Credentials are deliberately NOT read here: boto3 uses the default
# credential chain, which on AWS is the attached IAM role. No AWS key belongs in
# code or in .env.
AWS_REGION = _require("AWS_REGION")
BEDROCK_CHAT_MODEL_ARN = _require("BEDROCK_CHAT_MODEL_ARN")
BEDROCK_EMBEDDING_MODEL_ARN = _require("BEDROCK_EMBEDDING_MODEL_ARN")
# Optional. Unset means the model's own default reasoning effort is used.
BEDROCK_REASONING_EFFORT = os.getenv("BEDROCK_REASONING_EFFORT", "").strip() or None

# --- Supabase ---------------------------------------------------------------
SUPABASE_URL = _require("SUPABASE_URL")
SUPABASE_KEY = _require("SUPABASE_KEY")  # service role key
SUPABASE_KB_BUCKET = _require("SUPABASE_KB_BUCKET")
SUPABASE_KB_ROOT_PREFIX = _require("SUPABASE_KB_ROOT_PREFIX", "Organization Details")

# --- Knowledge Base admin login --------------------------------------------
# Gates the section 3.4 ingest controls. Read with os.getenv rather than _require
# on purpose: _require raises at import time, which would stop the whole API from
# starting just because this pair was missing. The endpoints that use these fail
# CLOSED when they are unset (see _check_kb_admin in main.py), so an unconfigured
# server refuses ingest instead of either crashing or running it unauthenticated.
KB_ADMIN_USERNAME = os.getenv("KB_ADMIN_USERNAME", "").strip()
KB_ADMIN_PASSWORD = os.getenv("KB_ADMIN_PASSWORD", "").strip()

# --- Hugging Face -----------------------------------------------------------
# Authenticates the cross-encoder weights fetch and removes the "You are sending
# unauthenticated requests to the HF Hub" rate-limit warning. huggingface_hub reads
# HF_TOKEN straight from the environment, and load_dotenv() above has already copied
# backend/.env into it, so setting it there is all that is required -- nothing has to
# thread the value through to the reranker.
#
# A BLANK value is worse than an absent one: the hub would attempt to authenticate
# with an empty token rather than fall back to anonymous access. So an empty entry is
# deleted from the environment here, leaving genuinely unauthenticated (but working)
# access rather than a guaranteed-failing authenticated one.
HF_TOKEN = os.getenv("HF_TOKEN", "").strip()
if not HF_TOKEN:
    os.environ.pop("HF_TOKEN", None)
else:
    os.environ["HF_TOKEN"] = HF_TOKEN

# --- Tunables ---------------------------------------------------------------
# documents.embedding is vector(1536); text-embedding-3-small emits 1536 dims.
EMBEDDING_DIM = 1536
EMBED_BATCH_SIZE = int(os.getenv("EMBED_BATCH_SIZE", "64"))
INSERT_BATCH_SIZE = int(os.getenv("INSERT_BATCH_SIZE", "100"))

# Retrieval / groundedness (sections 4.4, 4.7).
RETRIEVAL_MATCH_COUNT = int(os.getenv("RETRIEVAL_MATCH_COUNT", "8"))
RERANK_KEEP = int(os.getenv("RERANK_KEEP", "5"))

# Cross-department ("search all") path only: how many passages survive each
# department's own rerank before the departments compete against each other.
FANOUT_PER_DEPT_KEEP = int(os.getenv("FANOUT_PER_DEPT_KEEP", "2"))

# Broad "summarize all departments" requests keep this many chunks PER
# department (section 4.6), rather than a pooled global top-N.
BROAD_PER_DEPT_KEEP = int(os.getenv("BROAD_PER_DEPT_KEEP", "3"))

# A breadth request scoped to ONE department ("summarise this department") uses the
# same structural retrieval, but the whole budget goes to that department instead of
# being split fifteen ways, so it keeps more.
SINGLE_DEPT_BREADTH_KEEP = int(os.getenv("SINGLE_DEPT_BREADTH_KEEP", "8"))

# A drill-down ("tell me more about the second KPI") keeps more than a first-time
# question. The default 5 are the passages that produced the answer the user has
# already read, so expanding on that answer out of the same 5 leaves little to say
# that is both new and grounded.
DRILLDOWN_KEEP = int(os.getenv("DRILLDOWN_KEEP", "10"))

# ...and shows generation a wider set of them. The detail a follow-up is asking for
# lives in passages ADJACENT to the direct hit -- the function that uses a metric,
# the sibling records -- which score lower than the hit itself by construction. The
# relevance PRE-GATE is unaffected by this: it still runs at
# GROUNDEDNESS_MIN_RELEVANCE on the top score, so a drill-down into a subject the
# knowledge base does not cover still refuses. This only widens what generation may
# read, and every claim drawn from it is still claim-verified.
DRILLDOWN_MIN_RELEVANCE = float(os.getenv("DRILLDOWN_MIN_RELEVANCE", "1.0"))

# The reranker scores relevance 0-10. The groundedness gate thresholds on THAT,
# not on hybrid_search's RRF score -- an RRF score is a function of rank position
# only, so a rank-1 chunk scores ~0.0164-0.0328 whether or not it is relevant, and
# is therefore useless as a "did we actually find anything" signal. See
# groundedness/gate.py for the full reasoning.
GROUNDEDNESS_MIN_RELEVANCE = float(os.getenv("GROUNDEDNESS_MIN_RELEVANCE", "4.0"))

# Memory (sections 4.11, 4.12).
MEMORY_TURN_WINDOW = int(os.getenv("MEMORY_TURN_WINDOW", "6"))
MEMORY_MAX_LONG_TERM = int(os.getenv("MEMORY_MAX_LONG_TERM", "10"))

# Reranker backend: "llm" (the Bedrock chat model) or "cross_encoder" (local, no API round-trip).
RERANK_BACKEND = os.getenv("RERANK_BACKEND", "cross_encoder")
CROSS_ENCODER_MODEL = os.getenv("CROSS_ENCODER_MODEL", "cross-encoder/ms-marco-MiniLM-L-6-v2")

# Planner HD routing (section 4.6). Below this, ask instead of guessing.
HD_ROUTING_MIN_CONFIDENCE = float(os.getenv("HD_ROUTING_MIN_CONFIDENCE", "0.55"))
HD_ROUTING_DUAL_MARGIN = float(os.getenv("HD_ROUTING_DUAL_MARGIN", "0.15"))
