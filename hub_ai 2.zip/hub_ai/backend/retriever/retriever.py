"""Hybrid retrieval + rerank (CLAUDE.md section 4.4).

hybrid_search is called once per head department and merged in Python. It is never
called with a NULL filter -- that returns zero rows by design (fail-closed), and the
cross-department path is an explicit fan-out, not a filter bypass.

The reranker exists for two reasons. The obvious one is precision. The less obvious
one is that RRF scores carry no relevance signal at all: a chunk that ranks first in
both arms scores ~0.0328 whether it answers the question or is merely the closest of
a bad lot. The groundedness gate needs a number that means "this is actually
relevant", and the reranker's 0-10 score is that number.
"""
from __future__ import annotations

import json
import math
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any

from clients import chat_create, db_call, supabase
from config import (BROAD_PER_DEPT_KEEP, CROSS_ENCODER_MODEL, FANOUT_PER_DEPT_KEEP,
                    RERANK_BACKEND, RERANK_KEEP,
                    RETRIEVAL_MATCH_COUNT)
from ingestion.embedder import embed_query


@dataclass
class Hit:
    id: str
    content: str
    head_dept: str
    source_file: str
    rrf_score: float
    relevance: float | None = None
    # True when the passage is about the right subject but records no actual values
    # ("Information not available in the documentation"). Lets the gate say "the
    # documentation has this section but it is blank" instead of "not in the
    # knowledge base", which are very different things to tell a user.
    covers_topic: bool | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def source_name(self) -> str:
        return self.source_file.split("/")[-1] if self.source_file else "unknown"


def search_head_dept(query: str, head_dept: str, embedding: list[float] | None = None,
                     match_count: int | None = None) -> list[Hit]:
    """One hybrid_search RPC call, hard-scoped to a single head department."""
    if not head_dept:
        return []  # never pass NULL through to the RPC
    vec = embedding if embedding is not None else embed_query(query)
    # Wrapped: a dropped HTTP/2 stream on this RPC was the single most common
    # cause of a user-visible 500 (see clients.db_call).
    rows = db_call(lambda: supabase().rpc("hybrid_search", {
        "query_embedding": vec,
        "query_text": query,
        "filter_head_dept": head_dept,
        "match_count": match_count or RETRIEVAL_MATCH_COUNT,
    }).execute()).data or []
    return [Hit(id=r["id"], content=r["content"], head_dept=r["head_dept"],
                source_file=r.get("source_file") or "", rrf_score=float(r["score"]))
            for r in rows]


def search_by_dept(query: str, head_depts: list[str],
                   match_count: int | None = None) -> dict[str, list[Hit]]:
    """Fan out across the scoped departments, embedding the query only once.

    Results stay grouped by department on purpose. RRF scores are only comparable
    WITHIN a department -- they are a function of rank position, so every
    department's rank-1 passage scores an identical ~0.01734 (or ~0.03132 when it
    tops both arms). Pooling and sorting them cross-department produces massive ties
    broken by nothing but iteration order, which would silently privilege whichever
    departments come first in the list.
    """
    if not head_depts:
        return {}
    vec = embed_query(query)
    if len(head_depts) == 1:
        hd = head_depts[0]
        return {hd: search_head_dept(query, hd, embedding=vec, match_count=match_count)}

    # One RPC per department. Run concurrently -- issued serially, 15 departments
    # cost ~4.6s of pure round-trip, which was 22% of fan-out latency.
    out: dict[str, list[Hit]] = {}
    with ThreadPoolExecutor(max_workers=min(8, len(head_depts))) as pool:
        futures = {pool.submit(search_head_dept, query, hd, vec, match_count): hd
                   for hd in head_depts}
        for fut in as_completed(futures):
            hd = futures[fut]
            try:
                out[hd] = fut.result()
            except Exception:
                out[hd] = []
    return {hd: out.get(hd, []) for hd in head_depts}


def search(query: str, head_depts: list[str], match_count: int | None = None) -> list[Hit]:
    """Flat fan-out. Ordering is only meaningful for a single department."""
    grouped = search_by_dept(query, head_depts, match_count)
    hits = [h for group in grouped.values() for h in group]
    if len(grouped) == 1:
        hits.sort(key=lambda h: h.rrf_score, reverse=True)
    return hits


_RERANK_SYSTEM = """You score how well each numbered passage answers the user's question.

Return JSON only, one entry per passage:
{"scores": [{"index": <int>, "relevance": <0-10>, "covers_topic": true|false}, ...]}

relevance:
  0-2  unrelated, or only shares generic vocabulary with the question
  3-4  same topic area but does not contain the answer
  5-7  contains part of the answer
  8-10 directly and specifically answers the question

covers_topic is true when the passage is ABOUT the thing asked -- the right section
for the question -- regardless of whether it holds usable values.

Judge only what the passage actually states. A passage whose fields all read
"Information not available in the documentation" answers nothing, so score its
relevance low, but set covers_topic true if it is the right section: that combination
means the documentation has the section and left it blank."""


UNFILLED_MARKER = "information not available in the documentation"
# A blank section is topically perfect and informationally empty, so a cross-encoder
# ranks it ABOVE the departments that actually documented the thing: asked "what
# systems are used", CMO's empty Systems section beat every filled one and became the
# sole kept chunk. Scale such passages down so answerable content outranks them. They
# stay retrievable -- the gate still recognises a genuinely blank single-department
# section from the ones that survive.
BLANK_RELEVANCE_FACTOR = 0.35


def is_blank_content(content: str) -> bool:
    """True when a passage's fields are overwhelmingly 'Information not available'."""
    body = [l.strip() for l in content.splitlines()
            if l.strip() and not l.startswith(("Head department:", "Sub-department:",
                                               "Section:", "Function:", "KPI:"))]
    if not body:
        return False
    unfilled = sum(1 for l in body if UNFILLED_MARKER in l.lower())
    return unfilled >= max(1, int(len(body) * 0.6))


_CROSS_ENCODER = None
_CE_LOCK = threading.Lock()


def _cross_encoder():
    """Lazily loaded local cross-encoder. Thread-safe; loaded once per process."""
    global _CROSS_ENCODER
    if _CROSS_ENCODER is None:
        with _CE_LOCK:
            if _CROSS_ENCODER is None:
                from sentence_transformers import CrossEncoder
                _CROSS_ENCODER = CrossEncoder(CROSS_ENCODER_MODEL, max_length=512)
    return _CROSS_ENCODER


def warm_cross_encoder() -> None:
    """Load the cross-encoder now, so the first real request does not pay for it.

    The model was already cached for the life of the process -- it is NOT rebuilt per
    request -- but it was built lazily, on whichever request happened to arrive first.
    Measured on a cold start, that request spent 24.3s inside the rerank stage while
    every later one took 118-405ms. Nothing was wrong with the caching; the cost was
    simply parked on an unlucky user instead of on boot.

    Called from a background thread at startup (see main.py) rather than inline, so
    the server still accepts connections immediately. A request that arrives mid-load
    blocks on the same lock it always did, so this can only make the first request
    faster, never slower. Failures are swallowed: rerank() already falls back to the
    LLM backend when the model cannot be built.
    """
    try:
        _cross_encoder()
    except Exception:
        pass


def _rerank_cross_encoder(query: str, hits: list[Hit], keep: int) -> list[Hit]:
    """Local rerank -- no API round-trip (CLAUDE.md 8.2).

    ms-marco cross-encoders emit an unbounded logit; a sigmoid maps it onto the same
    0-10 scale the LLM reranker used, so GROUNDEDNESS_MIN_RELEVANCE keeps its meaning
    across backends. The mapping is monotonic, so ordering is untouched -- only the
    absolute threshold needed re-checking, which the eval harness does.
    """
    model = _cross_encoder()
    pairs = [(query, h.content[:2000]) for h in hits]
    scores = model.predict(pairs, show_progress_bar=False)
    for h, raw in zip(hits, scores):
        rel = 10.0 / (1.0 + math.exp(-float(raw)))
        if is_blank_content(h.content):
            rel *= BLANK_RELEVANCE_FACTOR
        h.relevance = round(rel, 2)
        h.covers_topic = None  # gate derives this deterministically instead
    ranked = sorted(hits, key=lambda h: (h.relevance, h.rrf_score), reverse=True)
    return ranked[:keep]


def rerank(query: str, hits: list[Hit], keep: int | None = None) -> list[Hit]:
    """Rerank pass. Attaches .relevance (0-10) and returns the top `keep`."""
    if not hits:
        return []
    keep = keep or RERANK_KEEP

    if RERANK_BACKEND == "cross_encoder":
        try:
            return _rerank_cross_encoder(query, hits, keep)
        except Exception:
            pass  # model unavailable -- fall through to the LLM path

    passages = "\n\n".join(
        f"[{i}] (department: {h.head_dept}, source: {h.source_name})\n{h.content[:1500]}"
        for i, h in enumerate(hits)
    )
    try:
        resp = chat_create(
            temperature=0,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": _RERANK_SYSTEM},
                {"role": "user", "content": f"Question: {query}\n\nPassages:\n{passages}"},
            ],
        )
        scores = json.loads(resp.choices[0].message.content or "{}").get("scores", [])
        by_index = {int(s["index"]): (float(s["relevance"]), bool(s.get("covers_topic")))
                    for s in scores if "index" in s and "relevance" in s}
    except Exception:
        # Reranker unavailable -- fall back to RRF order, but leave relevance None so
        # the groundedness gate can tell it was never actually scored.
        by_index = {}

    for i, h in enumerate(hits):
        scored_pair = by_index.get(i)
        h.relevance, h.covers_topic = scored_pair if scored_pair else (None, None)

    scored = [h for h in hits if h.relevance is not None]
    if not scored:
        return hits[:keep]
    scored.sort(key=lambda h: (h.relevance, h.rrf_score), reverse=True)
    kept = scored[:keep]

    # Always carry through one on-topic passage even if it scored too low to make the
    # cut, so the gate can distinguish "we have no such section" from "the section
    # exists but is blank".
    if not any(h.covers_topic for h in kept):
        topical = next((h for h in scored if h.covers_topic), None)
        if topical is not None:
            kept.append(topical)
    return kept


def rerank_fanout(query: str, grouped: dict[str, list[Hit]],
                  per_dept_keep: int | None = None,
                  final_keep: int | None = None) -> list[Hit]:
    """Two-stage rerank for the cross-department path (build-order step 8).

    Stage 1 ranks each department's passages against the query on its own; stage 2
    ranks the survivors against each other. One flat pass over the pooled set was
    both worse and dearer: 15 departments x match_count 8 is 120 passages (~17k
    tokens, ~54k once all 18 are populated), and single-shot LLM ranking degrades
    sharply at that length. Per-department first also guarantees every department is
    judged on its merits before competing, rather than being crowded out by whichever
    department happened to sort first.
    """
    per_dept_keep = per_dept_keep or FANOUT_PER_DEPT_KEEP
    final_keep = final_keep or RERANK_KEEP

    groups = {hd: hits for hd, hits in grouped.items() if hits}
    if not groups:
        return []
    if len(groups) == 1:
        return rerank(query, next(iter(groups.values())), keep=final_keep)

    # A cross-encoder scores each (query, passage) pair independently, so its scores
    # ARE comparable across departments and it does not degrade with list length --
    # both reasons the two-stage design existed. Score the whole pool in one batched
    # pass instead: measured at 8.4s for 15 sequential per-department passes versus a
    # single batch here.
    if RERANK_BACKEND == "cross_encoder":
        pooled = [h for hits in groups.values() for h in hits]
        try:
            return _rerank_cross_encoder(query, pooled, final_keep)
        except Exception:
            pass  # model unavailable -- fall through to the staged LLM path

    survivors: list[Hit] = []
    with ThreadPoolExecutor(max_workers=min(8, len(groups))) as pool:
        futures = {pool.submit(rerank, query, hits, per_dept_keep): hd
                   for hd, hits in groups.items()}
        for fut in as_completed(futures):
            try:
                survivors.extend(fut.result())
            except Exception:
                continue  # one department's rerank failing must not sink the query

    # Drop passages stage 1 already judged irrelevant, so stage 2 ranks a real
    # shortlist instead of re-litigating the whole pool.
    shortlist = [h for h in survivors if (h.relevance or 0) > 0] or survivors
    return rerank(query, shortlist, keep=final_keep)


# Section ladder for a structural summary, most-summary-like first. Section 4.6 asks
# for "a defined slice per department directly by section (e.g. identity, functions,
# KPIs)"; only the first two rungs were implemented, so a department summary was built
# from profile chunks alone -- 1 for FDE TCG, 3 for CMO, 4 for TAG. Everything that
# makes a department what it does (its functions, processes, KPIs, systems) was
# absent, so "summarize this department" answered from the blurb and nothing else.
# Order matters: the budget is filled from the top down, so the profile still leads.
_BREADTH_SECTIONS = (
    "profile_text", "department_identity", "organization_structure",
    "functions", "business_processes", "kpis", "services_offered", "systems",
)


def _representative_for(head_dept: str, per_dept: int) -> list[Hit]:
    """A department's own summary chunks, selected structurally rather than by search.

    Fills `per_dept` down the section ladder rather than from one section, so a
    department whose profile is a single chunk still gets a summary covering what it
    does. Selection stays structural -- by section, never by similarity -- because a
    breadth request names no topic for a similarity score to mean anything against.
    """
    sb = supabase()
    rows = (db_call(lambda: sb.table("documents")
                    .select("id,content,head_dept,source_file,metadata")
                    .eq("head_dept", head_dept)
                    .in_("metadata->>section", list(_BREADTH_SECTIONS))
                    .execute()).data or [])
    if not rows:
        return []

    # Round-robin down the ladder, not straight down it. A department with several
    # sub-department files has several profile chunks, so taking them in strict
    # section order spent the whole budget on profile and identity and never reached
    # functions or KPIs -- CMO filled 8 slots with 3 profiles, 3 identities and 2
    # org-structures. Breadth wants one of each thing before a second of anything.
    buckets: dict[str, list[dict]] = {s: [] for s in _BREADTH_SECTIONS}
    for r in rows:
        section = (r.get("metadata") or {}).get("section")
        if section in buckets:
            buckets[section].append(r)

    picked, depth = [], 0
    while len(picked) < per_dept and depth < max((len(v) for v in buckets.values()),
                                                 default=0):
        for section in _BREADTH_SECTIONS:
            if len(picked) >= per_dept:
                break
            if depth < len(buckets[section]):
                picked.append(buckets[section][depth])
        depth += 1

    return [Hit(id=r["id"], content=r["content"], head_dept=r["head_dept"],
                source_file=r.get("source_file") or "", rrf_score=0.0,
                relevance=None, metadata=r.get("metadata") or {})
            for r in picked]


def retrieve_broad(query: str, head_depts: list[str], sw=None,
                   per_dept: int | None = None) -> tuple[list[Hit], list[str]]:
    """Representative coverage: every in-scope department, not a pooled top-N.

    Two things make this different from normal retrieval, both deliberate.

    First, the selection is STRUCTURAL, not semantic. "Summarize all departments" is
    a poor search query -- it names no subject, so the cross-encoder scores every
    passage near zero and the groundedness gate rejects the lot. Measured: this
    returned 0-1 departments out of 15. Each department's own profile_text chunk is
    what a summary of that department should be built from, and it is identified by
    section, not by similarity to the request.

    Second, the result is not truncated to a global top-N. Pooling and keeping the
    best N silently returns whichever 3-4 departments scored highest and starves the
    rest, which is wrong for a request that explicitly asked about all of them.
    """
    keep = per_dept or BROAD_PER_DEPT_KEEP
    if not head_depts:
        return [], []

    def _go() -> tuple[list[Hit], list[str]]:
        by_dept: dict[str, list[Hit]] = {}
        failed: list[str] = []
        with ThreadPoolExecutor(max_workers=min(8, len(head_depts))) as pool:
            futures = {pool.submit(_representative_for, hd, keep): hd
                       for hd in head_depts}
            for fut in as_completed(futures):
                hd = futures[fut]
                try:
                    by_dept[hd] = fut.result()
                except Exception:
                    failed.append(hd)

        # Retry serially. Swallowing these silently produced partial coverage that
        # looked like a working answer: one run returned exactly the first 8
        # departments alphabetically because 7 concurrent queries had failed and been
        # dropped without a trace. Coverage is the whole point of this path, so a
        # department that cannot be fetched must not simply vanish.
        for hd in failed:
            try:
                by_dept[hd] = _representative_for(hd, keep)
            except Exception:
                by_dept[hd] = []

        missing = [hd for hd in head_depts if not by_dept.get(hd)]
        out = [h for hd in head_depts for h in by_dept.get(hd, [])]
        out.sort(key=lambda h: h.head_dept)   # stable, department-ordered
        return out, missing

    if sw is None:
        return _go()
    with sw.stage("retrieval.broad"):
        return _go()


def retrieve(query: str, head_depts: list[str], sw=None,
             keep: int | None = None) -> list[Hit]:
    """Full retrieval path: hybrid search -> rerank. `sw` is an optional Stopwatch.

    `keep` widens the kept set beyond RERANK_KEEP. A drill-down needs it: the top 5
    passages are the ones that produced the answer the user has already read, so
    expanding on that answer from the same 5 has little left to draw on.
    """
    if not head_depts:
        return []

    def _rank(grouped):
        return (rerank(query, grouped.get(head_depts[0], []), keep=keep)
                if len(head_depts) == 1 else rerank_fanout(query, grouped))

    if sw is None:
        return _rank(search_by_dept(query, head_depts))

    # embed_query + one hybrid_search RPC per department
    with sw.stage("retrieval.search"):
        grouped = search_by_dept(query, head_depts)
    stage = "rerank.single" if len(head_depts) == 1 else "rerank.fanout"
    with sw.stage(stage):
        return _rank(grouped)
