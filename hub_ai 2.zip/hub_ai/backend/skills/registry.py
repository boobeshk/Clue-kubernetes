"""Skill registry (CLAUDE.md section 4.9).

A skill is instructions + optional script. The planner matches a query against skill
descriptions the same way it matches HD summaries, and routes to the skill lane when
one fits better than plain retrieval.

Script execution is deliberately NOT wired up. Uploaded scripts are stored and their
path recorded, but running arbitrary user-supplied code from an HTTP endpoint needs a
sandbox (subprocess isolation, resource limits, no network, no credentials in env)
that is out of scope here. execute() runs the instructions_md against grounded
context; if a skill has a script_path, the response says so rather than executing it.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from clients import chat_create, supabase
from config import BACKEND_DIR
from retriever.retriever import Hit

SCRIPT_DIR = BACKEND_DIR / "skills" / "scripts"


def list_skills() -> list[dict[str, Any]]:
    return supabase().table("skills").select("*").execute().data or []


def get_skill(skill_id: str) -> dict[str, Any] | None:
    rows = supabase().table("skills").select("*").eq("id", skill_id).execute().data or []
    return rows[0] if rows else None


def create_skill(name: str, description: str, instructions_md: str,
                 trigger_keywords: list[str] | None = None,
                 head_dept_scope: str | None = None,
                 script: str | None = None, owner: str | None = None) -> dict[str, Any]:
    script_path = None
    if script:
        SCRIPT_DIR.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r"[^a-zA-Z0-9_.-]+", "_", name).strip("_") or "skill"
        target = SCRIPT_DIR / f"{safe}.py"
        target.write_text(script, encoding="utf-8")
        script_path = str(target.relative_to(BACKEND_DIR))

    row = {
        "owner": owner,
        "name": name,
        "description": description,
        "trigger_keywords": trigger_keywords or [],
        "head_dept_scope": head_dept_scope,
        "instructions_md": instructions_md,
        "script_path": script_path,
    }
    return (supabase().table("skills").insert(row).execute().data or [row])[0]


_SKILL_SYSTEM = """You are executing a registered skill.

Follow the skill's instructions exactly. Ground every factual statement in the
supplied context passages -- they are your only source of company information. If the
instructions call for a fact the passages do not contain, say so rather than
inventing it. Cite source files as [source: filename]."""


def execute(skill: dict[str, Any], query: str, hits: list[Hit]) -> str:
    context = "\n\n".join(
        f"[{i+1}] (department: {h.head_dept}, source: {h.source_name})\n{h.content}"
        for i, h in enumerate(hits)) or "(no matching knowledge-base content)"

    resp = chat_create(
        temperature=0,
        messages=[
            {"role": "system", "content": _SKILL_SYSTEM},
            {"role": "user", "content":
                f"Skill: {skill['name']}\n{skill['description']}\n\n"
                f"Instructions:\n{skill['instructions_md']}\n\n"
                f"User request: {query}\n\nContext passages:\n{context}"},
        ],
    )
    out = (resp.choices[0].message.content or "").strip()
    if skill.get("script_path"):
        out += (f"\n\n_This skill has an attached script ({skill['script_path']}). "
                f"Script execution is not enabled -- only the instructions were applied._")
    return out
