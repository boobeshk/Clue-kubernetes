"""Planner: HD scope resolution + task-lane classification (CLAUDE.md section 4.6).

Scope resolution, in priority order:
  1. explicit head_dept (from @mention or sidebar) -> hard scope, no exceptions
  2. explicit "search all departments" intent      -> fan out across all populated HDs
  3. otherwise                                     -> match the query against the 18
     hd_index.summary_md entries; high confidence auto-scopes (and the answer says
     which HD it inferred), low confidence asks rather than guesses.

Every decision is written to routing_log so the confidence threshold can be tuned
against real traffic later (section 4.6 step 4).
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field

import responder
from clients import chat_create, db_call, supabase
from config import HD_ROUTING_DUAL_MARGIN, HD_ROUTING_MIN_CONFIDENCE
from ingestion.hd_map import SLUG_TO_DISPLAY, display_name

LANES = ("retrieval", "docgen", "skill", "chitchat")

# Must refer to DEPARTMENTS, not merely contain "all". An earlier version matched a
# bare "across all", so "What does the CMO do across all its teams?" fanned out to
# every department instead of staying scoped to CMO.
_ALL_PATTERNS = re.compile(
    r"(?:\b(?:across\s+)?(?:all|every)\s+(?:the\s+)?(?:head\s+)?departments?\b)"
    r"|(?:\bacross\s+everything\b)"
    r"|(?:\bsearch\s+all\b)"
    r"|(?:\b(?:company|org|organi[sz]ation)[-\s]wide\b)"
    r"|(?:\beverywhere\b)", re.I)


# --- broad / all-department summarisation (section 4.6) --------------------
# Distinct from a cross-department QUESTION. "what are the escalation contacts
# across departments" wants the globally best chunks, pooled. "summarize all
# departments" wants representative coverage of EVERY department -- pooling and
# keeping a global top-N there silently returns 3-4 departments out of 15.
# Built from _BREADTH_WORDS below so the two can never drift apart. Hyphens and
# runs of whitespace are interchangeable, so "high-level" and "high level" both hit.
def _breadth_pattern() -> "re.Pattern[str]":
    alts = sorted(_BREADTH_WORDS | {"all of it"}, key=len, reverse=True)
    body = "|".join(re.escape(w).replace(r"\ ", r"[-\s]+") for w in alts)
    return re.compile(r"(?<![a-z])(?:" + body + r")(?![a-z])", re.I)

_COMPANY_WIDE = re.compile(
    r"\b(across|for|of|about)\s+the\s+(whole\s+|entire\s+)?"
    r"(company|organi[sz]ation|org|business)\b", re.I)


def _names_a_department(query: str) -> bool:
    """True when the query names a specific department, by display name or slug."""
    q = (query or "").lower()
    for slug, name in SLUG_TO_DISPLAY.items():
        if slug.replace("_", " ") in q or name.lower() in q:
            return True
    return False


# --- breadth: "summarise the whole of X" vs "what is X's escalation path" -----
# These need DIFFERENT retrieval, and the difference has nothing to do with scope.
# A breadth request names no topic to score against, so similarity search rates
# every passage near zero and the relevance gate rejects the lot -- which is why
# "summarize this department" scoped to CMO answered "I couldn't find any
# information related to the CMO". Section 4.6 already established the remedy for
# the all-department shape (pull a defined slice structurally, by section, instead
# of by similarity); the same reasoning applies to ONE department, so the test for
# breadth is separated here from the test for scope.
_BREADTH_WORDS = {
    "summary", "summaries", "summarise", "summarize", "summarised", "summarized",
    "summarising", "summarizing", "overview", "overviews", "recap", "rundown",
    "run down", "snapshot", "briefing", "one pager", "onepager", "gist", "tldr",
    "big picture", "full picture", "whole picture", "complete picture",
    "high level", "birds eye", "at a glance", "everything", "all about", "profile",
    # "brief me on this department" was missed because only "briefing" was listed,
    # so it fell through to similarity search and answered "there's nothing in the
    # knowledge base related to Support Services". Same shape, different word --
    # which is the point of keeping this a vocabulary rather than a set of phrases.
    "brief", "brief me", "sum up", "in a nutshell", "primer", "intro",
    "introduction", "tell me about", "walk me through", "the basics",
}

# Words that carry no subject of their own: request scaffolding, articles, and the
# word "department" itself. What survives BOTH lists is the real topic, if there is
# one. This is a residue test, not a phrase list -- any wording whose only subject
# is the department passes it, and any wording naming something more specific fails.
_SUBJECTLESS = {
    "give", "gives", "given", "get", "got", "me", "my", "mine", "us", "our", "ours",
    "i", "id", "im", "we", "you", "your", "yours", "a", "an", "the", "of", "for",
    "about", "on", "in", "into", "to", "with", "from", "at", "as", "by",
    "is", "are", "was", "were", "be", "been", "being", "do", "does", "did", "doing",
    "what", "whats", "which", "who", "whos", "how", "s", "t",
    "this", "that", "these", "those", "it", "its", "here", "there", "them",
    "please", "pls", "plz", "kindly", "can", "could", "would", "will", "shall",
    "tell", "show", "provide", "explain", "describe", "list", "write", "make",
    "want", "need", "like", "know", "see", "look", "read", "have", "has",
    "department", "departments", "dept", "depts", "team", "and", "or", "some",
    "more", "just", "quick", "quickly", "short", "shortly", "briefly", "brief",
    "bit", "whole", "entire", "full", "complete", "overall", "general", "generally",
    "cover", "covers", "covered", "covering", "work", "works",
    "up", "out", "over", "hi", "hey", "hello", "thanks", "thank",
    # scope words: these say WHERE to look, never WHAT about
    "all", "every", "each", "any", "across", "company", "companywide", "wide",
    "org", "organisation", "organization", "business", "everywhere", "everything",
    # question verbs: "who OWNS compliance" is a question about compliance, so
    # leaving "owns" in the residue made the subject look like two words and
    # suppressed a check that should have fired
    "own", "owns", "owned", "handle", "handles", "handled", "lead", "leads", "led",
    "manage", "manages", "managed", "run", "runs", "involve", "involves",
    "measure", "measured", "measures", "happen", "happens", "use", "uses", "used",
    "define", "defined", "mean", "means",
}


_BREADTH = _breadth_pattern()


def _fold(text: str) -> str:
    """Lowercase, punctuation-free, hyphens opened up. Used only for the residue
    tests below, which need "P-Cube" and "p cube" to compare equal -- unlike
    _normalize_entity, which keeps hyphens because the entity index needs them."""
    t = (text or "").replace("&", " and ")
    # Apostrophes CLOSE UP rather than split: "you're" is one word, and splitting it
    # into "you" + "re" left an orphan fragment that neither vocabulary recognised,
    # so "morning! hope you're well" was not seen as a pure pleasantry and got a
    # request for clarification instead of a reply.
    t = re.sub(r"['’]", "", t)
    t = re.sub(r"[^A-Za-z0-9\s]", " ", t)
    return re.sub(r"\s+", " ", t).strip().lower()


def _strip_department_names(folded: str) -> str:
    """Remove any department this query actually names -- by display name, slug, or
    parenthesised abbreviation. Only departments PRESENT in the text are removed:
    stripping every department word globally would delete ordinary nouns like
    "delivery" or "people" from questions using them as a genuine subject."""
    out = folded
    for slug, name in SLUG_TO_DISPLAY.items():
        forms = [_fold(name), _fold(slug.replace("_", " "))]
        forms += [_fold(a) for a in re.findall(r"\((.*?)\)", name)]
        for form in sorted({f for f in forms if len(f) >= 2}, key=len, reverse=True):
            out = re.sub(r"\b" + re.escape(form) + r"\b", " ", out)
    return re.sub(r"\s+", " ", out).strip()


def _residual_subject(query: str) -> list[str]:
    """Whatever the request is about once scaffolding, breadth wording and the
    department's own name are removed. Empty means the department IS the subject."""
    folded = _strip_department_names(_fold(query))
    for phrase in sorted((w for w in _BREADTH_WORDS if " " in w), key=len, reverse=True):
        folded = folded.replace(phrase, " ")
    return [w for w in folded.split()
            if len(w) > 1 and w not in _BREADTH_WORDS and w not in _SUBJECTLESS]


def is_breadth_request(query: str) -> bool:
    """True when the request asks for the whole of something rather than one fact.

    Requires breadth wording AND no leftover subject, so "give me an overview of the
    escalation process in P-Cube" stays a normal search for the escalation process --
    only "give me an overview of P-Cube" is treated as breadth.
    """
    q = (query or "").strip()
    if not q or not _BREADTH.search(q):
        return False
    return not _residual_subject(q)


# --- pure social message (section 4.6 chitchat lane) -------------------------
# The lane classifier alone was too loose: "can you tell me more?", "tell me about
# it" and "can you help me with something?" were each classified chitchat and given
# a breezy assistant reply, when each is a request with no subject that should have
# been asked to clarify. This gate can only ever REMOVE the chitchat label, never
# apply it -- section 4.6 is explicit that a wrongly-broad chitchat call is a
# hallucination surface while a wrongly-narrow one costs one wasted lookup.
#
# This gate judges SHAPE, not vocabulary. An earlier version compared every word in
# the message against an allowlist of pleasantry words and required all of them to
# match. That inverted the failure: any greeting containing one unlisted word was
# demoted to retrieval and answered with a department clarification. "hello, im
# sujeeth" failed on the person's name, "howdy" failed on the greeting itself, and
# "hi my name is dana" failed on both -- names and unlisted greetings are the normal
# case, not edge cases, and no word list can enumerate them. Growing the list is the
# same hardcoding in a longer form, so the list is gone.
_SOCIAL_SYSTEM = """Decide whether a message contains any informational request.

A message is PURELY SOCIAL when it asks for nothing at all: a greeting, an
introduction ("hi, I'm Dana"), a thank-you, a farewell, a "how are you", or small
talk about the day or the week. Someone giving their name, or asking how you are,
has still asked you to look nothing up -- that is purely social.

A message is NOT purely social the moment it requests anything, however vague and
even if it names no subject. "Can you tell me more?", "tell me about it", "what can
you help with?" and "can you help me with something?" all ask for something, so
none of them are purely social.

Judge the shape of the message, not the specific words in it. An unfamiliar
greeting, a name you do not recognise, a typo or an unusual phrasing does not stop
a message from being purely social.

Return JSON only: {"purely_social": true|false}"""


def is_pure_social(query: str) -> bool:
    """True only when the message asks for nothing at all.

    Fails closed: any error returns False, sending the message to retrieval.
    Section 4.6 -- a wrongly-narrow chitchat call costs one wasted lookup, a
    wrongly-broad one is a hallucination surface.
    """
    q = (query or "").strip()
    if not q:
        return False
    try:
        resp = chat_create(
            temperature=0,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": _SOCIAL_SYSTEM},
                      {"role": "user", "content": q}],
        )
        data = json.loads(resp.choices[0].message.content or "{}")
        return data.get("purely_social") is True
    except Exception:
        return False


def is_broad_summary(query: str) -> bool:
    """True for breadth ACROSS every department.

    is_breadth_request covers breadth within one department; this adds the all-scope
    signal and the absence of a named department, so "tell me everything about CMO"
    stays inside CMO instead of fanning out to all 15.
    """
    q = (query or "").strip()
    if not q or not _BREADTH.search(q):
        return False
    if _names_a_department(q):
        return False
    return bool(_ALL_PATTERNS.search(q) or _COMPANY_WIDE.search(q)
                or re.search(r"\beverything\b", q, re.I))


# --- request shape: breadth, scope and drill-down, judged as intent ----------
#
# Everything in this section used to be decided by vocabularies: a set of breadth
# words, a set of subjectless words, a regex of referring expressions. Each was
# widened at least twice, and every widening was one reported phrasing turned into
# a literal -- "brief" was added the day "brief me on this department" failed. That
# cannot converge. The ways of asking for an overview are not an enumerable set, so
# the next unlisted word is always the next bug report, which is exactly the
# recurrence this section exists to end.
#
# Measured on the vocabulary version, 7 of 12 ordinary breadth phrasings failed --
# "what kind of stuff does this department handle" and "i want to understand this
# department properly" among them -- and they failed in two different ways: some
# contained no listed breadth word, while "summarize the FDE department and make it
# a document" contained one but was rejected because "document" survived the
# subjectless list and looked like a topic. Both arms of an AND had to be right
# about a word list for the request to be understood at all.
#
# Intent is judged here instead. The vocabulary tests above are kept, but only as
# the failure path: if the call errors, narrow-but-precise beats nothing.
@dataclass
class Intent:
    """What the message is trying to achieve, independent of how it is worded."""
    breadth: bool = False           # wants the whole of something, not one fact
    all_departments: bool = False   # spans the company, not one department
    drill_down: bool = False        # wants MORE about something already discussed
    focus: str | None = None        # the specific item to go deeper on
    source: str = "judged"          # "judged" | "fallback"


_SHAPE_SYSTEM = """You are reading one message from a conversation with a
knowledge-base assistant and describing its SHAPE, so the system can retrieve the
right way. You are not answering it.

Judge what the message is trying to achieve, the way a person would. Wording varies
enormously -- polite or blunt, fluent or broken, full sentences or fragments, with
typos, missing articles and non-native phrasing. Never depend on particular words
being present. "Give me an overview of Finance", "what kind of stuff does Finance
handle", "explain about the department details understandable" and "what detail you
have based on the department" are all the same request, and must be judged the same.

Report four things.

breadth -- does the message want the WHOLE of a department, or one thing from
  inside it? Work through these in order and stop at the first that applies.

  1. Does the message name, or ask about, any specific thing inside a department --
     anything with an identity of its own? A process, report, role, metric, team,
     system, policy or meeting counts, and so does a TERM, an abbreviation, a
     document or a tool. The list is illustrative, not exhaustive: if there is
     something particular the answer would be about, that is enough.
     If so, breadth is FALSE, no matter how broadly the request is worded. "Give me
     an overview of the escalation process", "summarise the hiring process", "tell
     me about the KPIs" and "what are the escalation contacts" each name a specific
     thing, so each is an ordinary question about that thing.
     Asking what something IS, what it STANDS FOR, or how two named things DIFFER is
     always about those things: "what is the difference between an OQL and an SQL"
     and "what does FDX mean" are questions about OQL, SQL and FDX, never breadth.
  2. Does the message ask for ONE property of the department -- who leads it, how
     many people are in it, where it sits, when it meets, what it is called? If so,
     breadth is FALSE. "Who leads this department" wants one fact, not the whole
     picture, even though the department is the only thing it names.
  3. Otherwise, if the only thing named is the department, the team or the company
     -- or nothing is named at all -- breadth is TRUE. "What does this department
     do", "details about department", "what kind of stuff do they handle", "tell me
     what this team actually does day to day" and "i'm new, what should i know"
     name no inner subject and ask for no single property, so the subject is the
     department itself.

  Vague quantity words ("stuff", "things", "detail", "info") are not subjects, and
  neither is a manner phrase like "day to day" or "in simple terms".
  An instruction about FORMAT is not a subject either. "Summarise the FDE
  department and make it a document" is still breadth: "make it a document" says
  how to deliver the answer, not what it is about.

all_departments -- true when answering would require looking at more than one
  department: an explicit all-department or company-wide request, or a question
  asking which departments do something. False when one department is named or
  clearly implied by the conversation.

drill_down -- BOTH of the following must be true. If either fails, it is false.

  (a) The message asks for MORE than it was already given. Either it explicitly
      requests further depth -- "tell me more", "explain that further", "go
      deeper", "expand on that", "elaborate", "what else", "anything more on X" --
      or it is not a complete question at all on its own and only makes sense as a
      continuation ("what about the first one", "and the second?").
      A message that stands alone as an ordinary question FAILS this, however
      closely it relates to what was just discussed. Being about the same
      department is not continuation. Check it by reading the message with the
      conversation removed: if it is still a perfectly good question that someone
      could ask cold, (a) fails.
        "What systems does TAG use"      -> a normal question -> (a) fails -> false
        "How do i raise a hiring request"-> a normal question -> (a) fails -> false
        "Who leads Labs"                 -> a normal question -> (a) fails -> false
        "Tell me more about the OQL report" -> asks for more  -> (a) holds
        "What about the first one"       -> incomplete alone  -> (a) holds

  (b) The thing it asks about was actually covered in the previous answer.

  Requires an earlier turn; with none, false. Also false for a request only to
  reformat or re-deliver what was already said ("make that a PDF"), and false for
  social messages.
  When unsure, answer false: a new question wrongly treated as a follow-up gets
  answered against the wrong subject, while a follow-up wrongly treated as new is
  merely answered from scratch.

focus -- when drill_down is true, the SPECIFIC thing the user wants more about,
  written as a plain noun phrase that could be looked up on its own. Resolve
  positional and pronoun references against the previous assistant answer: if that
  answer listed five teams and the user says "the first team", focus is that team's
  actual name. If the user names the item outright, use their words. Prefer the
  concrete name over a description. When the follow-up is entirely open ("tell me
  more", "elaborate"), focus is the main subject of the previous answer. null when
  drill_down is false, or when the item genuinely cannot be identified.

Return JSON only:
{"breadth": bool, "all_departments": bool, "drill_down": bool, "focus": string|null}"""


def _unscoped_everything(query: str) -> bool:
    """"Everything" with no department named -- i.e. the whole company.

    "Summarise everything" means the company; "tell me everything about CMO" means
    CMO. The difference is entirely whether a department is named, so that is the
    whole test.
    """
    return bool(re.search(r"\beverything\b", query or "", re.I)) \
        and not _names_a_department(query)


def _mentioned_in(focus: str, convo_ctx: str) -> bool:
    """Does `focus` name something the conversation has actually talked about?

    Compares distinctive content words, not the whole phrase: the model writes the
    focus in its own words ("systems used by TAG" for a question about systems), so
    a substring test would reject valid focuses. The department's own name is
    stripped first -- it appears in nearly every turn, so leaving it in would make
    any focus mentioning the department look present regardless of its real subject.
    """
    stripped = _strip_department_names(_fold(focus))
    words = {w for w in stripped.split()
             if len(w) > 2 and w not in _SUBJECTLESS and w not in _BREADTH_WORDS}
    if not words:
        return True  # nothing distinctive left to check -- do not veto on no evidence
    haystack = _fold(convo_ctx)
    return any(re.search(r"\b" + re.escape(w) + r"\b", haystack) for w in words)


def understand(query: str, convo_ctx: str = "") -> Intent:
    """Judge the shape of a request in one call.

    Degrades to the vocabulary tests on any error, so a failed call costs recall
    rather than changing behaviour.
    """
    q = (query or "").strip()
    if not q:
        return Intent()
    try:
        resp = chat_create(
            temperature=0,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": _SHAPE_SYSTEM},
                {"role": "user", "content": (
                    (f"Conversation so far:\n{convo_ctx}\n\n" if convo_ctx.strip()
                     else "This is the first message; there is no earlier turn.\n\n")
                    + f"Latest message: {q}")},
            ],
        )
        data = json.loads(resp.choices[0].message.content or "{}")
    except Exception:
        return Intent(breadth=is_breadth_request(q),
                      all_departments=is_broad_summary(q), source="fallback")

    # Drill-down is meaningless without something to drill into, whatever the
    # model says -- and a focus without a drill-down would silently replace the
    # user's actual question with an item from an earlier turn.
    drill = bool(data.get("drill_down")) and bool(convo_ctx.strip())
    focus = (data.get("focus") or "").strip() or None
    # You cannot go deeper into something that was never said. This is the one part
    # of a drill-down that is a fact about the transcript rather than a reading of
    # the request, so it is checked here rather than asked of the model: a focus
    # naming a subject absent from the conversation means a NEW question was read as
    # a follow-up ("what systems does TAG use", asked after an answer about TAG's
    # KPIs, came back as a drill-down on "systems used by TAG"). Downgrading it to
    # an ordinary question is the safe direction -- the question still gets asked,
    # just without being told to avoid repeating an answer it never saw.
    if drill and focus and not _mentioned_in(focus, convo_ctx):
        drill, focus = False, None
    return Intent(
        breadth=bool(data.get("breadth")),
        # Explicit all-department and company-wide phrasings are precise where they
        # fire, so they stay as a floor: the judgement may add recall, never withdraw
        # a certainty. Both rungs below were learned by losing them --
        # _COMPANY_WIDE's absence stopped "a full overview of the company" fanning
        # out, and _unscoped_everything's stopped "summarise everything", which the
        # model reads as scopeless because it names no department. In this product an
        # unscoped "everything" IS the company; with a department named it is that
        # department, which is why the test excludes those.
        all_departments=bool(data.get("all_departments"))
        or bool(_ALL_PATTERNS.search(q)) or bool(_COMPANY_WIDE.search(q))
        or _unscoped_everything(q),
        drill_down=drill,
        focus=focus if drill else None,
    )


@dataclass
class Plan:
    head_depts: list[str] = field(default_factory=list)
    confidence: float = 0.0
    lane: str = "retrieval"
    inferred: bool = False          # scope was inferred, not given
    needs_clarification: bool = False
    clarification: str | None = None
    searched_all: bool = False
    skill_id: str | None = None
    broad_coverage: bool = False
    reasoning: str = ""

    @property
    def scope_label(self) -> str:
        if self.searched_all:
            return "any department"
        if not self.head_depts:
            return "the knowledge base"
        return ", ".join(display_name(h) for h in self.head_depts)


def populated_head_depts() -> list[str]:
    rows = supabase().table("hd_index").select("head_dept").execute().data or []
    return [r["head_dept"] for r in rows]


def _summaries() -> list[dict]:
    return db_call(lambda: supabase().table("hd_index")
                   .select("head_dept,summary_md").execute()).data or []


_ROUTE_SYSTEM = """You route a question to the head department(s) whose knowledge base
can answer it, using only the department summaries provided.

Return JSON only:
{"departments": [{"slug": "<slug>", "confidence": <0.0-1.0>}], "reasoning": "<one line>"}

Step 1 - look for a named entity. Scan the question for any team, sub-department,
function, service, system, role or abbreviation that a summary lists under "Teams and
sub-departments", "Functions" or "Key terms and abbreviations".

If you find one, that department is the answer. Score it 0.7 or higher and stop
deliberating. This holds no matter how the question is phrased:
  "What services does IT Support provide?"          -> the dept owning IT Support
  "Who is the Director of Performance Review Mgmt?" -> the dept owning that function
  "How does the goal-setting process work?"         -> the dept owning Goal Setting
  "Who leads Pitch Lab?" / "What does Pitch Lab do?" -> both the dept owning Pitch Lab
A generic question SHAPE -- who / what / how / which services / list -- is not a
reason to hesitate. Only the presence or absence of a named entity matters. Do not
lower confidence because a question sounds routine.

Step 2 - only if NO entity from any summary appears anywhere in the question, treat it
as unscoped. "What are the KPIs?", "How do I escalate something?", "Who is the
department head?" name nothing, so they belong to no single department: score below
0.5 so the user is asked which one they mean.

Tie-break: if two departments both mention a term, prefer the one listing it as its
own team, function or service over one that merely references it in passing.

Shared terms: the question may be accompanied by a list of terms that several
departments all use. Those are NOT identifying entities -- finding one is not
step 1. If a shared term is the only thing the question names, step 2 applies and
you must score below 0.5, because no single department owns it. "Who owns
compliance?" names a term six departments list; naming one of them as the owner
asserts something the summaries do not support.

List at most 2 departments, best first. Return an empty list only when step 2 applies
and nothing matches at all."""


_LANE_SYSTEM = """Classify the user's request into exactly one lane.

  retrieval  a question to be answered from the knowledge base
  docgen     asks for a downloadable file artifact to be produced from knowledge-base
             content
  skill      matches one of the registered skills listed below better than it
             matches plain retrieval
  chitchat   a pure social pleasantry with NO informational request whatsoever --
             "hi", "thanks", "good morning", "how are you", "bye"

Precedence, in order:
1. chitchat applies ONLY when the message asks for nothing at all. If the message
   contains any question or request, however small, it is NOT chitchat -- classify
   it by the rules below and let the informational part go through retrieval.
   "Hi, what's the FDX figure" and "thanks - now what's the escalation path" are
   retrieval, not chitchat. When in doubt, do NOT choose chitchat: a missed
   chitchat costs one unnecessary lookup, a wrong one invents an answer.
2. If the request explicitly names a file format -- pdf, docx, xlsx, png, excel,
   spreadsheet, workbook, word document, image -- the lane is docgen. Always.
3. Otherwise, if a registered skill's trigger keywords or description match the
   request, the lane is skill. Words like "one-pager", "briefing", "summary" or
   "overview" describe a STYLE OF ANSWER, not a file, so they do not make it docgen.
4. Otherwise the lane is retrieval.

Return JSON only: {"lane": "...", "skill_id": <id or null>, "why": "<one line>"}"""


def chitchat_reply(query: str, convo_ctx: str = "") -> str:
    """Composed per message -- there is deliberately no canned greeting."""
    return responder.compose("chitchat", {"user_message": query})


# --- reference resolution (section 4.6) ------------------------------------
# A request whose subject is only a pronoun cannot be retrieved on literally.
# "make this a document" must not search for the word "this" and must not report
# "not found in the knowledge base" -- that is a reference failure, not a gap.
_PRONOUN_ONLY = re.compile(
    r"^\s*(please\s+)?"
    r"(make|turn|convert|export|summari[sz]e|expand|explain|send|save|format|"
    r"put|write|give|create|generate|build|draft|do|tell|show|describe|list)?\s*"
    r"(me\s+)?"
    r"(on|about|upon|into|to|out|up)?\s*"      # "expand ON that", "tell me ABOUT it"
    r"(a|an|the)?\s*"
    r"\b(this|that|it|these|those|the\s+above|the\s+last\s+one|same)\b"
    r"[\s\w]{0,40}$", re.I)

_HAS_SUBJECT = re.compile(
    r"\b(department|team|kpi|escalation|policy|process|system|contact|sop|"
    r"function|service|glossary|faq|budget|roster|charter|matrix|owner|lead|"
    r"head|stakeholder|integration|dependency)\b", re.I)


# A leading pleasantry is not part of the question. "thanks - now what is the
# escalation matrix?" was measurably worse at retrieval than the bare question:
# the prefix shifts cross-encoder scores enough to drop the one filled escalation
# matrix out of the kept set, leaving only blank ones. Section 4.6 requires the
# informational part to go through full retrieval, so strip the social wrapper
# from the RETRIEVAL query only -- the user still sees their words echoed back.
_LEADING_PLEASANTRY = re.compile(
    r"^\s*(hi|hey|hello|yo|thanks|thank\s+you|thx|cheers|ok|okay|cool|great|"
    r"good\s+(morning|afternoon|evening)|please)\b"
    r"[\s,.!—-]*(there|team|again)?[\s,.!—-]*"
    r"(and\s+)?(now|then|also|next)?[\s,.!—-]*", re.I)


def strip_pleasantries(query: str) -> str:
    """Remove leading social filler. Returns the original if nothing is left."""
    q = (query or "").strip()
    for _ in range(3):                      # "hi there, thanks - now ..."
        stripped = _LEADING_PLEASANTRY.sub("", q, count=1).strip()
        if stripped == q:
            break
        q = stripped
    return q or (query or "").strip()


_ANY_PRONOUN = re.compile(
    r"\b(this|that|it|these|those|them|same|the\s+above|the\s+last\s+one)\b", re.I)


def needs_reference_resolution(query: str) -> bool:
    """True when the request's ONLY subject is a pronoun.

    Deliberately strict: this is the test for asking a clarifying question, and a
    false positive here means nagging the user about a question they asked clearly.
    """
    q = (query or "").strip()
    if not q or len(q.split()) > 10:
        return False
    if _HAS_SUBJECT.search(q):
        return False          # names a real subject alongside the pronoun
    return bool(_PRONOUN_ONLY.match(q))


def has_unresolved_pronoun(query: str) -> bool:
    """True when a short query leans on a pronoun and names no concrete subject.

    Looser than needs_reference_resolution because the consequence is different:
    this only decides whether to REWRITE the query against conversation context,
    which is safe. "who owns it?" is not pronoun-as-subject, so the strict test
    misses it -- but retrieving on that literal text finds nothing, which is how a
    correctly-scoped follow-up still came back "not found".
    """
    q = (query or "").strip()
    if not q or len(q.split()) > 14:
        return False
    if not _ANY_PRONOUN.search(q):
        return False
    return not _HAS_SUBJECT.search(q)


_RESOLVE_SYSTEM = """Rewrite the user's latest message into a standalone question,
substituting what its pronouns refer to using the conversation so far.

Return JSON only: {"resolved": "<standalone question>", "confident": true|false}

- Change as little as possible: swap the pronoun for the thing it refers to and
  leave the rest alone.
- Keep the user's intent. "make this a document" about the TAG roster becomes
  "make a document about the TAG roster" -- still a document request.
- Add no facts and no detail the conversation does not contain.
- If the conversation does not make the referent clear, set confident false and
  return the original message unchanged."""


# Second pass, used only after the first one declines. The first prompt is allowed
# to say "not confident"; this one is not, because it only runs when a prior user
# turn demonstrably exists, which means a referent exists.
_RESOLVE_FORCED_SYSTEM = """The user's latest message refers back to the
conversation with a pronoun. Rewrite it as a standalone request, replacing the
pronoun with the topic of the most recent thing the user asked about.

The referent IS present in the conversation. Do not refuse, do not ask for
clarification, and do not return the message unchanged.

Keep the user's intent and action exactly -- a document request stays a document
request. Add no facts the conversation does not contain.

Return JSON only: {"resolved": "<standalone request>"}"""


_NEEDS_CONTEXT_SYSTEM = """Decide whether the user's latest message can be
understood on its own, or whether it needs the earlier conversation to know what it
is about.

NEEDS CONTEXT -- it points back at something said earlier without naming it:
"make it a document", "above details", "make the detail as a document", "explain
more about that", "what about last quarter", "same for the other one". Pointing back
does NOT require a pronoun: "the detail", "above", "more", "the same" all refer to
something already said.

SELF-CONTAINED -- it names its own subject, even if a pronoun also appears:
"What is Labs' role, and who leads it?", "What are Finance's KPIs?", "who owns this
process in P-Cube?"

Judge the shape of the message, not which specific words it uses.

Return JSON only: {"needs_context": true|false}"""


def depends_on_context(query: str, convo_ctx: str) -> bool:
    """Does this message need the earlier turns to know what it is about?

    This replaces a regex over a fixed list of referring expressions. That list
    decided WHETHER resolution ran at all, so anything it did not enumerate was
    never resolved: "make the detail as a document" and "above details" both point
    backwards perfectly clearly to a person, contain no listed pronoun, and so went
    straight to retrieval as literal text and came back empty -- while "make the
    ABOVE details as a document" worked purely because "the above" happened to be
    on the list. Enumerating more referring expressions is the same bug with a
    longer list, so the judgement is now about shape.

    Cheap guards first, so the model is only consulted when it could matter:
    no context to resolve against, an over-long message, or a message that names
    its own department all answer this without a call.
    """
    if not (convo_ctx or "").strip():
        return False
    q = (query or "").strip()
    if not q or len(q.split()) > 14:
        return False
    if _names_a_department(q):
        return False               # names its own scope, so it stands alone
    try:
        resp = chat_create(
            temperature=0,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": _NEEDS_CONTEXT_SYSTEM},
                      {"role": "user",
                       "content": f"Conversation so far:\n{convo_ctx}\n\n"
                                  f"Latest message: {q}"}],
        )
        data = json.loads(resp.choices[0].message.content or "{}")
        return data.get("needs_context") is True
    except Exception:
        # Fall back to the old deterministic signal rather than nothing.
        return has_unresolved_pronoun(q)


def last_substantive_user_turn(convo_ctx: str) -> str | None:
    """The most recent user line in the context that names something concrete.

    This is the referent of last resort and needs no model call, so it cannot be
    non-deterministic: if the user asked something real and then said "make it a
    document", the real question IS what "it" refers to.

    The test is needs_reference_resolution (is this ONLY a pronoun?), NOT
    has_unresolved_pronoun (does it contain one?). Ordinary questions mention
    pronouns while still naming their subject perfectly well -- "What is Labs' role,
    and who leads it?" is the referent for the follow-up that comes after it, and an
    earlier version of this function rejected exactly that opener for containing
    "it", so the fallback never ran and Labs still asked for clarification.
    """
    for line in reversed((convo_ctx or "").splitlines()):
        if not line.lower().startswith("user:"):
            continue
        text = line.split(":", 1)[1].strip()
        if text and not needs_reference_resolution(text):
            return text
    return None


# Words that describe the OUTPUT rather than the subject. A rewrite made only of
# these has resolved nothing, however fluent it reads.
_FORMAT_WORDS = {
    "document", "documents", "doc", "docs", "docx", "pdf", "xlsx", "excel",
    "spreadsheet", "workbook", "image", "png", "file", "report", "export",
}
_FILLER_WORDS = {
    "please", "provide", "about", "which", "what", "this", "that", "these",
    "those", "them", "there", "with", "from", "your", "make", "turn", "into",
    "also", "have", "does", "would", "could", "like", "want", "need", "give",
    "create", "generate", "summarise", "summarize", "regarding", "related",
}


def _subject_tokens(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9]{4,}", (text or "").lower())
            if w not in _FORMAT_WORDS and w not in _FILLER_WORDS}


def _carries_subject(resolved: str, prior: str | None) -> bool:
    """True when the rewrite actually names something from the turn it refers to.

    A pronoun check alone is not enough. "Please provide the document." contains no
    pronoun and is perfectly grammatical, yet names nothing -- accepting it sends a
    subject-less query into retrieval, which finds nothing and (because scope was
    inferred) comes back asking which department was meant. That is the original
    bug wearing a different hat, so the rewrite has to prove it carried the subject
    across, not merely that it dropped the pronoun.
    """
    if not prior:
        return bool(_subject_tokens(resolved))
    return bool(_subject_tokens(resolved) & _subject_tokens(prior))


def _resolve_once(system: str, query: str, convo_ctx: str,
                  require_confident: bool) -> str | None:
    try:
        resp = chat_create(
            temperature=0,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": system},
                      {"role": "user",
                       "content": f"Conversation so far:\n{convo_ctx}\n\n"
                                  f"Latest message: {query}"}],
        )
        data = json.loads(resp.choices[0].message.content or "{}")
        resolved = (data.get("resolved") or "").strip()
        if not resolved:
            return None
        if require_confident and not data.get("confident"):
            return None
        # A rewrite identical to the input resolved nothing.
        if resolved.strip().lower() == (query or "").strip().lower():
            return None
        # A rewrite that is STILL only a pronoun resolved nothing either, however
        # confident the model claimed to be. Accepting one sends a subject-less
        # query ("making it a document") into retrieval, which then legitimately
        # finds nothing -- and because scope was inferred, the request comes back
        # as "which department did you mean?" even though the pronoun had already
        # been matched to the right one. That reads exactly like the original bug.
        if needs_reference_resolution(resolved):
            return None
        return resolved
    except Exception:
        return None


def resolve_reference(query: str, convo_ctx: str) -> tuple[str, bool]:
    """(resolved_query, resolved). Falls back to the original text on any failure.

    Why this is layered rather than one call. The single-call version decided the
    whole outcome on one non-deterministic `confident` flag, and that flag turned
    out to be phrasing-sensitive: against a real Labs answer, "make it a document"
    reported confident 3 times out of 3, "make this a document" 2 out of 3, and
    "make it document" 0 out of 3 -- so the same follow-up succeeded or asked for
    clarification depending on wording and on sampling luck. That is why this bug
    kept coming back on a new department after being fixed on the last one: the
    department was never the variable, the phrasing and the coin-flip were.

    Clarifying is correct only when there is genuinely nothing to resolve against
    (sections 4.6, 4.8). "The model felt unsure" is not the same thing as "there is
    no earlier turn", so a prior substantive turn now forces a rewrite instead.
    """
    if not convo_ctx.strip():
        return query, False            # nothing to resolve against: caller may ask

    prior = last_substantive_user_turn(convo_ctx)

    # 1. Normal attempt, retried once -- the same "retry before accepting a
    #    self-reported failure" pattern the groundedness gate uses.
    for _ in range(2):
        resolved = _resolve_once(_RESOLVE_SYSTEM, query, convo_ctx,
                                 require_confident=True)
        if resolved and _carries_subject(resolved, prior):
            return resolved, True

    # 2. A prior substantive turn exists, so a referent exists. Force the rewrite
    #    rather than asking the user to repeat what they just said.
    if prior:
        resolved = _resolve_once(_RESOLVE_FORCED_SYSTEM, query, convo_ctx,
                                 require_confident=False)
        if resolved and _carries_subject(resolved, prior):
            return resolved, True

        # 3. Deterministic last resort, no model call and therefore no variance:
        #    the question the pronoun refers back to IS the subject. Retrieval acts
        #    on this text; the output FORMAT is read from the user's original words
        #    (generator.detect_format(query) in main.py), so handing retrieval the
        #    earlier question does not turn a docx request into a pdf.
        return prior, True

    return query, False


def reference_clarification(query: str, has_prior_context: bool = False) -> str:
    """Ask what the pronoun meant. Composed, not templated."""
    m = re.search(r"(this|that|it|these|those|same)", query or "", re.I)
    wants_doc = bool(re.search(
        r"(document|doc|pdf|xlsx|excel|spreadsheet|docx|file|image|png)",
        query or "", re.I))
    # The reason has to describe the real situation. Stating "there is no earlier
    # turn" after a conversation that plainly had one is a false explanation.
    why = ("the earlier turns in this conversation do not make clear what it "
           "refers to" if has_prior_context else
           "there is no earlier turn in this conversation to resolve it against")
    return responder.compose("unresolved_reference", {
        "user_message": query,
        "pronoun": m.group(0) if m else "that",
        "requested_action": "create a document" if wants_doc else "look something up",
        "why": why,
    })


def classify_lane(query: str, skills: list[dict]) -> tuple[str, str | None, str]:
    listing = "\n".join(
        f'- id={s["id"]} name={s["name"]}: {s["description"]} '
        f'(triggers: {", ".join(s.get("trigger_keywords") or [])})'
        for s in skills) or "(no skills registered)"
    try:
        resp = chat_create(
            temperature=0,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": _LANE_SYSTEM + "\n\nSkills:\n" + listing},
                      {"role": "user", "content": query}],
        )
        data = json.loads(resp.choices[0].message.content or "{}")
        lane = data.get("lane") if data.get("lane") in LANES else "retrieval"
        return lane, data.get("skill_id"), data.get("why", "")
    except Exception:
        return "retrieval", None, "lane classification unavailable; defaulted to retrieval"


# --- deterministic entity index (section 4.6) -------------------------------
# The LLM router was measurably unstable for some phrasings: "How does the
# goal-setting process work?" routed correctly on 3 of 5 identical runs and asked for
# clarification on the other 2, at temperature 0. That is a property of the matching
# APPROACH, not of the question -- the entity ("Goal Setting") is right there in the
# summary either way.
#
# So entity matching is done deterministically first, from the same structured lines
# the summaries already publish. Nothing here is hand-written per question: the terms
# are whatever the summaries list. The LLM router still runs for everything the index
# cannot decide.
_ENTITY_LINES = ("teams and sub-departments:", "functions:", "processes:",
                 "kpis:", "systems:", "key terms and abbreviations:")

# Words too generic to identify a department on their own; every summary has them.
_GENERIC_TERMS = {
    "compliance", "budget management", "vendor management", "service delivery",
    "onboarding support", "governance", "reporting", "operations", "automation",
    "risk management", "quality", "training", "documentation", "support",
    "management", "administration", "planning", "strategy", "analytics",
    "performance management", "resource management", "process excellence",
}


def _normalize_entity(text: str) -> str:
    """Fold a term or a query to one comparable form.

    "&" becomes "and" on BOTH sides: the index held "Year-End Assessment &
    Calibration" while the question said "year-end assessment and calibration", so
    the two never met and the question routed to the wrong department.
    """
    t = re.sub(r"\(.*?\)", " ", text or "")        # drop "(expansion)"
    t = t.replace("&", " and ")
    t = re.sub(r"[^A-Za-z0-9\s-]", " ", t)
    return re.sub(r"\s+", " ", t).strip().lower()


# "Track C - RFP Build Process", "Phase 2 - Gate Review", "Step 1 Intake": a short
# enumerator in front of the real name. People ask for the name, not the label.
_ENUMERATOR = re.compile(
    r"^(?:track|phase|stage|step|level|tier|type|option|part|wave)\s+[a-z0-9]{1,3}\s+",
    re.I)


def _term_variants(term: str) -> set[str]:
    """The term, plus its head phrase when a qualifier follows, plus its tail when
    a leading enumerator precedes it.

    KPI and process names are routinely written as "<name> vs. <benchmark>" or
    "<name> - <detail>", while people ask using the head alone: the index held
    "portfolio performance vs ips benchmarks" and the question said "portfolio
    performance", which matched nothing.

    The mirror case is a LEADING label. The index held "track c rfp build process"
    while the question said "the RFP build process", so the deterministic match
    missed and routing fell through to the LLM -- which got it right 4 times out of
    4 by hand and wrong once inside a full run. Indexing the tail makes it decided
    rather than sampled.
    """
    out = {term}
    for sep in (" vs ", " versus ", " - ", " / ", " for ", ":"):
        if sep in term:
            head = term.split(sep, 1)[0].strip()
            if len(head) >= 8 and len(head.split()) >= 2:
                out.add(head)
    tail = _ENUMERATOR.sub("", term).strip()
    if tail != term and len(tail) >= 8 and len(tail.split()) >= 2:
        out.add(tail)
    return out


_INDEX_CACHE: dict[str, object] = {}
_INDEX_TTL_SECONDS = 300


def _indexes() -> tuple[dict[str, set[str]], dict[str, set[str]]]:
    """(owned, contested), both derived from the published summaries.

    owned      terms specific enough to route on, owned by exactly one department
    contested  terms that appear under 2+ departments' owned labels. These are the
               ones that must NOT produce a confident route: "compliance" is listed
               by six departments, two of them as a bare owned term, so answering
               "who owns compliance?" with a single department states as fact
               something the knowledge base does not support.

    Cached briefly: this used to be a database read on every single query.
    """
    now = time.time()
    if _INDEX_CACHE.get("at", 0) and now - float(_INDEX_CACHE["at"]) < _INDEX_TTL_SECONDS:
        return _INDEX_CACHE["owned"], _INDEX_CACHE["contested"]  # type: ignore[return-value]
    owned, seen_all = _build_index()
    # Contested AND not specific enough to route on. The second half matters: two
    # departments both list "Capability Management Office", but that is one
    # department's own name which the other references, and the router's owns-vs-
    # references tie-break already resolves it correctly. Flagging it would turn a
    # working answer into a needless question. What is left is the genuinely common
    # vocabulary the index deliberately refuses to route on -- compliance,
    # governance, reporting, growth -- where naming one owner really is a guess.
    contested = {t: o for t, o in seen_all.items()
                 if len(o) > 1 and t not in owned}
    _INDEX_CACHE.update({"at": now, "owned": owned, "contested": contested})
    return owned, contested


def contested_terms_in(query: str) -> list[str]:
    """Contested terms this query actually names, longest first.

    Handed to the router so it stops treating a shared term as an identifying
    entity. Derived from the data, so it covers every shared term rather than the
    handful anyone thought to write down.
    """
    q = " " + _normalize_entity(query) + " "
    try:
        _, contested = _indexes()
    except Exception:
        return []
    found = [t for t in contested if f" {t} " in q]
    if not found:
        return []

    # A shared word only makes a question unroutable when it IS the question.
    # "Who owns compliance?" is about nothing else, so naming one of the six
    # departments that list compliance is a guess. "Who owns KEBS data capture?"
    # and "how does milestone and deliverable predictability governance work?"
    # merely CONTAIN a shared word inside a far more specific phrase, and those
    # route correctly -- flagging them cost two working answers. So: report the
    # shared terms only when they account for everything the question is about.
    residual = set(_residual_subject(query))
    covered: set[str] = set()
    for term in found:
        covered |= set(term.split())
    if residual - covered:
        return []
    return sorted(found, key=len, reverse=True)[:12]


def _entity_index() -> dict[str, set[str]]:
    """term -> {slugs that list it}, restricted to terms worth routing on."""
    return _indexes()[0]


def _build_index() -> tuple[dict[str, set[str]], dict[str, set[str]]]:
    """Returns (routable, every-term). The second keeps the terms the first drops
    -- generic words and bare single words -- because those are exactly the ones
    needed to notice that a query names nothing distinctive."""
    index: dict[str, set[str]] = {}
    every: dict[str, set[str]] = {}
    for row in _summaries():
        slug, text = row["head_dept"], row.get("summary_md") or ""
        for line in text.splitlines():
            low = line.strip().lower()
            if not any(low.startswith(p) for p in _ENTITY_LINES):
                continue
            for raw in line.split(":", 1)[1].split(","):
                term = _normalize_entity(raw)
                if len(term) < 4:
                    continue
                # Recorded BEFORE the routability filters below. A term dropped for
                # being generic or single-word is still evidence about ownership --
                # it is precisely what tells us a query names nothing distinctive.
                every.setdefault(term, set()).add(slug)
                if len(term) < 6 or term in _GENERIC_TERMS:
                    continue
                # A single ordinary word is never specific enough to route on.
                # "capability" was indexed as uniquely owned by FDE TCG purely
                # because that summary happened to list it alone, and it then
                # captured every CMO question containing the word. Acronyms are the
                # exception -- "KEBS", "PRMG", "OQL" are genuinely distinctive.
                is_acronym = raw.strip().isupper() and 3 <= len(raw.strip()) <= 8
                if len(term.split()) == 1 and not is_acronym:
                    continue
                for variant in _term_variants(term):
                    if len(variant) < 6 or variant in _GENERIC_TERMS:
                        continue
                    if len(variant.split()) == 1 and not is_acronym:
                        continue
                    index.setdefault(variant, set()).add(slug)
    return index, every


def match_entity(query: str) -> str | None:
    """Slug when the query names an entity owned by exactly ONE department."""
    # Same normalisation the index was built with, so "&" and "and" compare equal.
    q = " " + _normalize_entity(query) + " "
    try:
        index = _entity_index()
    except Exception:
        return None

    matches = [(len(term), term, owners) for term, owners in index.items()
               if f" {term} " in q]
    if not matches:
        return None

    # Longest match wins, INCLUDING when it is ambiguous. Skipping ambiguous terms
    # and falling through to a shorter one inverted the specificity: "capability
    # management office" is owned by both CMO and FDE TCG, so it was ignored and the
    # shorter "capability" decided the route on its own. If the most specific thing
    # the question names is genuinely shared, defer to the LLM router instead.
    matches.sort(key=lambda m: -m[0])
    _, _, owners = matches[0]
    return next(iter(owners)) if len(owners) == 1 else None


def resolve_scope(query: str, explicit_head_dept: str | None,
                  convo_ctx: str = "", intent: Intent | None = None) -> Plan:
    """convo_ctx is prior turns, used ONLY to interpret an elliptical follow-up
    ("what about last quarter?"). It never widens scope on its own: an explicit
    head_dept still wins outright, and a low-confidence match still asks.

    `intent` is the shape judgement from understand(). It is passed in rather than
    recomputed so the whole request is judged once, on the same reading.
    """
    # A breadth request needs structural retrieval whatever its scope. Computed once
    # here and carried on the Plan, so every branch below gets it -- the single
    # department cases used to fall through to similarity search and answer "I
    # couldn't find any information related to <that department>".
    if intent is None:
        intent = Intent(breadth=is_breadth_request(query),
                        all_departments=is_broad_summary(query), source="fallback")
    breadth = intent.breadth

    # 1. explicit scope wins outright
    if explicit_head_dept:
        return Plan(head_depts=[explicit_head_dept], confidence=1.0, inferred=False,
                    broad_coverage=breadth,
                    reasoning="explicit head_dept supplied by the client")

    # 2. explicit cross-department intent
    broad = intent.breadth and intent.all_departments
    if _ALL_PATTERNS.search(query) or broad:
        hds = populated_head_depts()
        return Plan(head_depts=hds, confidence=1.0, inferred=False, searched_all=True,
                    broad_coverage=broad,
                    reasoning=("broad all-department summary" if broad
                               else "user asked to search across all departments"))

    # 3. match against hd_index summaries
    summaries = _summaries()
    if not summaries:
        return Plan(needs_clarification=True,
                    clarification=responder.compose("no_index", {}),
                    reasoning="hd_index empty")

    # Deterministic entity match first. If the question names something exactly one
    # department publishes, that is not a judgement call and should not be re-decided
    # by a model that answers differently on identical input.
    entity_slug = match_entity(query)
    if entity_slug:
        return Plan(head_depts=[entity_slug], confidence=0.9, inferred=True,
                    broad_coverage=breadth,
                    reasoning="deterministic entity match from the routing index")

    catalogue = "\n\n".join(f"slug: {s['head_dept']}\n{s['summary_md']}" for s in summaries)
    shared = contested_terms_in(query)
    try:
        resp = chat_create(
            temperature=0,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": _ROUTE_SYSTEM},
                      {"role": "user",
                       "content": (f"Departments:\n{catalogue}\n\n"
                                   + (f"Terms in this question that SEVERAL departments "
                                      f"use, and which therefore identify none of them: "
                                      f"{', '.join(shared)}\n\n" if shared else "")
                                   + (f"Earlier turns in this conversation (for resolving "
                                      f"references like 'that team' or 'last quarter' "
                                      f"only):\n{convo_ctx}\n\n" if convo_ctx else "")
                                   + f"Question: {query}")}],
        )
        data = json.loads(resp.choices[0].message.content or "{}")
    except Exception as exc:
        return Plan(needs_clarification=True,
                    clarification=responder.compose("router_error", {}),
                    reasoning=f"router error: {type(exc).__name__}")

    known = {s["head_dept"] for s in summaries}
    ranked = [(d.get("slug"), float(d.get("confidence", 0)))
              for d in data.get("departments", []) if d.get("slug") in known]
    ranked.sort(key=lambda x: x[1], reverse=True)
    reasoning = data.get("reasoning", "")

    if not ranked or ranked[0][1] < HD_ROUTING_MIN_CONFIDENCE:
        return Plan(confidence=ranked[0][1] if ranked else 0.0,
                    needs_clarification=True,
                    clarification=responder.compose("ambiguous_scope", {
                        "user_question": query,
                        "example_departments": [display_name(s_["head_dept"])
                                                for s_ in summaries[:6]],
                        "closest_guess": display_name(ranked[0][0]) if ranked else None,
                        "can_search_all": True,
                    }),
                    reasoning=reasoning or "below confidence threshold")

    chosen = [ranked[0][0]]
    if len(ranked) > 1 and ranked[0][1] - ranked[1][1] <= HD_ROUTING_DUAL_MARGIN \
            and ranked[1][1] >= HD_ROUTING_MIN_CONFIDENCE:
        chosen.append(ranked[1][0])

    return Plan(head_depts=chosen, confidence=ranked[0][1], inferred=True,
                broad_coverage=breadth, reasoning=reasoning)


def log_routing(query: str, plan: Plan) -> None:
    try:
        supabase().table("routing_log").insert({
            "query": query,
            "resolved_head_depts": plan.head_depts or None,
            "confidence": plan.confidence,
            "task_lane": plan.lane,
        }).execute()
    except Exception:
        pass  # logging must never break a request
