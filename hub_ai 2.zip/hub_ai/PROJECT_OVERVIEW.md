# HUB AI — Project Overview

> Written for another AI assistant that cannot see the code. It is based on reading the actual files in the repo (backend modules, SQL migrations, frontend `index.html`, both `CLAUDE.md` files, and the test suite). Where the repo's own docs contradict the code, the code wins and the discrepancy is flagged in section 10. No secrets are included.

---

## 1. PROJECT SUMMARY

**HUB AI** (UI title: "Agilisium Hubs AI") is an internal, ChatGPT-style chatbot for **Agilisium**. It answers employee questions **strictly from a curated company knowledge base**. That knowledge base is a set of JSON "department profile" files, 90+ in the target state, grouped under **18 head departments (HDs)**.

**Who it is for:** internal employees. Identity is a client-generated anonymous UUID, so there is no real login. A separate Basic-auth gate protects the knowledge-base admin (ingest) actions.

**Problem it solves:** generic LLM chatbots invent answers. HUB AI is built around not doing that.
- Retrieval is hard-scoped per department, and one department's data does not leak into another's.
- A relevance gate refuses when nothing relevant is found.
- Every drafted answer is claim-checked against the retrieved passages, and unsupported claims are removed before the user sees them.
- Every answer carries source-file citations.
- Per-department `do_not_disclose` rules are enforced at generation time and are never embedded.

**Three capabilities:**
1. Grounded Q&A with citations.
2. Document creation (docx / pdf / xlsx / png) built only from retrieved, grounded passages.
3. User-uploaded "skills" (instructions plus an optional script). Scripts are stored and never executed.

**Also included:** conversation history, a sidebar "Search chats", long-term per-user memory (API only), and live pipeline-status streaming.

---

## 2. TECH STACK

| Layer | Choice |
|---|---|
| Language | Python 3.14.7 (the backend venv's `pyvenv.cfg`); vanilla JavaScript, HTML and CSS for the frontend |
| Backend framework | FastAPI (async-capable, but most routes are sync `def`), served by uvicorn |
| Database | Supabase Postgres with `pgvector` (HNSW cosine index) and native `tsvector` full-text (GIN index) |
| File storage | Supabase Storage bucket holding the raw KB JSON |
| LLM and embeddings | OpenAI. Chat model default `gpt-4o-mini` (env `OPENAI_CHAT_MODEL`); embeddings default `text-embedding-3-small`, 1536 dims (env `OPENAI_EMBEDDING_MODEL`) |
| Reranker | Local cross-encoder `cross-encoder/ms-marco-MiniLM-L-6-v2` via `sentence-transformers` (pulls in torch). The LLM reranker is the fallback (`RERANK_BACKEND=llm`) and the automatic fallback if the model fails to load |
| Doc generation | `python-docx`, `openpyxl`, `reportlab`, `Pillow` |
| Test tooling | `playwright` (Python, headless Chromium) and FastAPI `TestClient` |
| Frontend | One static file, `frontend/index.html` (about 2,100 lines). **No Node, npm, React, Vite or build step, by explicit rule** |
| Hosting / deploy | None defined. The app runs locally with uvicorn, and FastAPI also serves `frontend/` as static files. There is no Dockerfile, CI or cloud config in the repo |

**Declared versions** (`backend/requirements.txt`; all are lower bounds, with no lockfile and no pinned versions):
`fastapi>=0.115`, `uvicorn[standard]>=0.32`, `python-dotenv>=1.0`, `openai>=1.55`, `supabase>=2.10`, `pydantic>=2.9`, `python-docx>=1.1`, `openpyxl>=3.1`, `reportlab>=4.2`, `Pillow>=11.0`, `sentence-transformers>=6.0`, `playwright>=1.49`.

There is no `package.json`, by design.

**External services:** OpenAI API, Supabase (Postgres, Storage, PostgREST), and Hugging Face Hub (downloads the cross-encoder weights; optional `HF_TOKEN`).

---

## 3. FOLDER STRUCTURE

```
hub_ai/
├─ CLAUDE.md                 Build spec / project rules (the source of intent; long)
├─ CLAUDE.md.bak             Backup of an older CLAUDE.md
├─ PROJECT_OVERVIEW.md       This file
├─ .gitignore                Ignores .env, venvs, logs, eval/matrix output, e2e artifacts
├─ .claude/
│  ├─ settings.json          Registers two Claude Code hooks (below)
│  └─ hooks/
│     ├─ guard_heredoc.py    PreToolUse: blocks writing source via bash heredoc (it corrupted regexes before)
│     └─ check_integrity.py  PostToolUse: every .py parses and no raw control bytes in source files
├─ frontend/
│  ├─ CLAUDE.md              Frontend-only rules (loaded when working under frontend/)
│  ├─ index.html             The entire UI: CSS, markup and vanilla JS (~2,100 lines)
│  └─ src/agilisium.png      Logo (the bytes are actually WebP; this is intentional)
└─ backend/
   ├─ main.py                FastAPI app, every route, and the chat pipeline orchestration (_run_chat)
   ├─ config.py              All env vars and tunables (single source; nothing hardcoded elsewhere)
   ├─ clients.py             Cached Supabase + OpenAI clients; db_call() retry wrapper for transient httpx errors
   ├─ perf.py                Stopwatch (per-stage timing) + persist to latency_log
   ├─ responder.py           LLM-composed user-facing messages (no canned strings by design)
   ├─ requirements.txt       Dependencies
   ├─ README.md              Backend README (partly stale, see section 10)
   ├─ db/                    SQL migrations 001-004 + README (README is stale)
   ├─ ingestion/
   │  ├─ hd_map.py           The canonical 18 HDs: display name <-> slug, aliases, normalisation
   │  ├─ storage.py          List and download JSON from the Supabase Storage bucket
   │  ├─ chunker.py          JSON profile -> logical-unit chunks (one list item or section each)
   │  ├─ embedder.py         Batched OpenAI embeddings with retry
   │  ├─ summarizer.py       Builds the structured routing index (hd_index.summary_md) per HD via LLM
   │  ├─ pipeline.py         Incremental / full ingestion, orphan check, in-memory job state
   │  └─ run.py              CLI (python -m ingestion.run), including --dry-run
   ├─ planner/planner.py     Scope resolution, lane classification, intent/shape judgement, reference resolution, entity index, routing_log
   ├─ retriever/retriever.py hybrid_search fan-out, cross-encoder/LLM rerank, structural "broad" retrieval
   ├─ groundedness/gate.py   Pre-gate, generation, claim verification, citations, do_not_disclose, blank-section handling
   ├─ docgen/generator.py    Builds docx/pdf/xlsx/png from grounded hits and extracts the request subject
   ├─ skills/registry.py     Skill CRUD and instruction-only execution (scripts stored, never run)
   ├─ memory/store.py        Conversations, chat turns, chat search, long-term memory + safety filter
   ├─ streaming/progress.py  SSE status events driven off the Stopwatch; answer sent once in a final event
   ├─ entities.json          Generated dump of per-department entities (gitignored pattern; present locally)
   └─ tests/                 See "Testing" in section 8
      ├─ eval_set.py, run_eval.py      Standing quality eval (outcome-type assertions) + runner
      ├─ matrix_18.py, run_matrix_18.py  18-department x question-shape matrix
      ├─ shape_set.py, run_shape.py    Unit-level tests of planner.understand()
      ├─ preflight.py                  Fast parallel smoke over historically fragile shapes
      ├─ proof_continuity.py           Prints a multi-turn transcript + DB rows proving conversation_id reuse
      ├─ test_*.py                     memory, skills, streaming, broad coverage, context/no-hijack, docgen reference, search chats
      └─ e2e/                          Playwright browser suites (test_ui.py, test_all_departments.py)
```

Local-only, gitignored files such as `server.log`, `matrix_*.json` and `eval_*.json` may also be present in `backend/`.

---

## 4. HOW IT WORKS

### 4.1 Architecture

```
Browser (frontend/index.html, vanilla JS)
   │  fetch / SSE                      anon_user_id (localStorage) + conversation_id (per view)
   ▼
FastAPI (backend/main.py)  ── also serves frontend/ as static files at "/" (mounted last)
   ├─ planner (OpenAI chat, Supabase hd_index / routing_log)
   ├─ retriever ── Supabase RPC hybrid_search (pgvector + tsvector, RRF) ── local cross-encoder rerank
   ├─ groundedness gate ── OpenAI generate + claim-verify
   ├─ docgen (pure formatting) · skills registry · memory store
   └─ ingestion (background job) ── Supabase Storage → chunk → OpenAI embed → documents table
Supabase: Postgres (+pgvector) and Storage. The backend uses the service-role key (RLS is enabled with no policies).
```

Same-origin serving means the frontend's `API_BASE` is `''` over http(s). If the file is opened from disk (`file:`), it falls back to `http://127.0.0.1:8000`. CORS is `allow_origins=["*"]`.

### 4.2 Ingestion (offline / admin)

Triggered by the CLI or by the "Update Knowledge Base" / "Full Re-embed" buttons in the UI admin panel, which call `POST /api/documents/ingest` and poll the job.
1. List HD folders under `SUPABASE_KB_ROOT_PREFIX` (default `Organization Details`). Folders are named with HD **display names**, which `hd_map.resolve_slug` maps to slugs (case-insensitive; `&` is treated as "and"; extra aliases are accepted). Unknown folders are skipped with a warning.
2. List the JSON files per folder. Possible duplicate uploads (e.g. `x (1).json`) are flagged in warnings but still ingested.
3. **Orphan check (both modes):** chunks and log rows for files no longer in the bucket are deleted.
4. **Full mode:** delete the scope's `documents` and `ingestion_log` rows first.
5. Per file: skip if the bucket `updated_at` is not newer than `ingestion_log.file_updated_at` (incremental only). Otherwise download, `chunk_profile`, delete that file's old chunks, embed in batches, insert in batches, and upsert `ingestion_log`.
6. For each touched HD, regenerate `hd_index.summary_md` through an LLM digest of the profiles. This is a **structured routing index**: prose plus labelled lines (Teams and sub-departments, Functions, Processes, KPIs, Systems, Key terms and abbreviations). It deliberately never names other departments.

**Chunking** (`chunker.py`): the profiles have 31 uniform top-level keys. One chunk is made per list item for 15 list fields (functions, services_offered, kpis, faqs, glossary, contact_directory, sops, business_processes, cross_department_relationships, decision_matrix, approval_matrix, data_ownership, systems, policies, integrations). There is one chunk per section for the nested dicts (department_identity, organization_structure, ai_specific_knowledge, communication_channels, dependencies, escalation_matrix, stakeholders), and `profile_text` is its own chunk. Metadata-only keys are never embedded. `ai_specific_knowledge.do_not_disclose` is stripped from chunk text and stored in `metadata.file_meta`.

### 4.3 Request flow: `POST /api/chat` and `/api/chat/stream` (`main._run_chat`)

1. **Validate** the query, and `head_dept` if one is supplied.
2. **Load memory** (interpretation context only):
   - the last `MEMORY_TURN_WINDOW` (6) turns of this conversation;
   - long-term memories for the `anon_user_id`.
3. **Two concurrent LLM judgements:**
   - `planner.classify_lane` → `retrieval | docgen | skill | chitchat`;
   - `planner.understand` → an `Intent`: breadth, all_departments, drill_down, focus.
   - Chitchat is then re-checked deterministically with `is_pure_social` and can only be downgraded to retrieval.
4. **Chitchat lane:** the model writes a short reply through `responder.compose`, with no retrieval and no citations.
5. **Reference resolution:**
   - A drill-down uses the focus extracted from the previous answer.
   - Otherwise `depends_on_context` followed by `resolve_reference` rewrites the query against prior turns.
   - If a bare pronoun cannot be resolved, the app asks a clarifying question. It never reports "not found".
6. **Scope resolution** (`planner.resolve_scope`), in priority order:
   - an explicit `head_dept` (@mention or sidebar) is a hard scope;
   - "search all" or a broad all-department summary fans out to all populated HDs;
   - a **deterministic entity match** against the published routing index, which only counts if exactly one department owns the entity;
   - an LLM router over the `hd_index` summaries, with confidence thresholds. Below `HD_ROUTING_MIN_CONFIDENCE` (0.55) the app asks the user which department. A second department is added if it is within `HD_ROUTING_DUAL_MARGIN` (0.15) of the first.
   - Every decision is written to `routing_log`.
7. **Retrieval:**
   - *Broad* requests use `retrieve_broad`. It takes a structural, by-section slice per department (profile_text, identity, org structure, functions, processes, KPIs, services, systems), with no similarity scoring. It fetches departments concurrently, retries failures serially, and reports any department that is still empty so the answer can disclose it.
   - *Drill-downs* use a wider keep (`DRILLDOWN_KEEP=10`).
   - *Normal* retrieval embeds the query, then calls one `hybrid_search` RPC per department, concurrently. Reciprocal Rank Fusion is applied per department. The pooled hits go through a cross-encoder rerank. Its logit is mapped by sigmoid onto a 0–10 scale. Blank "Information not available" passages are down-weighted by ×0.35.
8. **Lane handling:**
   - *skill:* `registry.execute` applies `instructions_md` to the hits.
   - *docgen:* retrieve on the extracted subject (`generator.content_query`), run the pre-gate, then build the file and return it base64-encoded in the JSON body.
   - *retrieval:* `gate.generate`.
9. **`gate.generate`:**
   - The **pre-gate** refuses if the top rerank relevance is below `GROUNDEDNESS_MIN_RELEVANCE` (4.0). Broad structural hits skip the pre-gate.
   - A **blank-section** check runs on the kept set. If every field in the section is unfilled, the answer says "recorded but empty" instead of "not found".
   - `do_not_disclose` rules are injected as hard constraints.
   - Generation runs at temperature 0, grounded only in the numbered passages.
   - **Claim verification** uses an LLM audit followed by an LLM rewrite that removes unsupported claims. If everything is stripped, it **re-verifies once** before concluding "not found".
   - Citations are snapped to real retrieved filenames (one file per `[source: x]` bracket).
   - Preamble and sign-off boilerplate are stripped. Any department that could not be fetched is disclosed.
10. **Persist:** `_record` writes the user and assistant turns to `chat_turns`, sets the conversation title from the first message, and writes timing to `latency_log`. Persistence failures never break the response.
11. **Response body:** `answer`, `sources[{head_dept, source_file}]`, `inferred_hd`, `lane`, `grounded`, `confidence`, `needs_clarification`, `document{filename, media_type, base64}`, `unavailable_departments`, `dropped_claims`, `blank_section`, `timing`.

**Streaming (`/api/chat/stream`):** it is the same pipeline, with SSE events `status` (one per real pipeline stage, labelled from `streaming.STAGE_LABELS`) and a single terminal `done` or `error`. **The answer is never streamed token by token.** It is sent once, after claim verification, so a reader can't see a claim that is about to be removed. The "typing" effect is a client-side cosmetic reveal (`revealAnswer`) of already-verified text.

### 4.4 Frontend ↔ backend

The frontend is **wired to the backend**, despite stale docs saying otherwise.
- `findKBAnswer` calls `streamChat` (fetch plus a `ReadableStream` reader on `/api/chat/stream`) and falls back to `POST /api/chat`.
- `ANON_USER_ID` is a UUID in `localStorage['hubai_anon_user_id']`.
- `activeConversation` maps a **view key** (`home` or a department slug) to a `conversation_id`, created lazily through `POST /api/conversations` and reused for every message in that view. This is the fix for repeated failures where follow-ups lost context.
- Recents, opening a conversation, and Search chats use `/api/conversations*`.
- The admin panel calls `/api/kb-admin/login`, `/api/documents/ingest` and the status route. Credentials are kept in memory only, not in localStorage or sessionStorage.

---

## 5. KEY FEATURES

| Feature | Where |
|---|---|
| Strict grounded Q&A with citations | `groundedness/gate.py` (`generate`, `verify`, `snap_citations`, `pre_gate`) |
| Hybrid retrieval (vector + keyword, RRF) | `db/002_hybrid_search.sql`, `retriever/retriever.py` |
| Local cross-encoder rerank with LLM fallback; warmed at startup | `retriever/retriever.py`, `main._lifespan` |
| Hard department scoping; fail-closed `hybrid_search` (NULL filter returns zero rows) | `002_hybrid_search.sql`, `planner.resolve_scope` |
| Deterministic entity routing, then LLM routing, then ask the user | `planner.py` (`match_entity`, `_build_index`, `contested_terms_in`, `resolve_scope`) |
| Cross-department fan-out (concurrent) and broad all-department summaries (structural retrieval) | `retriever.retrieve`, `retrieve_broad`; `planner.understand` |
| Failure disclosure for departments that couldn't be fetched | `retrieve_broad`, `gate.coverage_gap_note` |
| Drill-down ("tell me more about the 2nd KPI") | `planner.understand`, `main._run_chat`, `gate.generate(prior_answer, focus)` |
| Reference resolution ("this", "it", "that") or ask | `planner.depends_on_context`, `resolve_reference`, `reference_clarification` |
| Chitchat lane (model-written, no retrieval) | `planner.is_pure_social`, `chitchat_reply`, `responder.py` |
| `do_not_disclose` enforcement (never embedded, injected as a constraint) | `chunker.py`, `gate.do_not_disclose_for`, `gate.generate` |
| Blank-section detection ("recorded but empty") | `retriever.is_blank_content`, `gate.is_blank_section`, `unavailable_fields` |
| Document creation (docx/pdf/xlsx/png) | `docgen/generator.py` (`detect_format`, `content_query`, `build`) |
| Skills (instructions-only execution; scripts stored, never run) | `skills/registry.py`, `main.py` skill routes |
| Conversation history, titles, per-view Recents, Search chats | `memory/store.py`, `main.py`, `index.html` |
| Long-term memory with a safety blocklist, plus list and delete endpoints | `memory/store.py` (`is_safe_memory`, `propose_memories`) |
| Live status via SSE, and answer reveal after verification | `streaming/progress.py`, `index.html` (`streamChat`, `revealAnswer`) |
| Per-stage latency instrumentation | `perf.py`, `latency_log` |
| KB admin gate (HTTP Basic, constant-time compare, fails closed) | `main._check_kb_admin` |
| Ingestion: incremental and full, orphan cleanup, async job with status | `ingestion/pipeline.py`, `main.py` |
| @mention of departments, Prompt Library, voice dictation (never auto-sends) | `frontend/index.html` |
| Dev-time guards against file corruption | `.claude/hooks/*` |

---

## 6. DATA MODELS / DATABASE SCHEMA

All tables are in the Supabase `public` schema. **RLS is enabled on all of them with no policies**, so anon and authenticated roles read nothing. The backend uses the service-role key, which bypasses RLS.

**`documents`**: one row per chunk (`001_schema.sql`)
- `id uuid pk`
- `head_dept text` (the slug)
- `sub_dept text`
- `source_file text` (the full storage path)
- `content text`
- `content_tsv tsvector` (generated from `content`, English)
- `embedding vector(1536)`
- `metadata jsonb` (keys include `section`, `label`, `item_index`, `storage_file_name`, `file_meta` carrying `do_not_disclose`, and `needs_review`)
- `created_at`
- Indexes: HNSW on `embedding` (cosine), GIN on `content_tsv`, btree on `head_dept`. An optional btree on `source_file` is in `003_optional_hardening.sql`.

**`hd_index`**: `head_dept text pk`, `summary_md text`, `updated_at`. This is the structured routing index per department.

**`ingestion_log`**: `storage_path text pk`, `head_dept`, `file_updated_at`, `processed_at`.

**`skills`**: `id`, `owner`, `name`, `description`, `trigger_keywords text[]`, `head_dept_scope`, `instructions_md`, `script_path`, `created_at`.

**`routing_log`**: `id`, `query`, `resolved_head_depts text[]`, `confidence float`, `task_lane`, `created_at`.

**`conversations`**: `id`, `anon_user_id`, `head_dept` (NULL means a home/global conversation), `title`, `created_at`, `updated_at`. Indexes on `(anon_user_id, updated_at desc)` and `(anon_user_id, head_dept, updated_at desc)`.

**`chat_turns`**: `id`, `conversation_id` (FK to `conversations`, on delete cascade), `role`, `content`, `head_dept`, `sources jsonb`, `created_at`.

**`user_memory`**: `id`, `anon_user_id`, `memory_text`, `category`, `source_conversation_id` (FK to `conversations`), `created_at`.

**`latency_log`**: `id`, `query`, `lane`, `head_dept_count`, `searched_all`, `total_ms`, `stages jsonb`, `created_at`.

**RPC `hybrid_search(query_embedding vector(1536), query_text text, filter_head_dept text, match_count int default 8)`**
- It returns `(id, content, head_dept, source_file, score)`.
- It runs a vector arm and a keyword arm (`plainto_tsquery`), each limited to `match_count*2`, then does a full outer join.
- The score is Reciprocal Rank Fusion: `1/(60+rank_v) + 1/(60+rank_t)`, with a missing arm counted as rank 1000.
- The `003` file re-declares it with `stable`, `security invoker` and a pinned `search_path`. The two bodies must be kept in sync by hand.

**Relationships:** `chat_turns → conversations` and `user_memory → conversations`, both by FK. The rest are joined logically by `head_dept` slug or `storage_path`. There are no FKs from `documents` to `ingestion_log`.

**In-memory (not persisted):** `ingestion.pipeline.JOBS`, which holds ingest job state and is lost on restart and not shared across workers. The planner's entity-index cache has a 5-minute TTL.

**The 18 head departments (slug ← display name):** `business_growth_management`, `business_growth_support`, `cmo`, `customer_success_management`, `delivery_management`, `fde_dcg`, `fde_tcg`, `finance`, `holding_co_family_office_management`, `internal_apps`, `knowledge_mastery_deployment`, `labs`, `office_of_ceo`, `p_cube`, `sme_advisory_group`, `support_services`, `tag`, `ocpe` (Organizational Culture & People Experience). Defined in `ingestion/hd_map.py`.

Per the repo's own notes, Finance, SME Advisory Group and OCPE currently hold no data (15 departments are populated).

---

## 7. API ENDPOINTS / ROUTES

All routes are in `backend/main.py`. `/api/*` routes are registered before the static mount.

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/chat` | Run the full pipeline and return the JSON body |
| POST | `/api/chat/stream` | Same pipeline as SSE: `status` events, then one `done` or `error` event |
| POST | `/api/kb-admin/login` | Check Basic credentials; returns 200 or 401, no token |
| POST | `/api/documents/ingest` | **Admin (Basic).** Start an async ingest job (`{head_dept?, mode: incremental\|full}`), returns `job_id` |
| GET | `/api/documents/ingest/status/{job_id}` | **Admin (Basic).** Job progress, warnings and errors |
| POST | `/api/skills/upload` | Register a skill (the script is stored, not executed) |
| GET | `/api/skills` | List skills |
| GET | `/api/head-departments` | The 18 departments with slug, name and routing summary |
| POST | `/api/conversations` | Create a conversation (`anon_user_id`, optional `head_dept`) |
| GET | `/api/conversations` | List for the sidebar (`anon_user_id`, `head_dept?`, `scope=auto\|department\|global\|all`) |
| GET | `/api/conversations/search` | Search the user's chats by title and content (declared before the `{id}` route on purpose) |
| GET | `/api/conversations/{id}` | One conversation with its turns |
| PATCH | `/api/conversations/{id}` | Rename |
| DELETE | `/api/conversations/{id}` | Delete (cascades to turns) |
| GET | `/api/memory?anon_user_id=` | List long-term memories |
| DELETE | `/api/memory/{memory_id}` | Delete one memory |
| DELETE | `/api/memory?anon_user_id=` | Delete all of a user's memories |
| POST | `/api/conversations/{id}/extract-memory?anon_user_id=` | Conservative end-of-conversation memory extraction |
| GET | `/api/health` | Liveness probe |
| GET | `/*` | Static `frontend/` (`index.html`) |

**Chat request:** `{query, head_dept?, session_id?, anon_user_id?, conversation_id?}`.

---

## 8. CONFIGURATION

**Environment variables** (`backend/.env`, gitignored; loaded by `config.py`; names only):

- **Required, startup fails without them:** `OPENAI_API_KEY`, `SUPABASE_URL`, `SUPABASE_KEY` (service role), `SUPABASE_KB_BUCKET`.
- **Optional, with defaults:** `OPENAI_CHAT_MODEL` (gpt-4o-mini), `OPENAI_EMBEDDING_MODEL` (text-embedding-3-small), `SUPABASE_KB_ROOT_PREFIX` ("Organization Details").
- **KB admin gate:** `KB_ADMIN_USERNAME`, `KB_ADMIN_PASSWORD`. These are read with `os.getenv`, so a missing value doesn't crash the server. Ingest endpoints then return 503 (fail closed).
- **Hugging Face:** `HF_TOKEN` (optional; an empty value is removed from the environment).
- **Tunables:**
  - Ingestion: `EMBED_BATCH_SIZE` (64), `INSERT_BATCH_SIZE` (100).
  - Retrieval: `RETRIEVAL_MATCH_COUNT` (8), `RERANK_KEEP` (5), `FANOUT_PER_DEPT_KEEP` (2), `BROAD_PER_DEPT_KEEP` (3), `SINGLE_DEPT_BREADTH_KEEP` (8), `DRILLDOWN_KEEP` (10), `DRILLDOWN_MIN_RELEVANCE` (1.0).
  - Gate and rerank: `GROUNDEDNESS_MIN_RELEVANCE` (4.0), `RERANK_BACKEND` (`cross_encoder` | `llm`), `CROSS_ENCODER_MODEL`.
  - Memory: `MEMORY_TURN_WINDOW` (6), `MEMORY_MAX_LONG_TERM` (10).
  - Routing: `HD_ROUTING_MIN_CONFIDENCE` (0.55), `HD_ROUTING_DUAL_MARGIN` (0.15).

**Install and run (Windows; from `backend/`):**
```bash
python -m venv .venv
.venv/Scripts/python -m pip install -r requirements.txt
python -m playwright install chromium          # only for browser tests
.venv/Scripts/python -m uvicorn main:app --reload
# UI + API at http://127.0.0.1:8000 (FastAPI serves frontend/)
```

**Database setup:** run in the Supabase SQL editor, in order: `db/001_schema.sql`, `db/002_hybrid_search.sql`, `db/004_memory_and_latency.sql`, and optionally `db/003_optional_hardening.sql` (it re-declares `hybrid_search`).

**Ingest:**
```bash
python -m ingestion.run --dry-run --head-dept cmo     # chunk only; no embed or write
python -m ingestion.run --mode incremental            # everyday path
python -m ingestion.run --head-dept cmo --mode full   # rebuild one department
```
Or use the UI admin panel (needs the KB admin credentials).

**Tests** (run from `backend/`):
```bash
python -m tests.run_eval            # standing quality eval (TestClient; no server needed)
python -m tests.run_matrix_18       # 18-department x question-shape matrix
python -m tests.run_shape           # planner.understand() unit-level
python -m tests.preflight --base http://127.0.0.1:8040   # fast parallel smoke against a running server
python -m tests.proof_continuity    # multi-turn conversation_id proof
python -m tests.e2e.test_ui         # Playwright browser regression (starts its own uvicorn)
python -m tests.test_memory | test_skills | test_streaming | test_broad_coverage | test_context_no_hijack | test_docgen_reference | test_search_chats
```
These are standalone scripts run with `python -m`. There is no pytest config. Some of them write to the live database and are meant to clean up after themselves.

**Build / deploy:** there is no build step. No deployment tooling exists in the repo.

---

## 9. IMPORTANT CODE PATTERNS

- **Fail closed, everywhere.**
  - `hybrid_search` with a NULL department returns nothing.
  - A pre-gate failure returns "not found".
  - An unconfigured admin gate returns 503.
  - An unresolved pronoun leads to a question, never a retrieval on the pronoun text.
- **Confidence comes from the reranker, not from RRF.** RRF scores encode rank only, so the 0–10 cross-encoder score is the "did we find anything" signal.
- **Interpretation context vs. evidence.** Conversation turns and long-term memory are passed to the planner and generator only to understand references. They are never sources and never widen scope.
- **No canned user-facing text.** Every refusal, clarification and chitchat reply is composed by the model through `responder.compose`, from structured facts. There is no hardcoded fallback; on failure it raises. This rule also applies to LLM prompts (a prompt must not instruct a fixed phrase).
- **LLM-judged shape and intent over keyword lists.** `planner.understand` and `depends_on_context` replaced regex vocabularies. The old regexes are kept only as a failure fallback.
- **Deterministic first, LLM second.** For example, entity routing runs before the LLM router, and `is_pure_social` can only downgrade a chitchat label.
- **Instrumentation by Stopwatch.** Every real stage is wrapped in `sw.stage(name)`. The same hook drives both `latency_log` and SSE status labels, so status can't describe work that didn't run. `test_streaming` asserts the stage names and the label map agree in both directions.
- **Resilience.**
  - `clients.db_call` retries only transient httpx transport errors, with backoff.
  - Broad retrieval retries failed departments serially and discloses the ones that stay empty.
  - Persistence and logging (`_record`, `routing_log`, `perf.persist`) swallow exceptions so they never break a response.
- **Concurrency.** `ThreadPoolExecutor` is used for the lane/intent judgement and for per-department fan-out. The cross-encoder is a lazily built, lock-guarded singleton, warmed on a daemon thread at startup.
- **Auth.**
  - There is no user authentication. The identity is `anon_user_id`, a client UUID. Anyone who knows a conversation id can read it through the id-addressed routes (see section 10).
  - KB admin uses HTTP Basic with `secrets.compare_digest` on both fields and one identical error message.
- **Error handling.** 400 for bad input, 404 for an unknown id, 401 or 503 for admin. Pipeline exceptions inside the SSE worker become an `error` event, and the frontend falls back to the non-streaming endpoint.
- **State management.** Backend: stateless, apart from the in-memory ingest `JOBS` and the entity-index cache. Frontend: module-level JS variables (`APPS`, `activeConversation`), with `localStorage` used only for `anon_user_id`.
- **Test hygiene rules** (from `CLAUDE.md`): tests that write to production tables must clean up in `finally`, and an "answered" vs "refused" judgement must be consistent across harnesses. After code edits, restart the server explicitly (`--reload` has silently failed before) and verify freshness with a behavioural check.
- **Source-corruption guards.** Hooks block heredoc-written source containing backslash escapes (a literal 0x08 in place of `\b` silently broke regexes three times) and scan edited files for raw control bytes.
- **Citations.** One `[source: file.json]` bracket per file. Department attribution goes in the prose, and citations are snapped to real retrieved filenames.

---

## 10. KNOWN ISSUES AND LIMITATIONS

**Stale or contradictory documentation (the code is the truth):**
- `backend/README.md` and `frontend/CLAUDE.md` say chat is not wired to the frontend. The code **is** wired (`/api/chat`, `/api/chat/stream`, conversations).
- `backend/README.md` says the retriever is "LLM rerank" and the eval has "31 cases", whereas the default is the cross-encoder.
- `backend/db/README.md` says "Nothing here has been run", lists only 001–003, and lists the RRF problem as an open item that is already fixed in `002`.
- The root `CLAUDE.md` says "18 departments in the frontend", but `index.html` has **17**. OCPE is deliberately omitted from `APPS` (it has no data), so it can't be @mentioned or picked in the UI, although the backend still treats it as a valid slug.
- `frontend/CLAUDE.md` describes some now-removed mock-answer fallback behaviour and a Track A "no fetch calls" rule that no longer matches the file.
- `CLAUDE.md.bak` is an unreferenced leftover.

**Security and privacy limitations:**
- **No real authentication.**
  - Identity is a client-controlled UUID.
  - `GET /api/conversations/{id}`, `PATCH` and `DELETE /api/conversations/{id}`, `DELETE /api/memory/{id}` and `POST /api/skills/upload` have no ownership or auth check. Knowing an id is enough.
  - `GET /api/skills` and `GET /api/head-departments` are open.
- CORS is `*`, and the KB-admin credentials are sent as Basic auth. This is only safe over HTTPS.
- Skill **scripts are stored on disk and never executed.** Sandboxing is an explicit open decision, and the spec forbids adding direct execution.
- The long-term-memory filter is regex-based. It was tested against the categories listed in the spec, but it is a blocklist and can't be exhaustive.

**Functional and accuracy limitations:**
- 3 of 18 departments (Finance, SME Advisory Group, OCPE) have no data, so they return a blank or "not found" result.
- A held ISC file (Support Services) is parked un-ingested on purpose, pending a delete-or-coexist decision on an older duplicate (from the user's memory notes).
- Thresholds are uncalibrated guesses: `GROUNDEDNESS_MIN_RELEVANCE` 4.0, `HD_ROUTING_MIN_CONFIDENCE` 0.55, `HD_ROUTING_DUAL_MARGIN` 0.15. They are meant to be tuned from `routing_log`.
- A pipeline request makes several sequential LLM calls (lane and intent concurrently, then possibly reference resolution, routing, generation, verification and possibly a rewrite). Latency is multi-second, and the first request after a cold start depends on the cross-encoder warm-up.
- The claim verifier is itself an LLM, so it can misfire. This is why the "re-verify once on total strip" workaround exists.
- Ingest **job state is in process memory**: it is lost on restart and doesn't work across multiple workers.
- A failed OpenAI embedding raises after retries and fails that file only. Duplicate-looking uploads are warned about but still ingested.
- Docgen output is a base64 payload inside the JSON response, which is fine for small files but would not scale to large ones. Docgen formats whatever chunks were retrieved, so a document is only as complete as the retrieval.
- Chitchat and shape classification depend on LLM judgement, which is non-deterministic. Several documented past bugs came from this (pronoun resolution, lane mislabeling).
- Dependencies are unpinned (lower bounds only). torch is pulled in transitively. The backend venv is on Python 3.14.
- `003_optional_hardening.sql` duplicates the `hybrid_search` body, so the two must be edited together.
- Spec-mandated test hygiene has gaps by nature: tests run against the **live** Supabase project, with no separate test database.

**No `TODO` or `FIXME` markers were found in project source.**

---

## 11. KEY FILES (read these first)

1. **`CLAUDE.md`**: the intent, rules and acceptance criteria. It explains why many odd-looking design choices exist (fail-closed scoping, no canned text, no raw token streaming, test hygiene). Some sections have since been moved into code.
2. **`backend/main.py`**: all routes plus `_run_chat`, the single orchestration function that shows the whole request flow and lane handling.
3. **`backend/planner/planner.py`** (~1,200 lines): scope resolution, lane classification, intent/shape judgement, reference resolution, deterministic entity index, and `routing_log`. This is the most intricate module.
4. **`backend/groundedness/gate.py`** (~750 lines): pre-gate, prompts, claim verification, citation snapping, `do_not_disclose`, blank-section logic. It is the core of the "no hallucination" guarantee.
5. **`backend/retriever/retriever.py`**: `hybrid_search` fan-out, cross-encoder rerank and the sigmoid mapping, blank-content down-weighting, and structural broad retrieval.
6. **`backend/db/001_schema.sql` and `002_hybrid_search.sql`** (plus `004`): the data model and the RRF RPC.
7. **`backend/ingestion/pipeline.py` and `chunker.py`**: how raw JSON becomes chunks, the incremental/full/orphan logic, and where `do_not_disclose` is removed from the embedded text.
8. **`backend/memory/store.py`**: conversations, turns, search, and the long-term-memory safety filter.
9. **`frontend/index.html`**: the whole UI. Start at the `APPS` array, then `ensureConversation`, `findKBAnswer`, `streamChat`, `revealAnswer`, `sendMessage` and `startIngest`.
10. **`backend/config.py`** (with `backend/ingestion/hd_map.py`): every tunable and env var, and the canonical department list. Together they are the quickest way to understand what is configurable and what the 18 departments are.

For verification and behaviour examples, `backend/tests/eval_set.py` and `backend/tests/proof_continuity.py` are the most informative.
